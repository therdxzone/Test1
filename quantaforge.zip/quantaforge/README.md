# QuantaForge – VPS Hosting Platform

Node.js + Express + SQLite (better-sqlite3), vanilla HTML/CSS/JS frontend. **VPS creation is fully manual** – nothing is ever provisioned automatically.

## Quick start
```bash
npm install
cp .env.example .env        # fill JWT_SECRET, VPS_SECRET (32+ chars each), ADMIN_EMAIL, ADMIN_PASSWORD (10+ chars)
npm run init-db             # creates tables, seeds categories/plans, creates the first admin
npm start                   # http://localhost:3000   admin: /admin.html
```
Generate secrets: `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`

## Category availability (Admin > Manage VPS Categories)
Each category has a status (Available / Coming Soon / Unavailable), description and announcement, plus per-plan on/off switches. The storefront reads everything from `GET /api/catalog`. When a category is not Available, Buy Now is disabled **and** the API rejects order creation and payment submission for it. Setting a category to Available instantly enables Buy Now for its active plans. No redeploy needed. Seed state: Intel Platinum = Available, AMD EPYC and Ryzen = Coming Soon.

## Order flow
Register → pick plan → order (Pending Payment) → pay externally → submit transaction ID (Payment Submitted) → admin sets Under Review / Approved / Rejected → admin creates VPS at provider → admin saves IP + login in order modal (Completed) → customer sees it in My VPS. Admin can later suspend/terminate (customer loses access to credentials).

## Production deployment (Ubuntu VPS)
```bash
sudo apt update && sudo apt install -y nginx certbot python3-certbot-nginx build-essential python3
# install Node 20+ (e.g. via nodesource), then:
sudo npm i -g pm2
git clone/upload project to /var/www/quantaforge && cd /var/www/quantaforge
npm ci --omit=dev && cp .env.example .env && nano .env && npm run init-db
pm2 start ecosystem.config.js && pm2 save && pm2 startup   # run the command it prints
sudo cp deploy/nginx.conf /etc/nginx/sites-available/quantaforge
sudo ln -s /etc/nginx/sites-available/quantaforge /etc/nginx/sites-enabled/ && sudo nginx -t && sudo systemctl reload nginx
sudo certbot --nginx -d yourdomain.com
```
Back up `data/quantaforge.db` regularly (`sqlite3 data/quantaforge.db ".backup backup.db"`). Never lose `VPS_SECRET`: it encrypts stored VPS passwords (AES-256-GCM).

## Notes / limits
- Seeded CPU and storage values are placeholders (the spec gave RAM and price only). Edit them in Admin > Plans.
- No email service: "Forgot password" notifies the admin, who issues a temporary password from Admin > Users.
- Logo is set by URL (no file upload). Terms/Privacy text is placeholder, replace before launch.
- Payment is verified manually by the admin; no payment gateway.
