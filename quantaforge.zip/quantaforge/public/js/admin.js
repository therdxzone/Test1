const app = $('#app'); let ME = null, TAB = 'dashboard';
const TABS = [['dashboard', 'Dashboard'], ['orders', 'Orders'], ['categories', 'Manage VPS Categories'], ['plans', 'Plans'], ['users', 'Users'], ['tickets', 'Tickets'], ['settings', 'Website Settings']];
const ST = ['available', 'coming_soon', 'unavailable'];
const OS = ['pending_payment', 'payment_submitted', 'under_review', 'approved', 'rejected'];
const opts = (list, cur) => list.map((x) => `<option value="${x}" ${x === cur ? 'selected' : ''}>${esc(label(x))}</option>`).join('');
const tbl = (cols, rows) => `<div class="tw"><table><tr>${cols.map((c) => `<th>${c}</th>`).join('')}</tr>${rows.join('') || `<tr><td colspan="${cols.length}" class="sub">Nothing here.</td></tr>`}</table></div>`;
const act = async (fn, ok = 'Saved') => { try { await fn(); toast(ok); show(TAB); } catch (e) { toast(e.message); } };
let CACHE = {};

function shell(html) {
  app.innerHTML = `<div class="dash"><div class="side">${TABS.map(([k, t]) => `<a href="#" data-t="${k}" class="${k === TAB ? 'on' : ''}">${t}</a>`).join('')}</div><div id="pane">${html}</div></div>`;
  app.querySelectorAll('[data-t]').forEach((a) => a.onclick = (e) => { e.preventDefault(); show(a.dataset.t); });
}
const V = {
  async dashboard() {
    const s = await api('/admin/stats');
    return `<h2>Dashboard</h2><div class="grid">${[['Total Users', s.users], ['Total Orders', s.orders], ['Total Revenue', inr(s.revenue)], ['Pending Orders', s.pending], ['Approved Orders', s.approved], ['Rejected Orders', s.rejected], ['Open Tickets', s.open_tickets]].map(([t, n]) => `<div class="card"><div class="sub">${t}</div><div class="stat">${n}</div></div>`).join('')}</div><p class="sub">Revenue counts approved and completed orders at the price charged when ordered.</p>`;
  },
  async orders() {
    const o = CACHE.orders = await api('/admin/orders');
    return `<h2>Orders</h2>${tbl(['#', 'Customer', 'Plan', 'Price', 'Txn ref', 'Status', 'VPS', ''], o.map((r) => `<tr><td>${r.id}</td><td>${esc(r.user_name)}<br><span class="sub">${esc(r.user_email)}</span></td><td>${esc(r.plan_name)}</td><td>${inr(r.price)}</td><td>${esc(r.txn_ref || '—')}</td><td>${badge(r.status)}</td><td>${r.vps_status ? badge(r.vps_status) : '—'}</td><td><button class="btn sm" onclick="orderModal(${r.id})">Manage</button></td></tr>`))}`;
  },
  async categories() {
    const c = await api('/admin/categories'), p = await api('/admin/plans');
    return `<h2>Manage VPS Categories</h2><p class="sub">Changes apply to the live website immediately. Only available categories accept orders.</p>${c.map((x) => `<div class="card" style="margin-bottom:14px"><div class="row" style="justify-content:space-between"><h3>${esc(x.name)}</h3>${badge(x.status)}</div>
    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))"><div><label>Status</label><select id="cs${x.id}">${opts(ST, x.status)}</select></div><div><label>Description</label><textarea id="cd${x.id}" maxlength="500">${esc(x.description)}</textarea></div><div><label>Announcement (optional)</label><textarea id="ca${x.id}" maxlength="500">${esc(x.announcement)}</textarea></div></div>
    <div class="row" style="margin-top:10px"><button class="btn sm" onclick="saveCat(${x.id})">Save</button><button class="btn sm alt" onclick="setCat(${x.id},'available')">Set Available</button><button class="btn sm alt" onclick="setCat(${x.id},'coming_soon')">Set Coming Soon</button><button class="btn sm alt" onclick="setCat(${x.id},'unavailable')">Disable</button></div>
    <h4>Plan availability</h4><div class="row">${p.filter((y) => y.category_id === x.id).map((y) => `<label style="display:flex;gap:6px;align-items:center;margin:0;color:var(--tx)"><input type="checkbox" style="width:auto" ${y.active ? 'checked' : ''} onchange="togglePlan(${y.id},this.checked)">${esc(y.ram)} · ${inr(y.price)}</label>`).join('')}</div></div>`).join('')}`;
  },
  async plans() {
    const [p, c] = [await api('/admin/plans'), await api('/admin/categories')]; CACHE.plans = p; CACHE.cats = c;
    return `<div class="row" style="justify-content:space-between"><h2>Plans</h2><button class="btn" onclick="planModal()">Add plan</button></div>${tbl(['Category', 'Name', 'RAM', 'CPU', 'Storage', 'Price', 'Active', ''], p.map((r) => `<tr><td>${esc(r.category_name)}</td><td>${esc(r.name)}</td><td>${esc(r.ram)}</td><td>${esc(r.cpu)}</td><td>${esc(r.storage)}</td><td>${inr(r.price)}</td><td>${r.active ? 'Yes' : 'No'}</td><td><button class="btn sm alt" onclick="planModal(${r.id})">Edit</button> <button class="btn sm bad" onclick="delPlan(${r.id})">Delete</button></td></tr>`))}`;
  },
  async users() {
    const d = CACHE.users = await api('/admin/users?q=' + encodeURIComponent(CACHE.q || ''));
    return `<h2>Users</h2><div class="row"><input id="uq" placeholder="Search name or email" value="${esc(CACHE.q || '')}" style="max-width:300px"><button class="btn sm" onclick="CACHE.q=$('#uq').value;show('users')">Search</button></div>
    ${d.reset_requests.length ? `<div class="notice">Password reset requests: ${d.reset_requests.map((r) => esc(r.email)).join(', ')}</div>` : ''}
    ${tbl(['ID', 'Name', 'Email', 'Role', 'Orders', 'Status', ''], d.users.map((u) => `<tr><td>${u.id}</td><td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${u.role}</td><td>${u.orders}</td><td>${badge(u.status)}</td><td>${u.role === 'admin' ? '' : `<button class="btn sm alt" onclick="userOrders(${u.id})">Orders</button> <button class="btn sm ${u.status === 'active' ? 'bad' : ''}" onclick="uStatus(${u.id},'${u.status === 'active' ? 'suspended' : 'active'}')">${u.status === 'active' ? 'Suspend' : 'Activate'}</button> <button class="btn sm alt" onclick="resetPw(${u.id})">Reset password</button>`}</td></tr>`))}`;
  },
  async tickets() {
    const t = await api('/admin/tickets');
    return `<h2>Support Tickets</h2>${t.map((x) => `<div class="card" style="margin-bottom:10px"><div class="row" style="justify-content:space-between"><b>#${x.id} ${esc(x.subject)}</b>${badge(x.status)}</div><p class="sub">${esc(x.user_email)}</p><p>${esc(x.message)}</p><textarea id="tr${x.id}" placeholder="Reply…">${esc(x.reply)}</textarea><div class="row" style="margin-top:8px"><button class="btn sm" onclick="replyT(${x.id},'open')">Save reply</button><button class="btn sm alt" onclick="replyT(${x.id},'closed')">Reply &amp; close</button></div></div>`).join('') || '<p class="sub">No tickets.</p>'}`;
  },
  async settings() {
    const s = await api('/admin/settings');
    return `<h2>Website Settings</h2><form class="f" id="sf" style="max-width:560px"><div><label>Website name</label><input name="site_name" value="${esc(s.site_name)}" required></div><div><label>Logo URL (https://… or /images/…)</label><input name="logo_url" value="${esc(s.logo_url)}"></div><div><label>Discord support link</label><input name="discord_url" value="${esc(s.discord_url)}" required></div><div><label>Announcement (shown site-wide)</label><textarea name="announcement" maxlength="500">${esc(s.announcement)}</textarea></div><div><label>Maintenance mode (pauses new orders)</label><select name="maintenance"><option value="0" ${s.maintenance === '0' ? 'selected' : ''}>Off</option><option value="1" ${s.maintenance === '1' ? 'selected' : ''}>On</option></select></div><button class="btn">Save settings</button></form>`;
  },
};
async function show(t) { TAB = t; shell(loading); try { $('#pane').innerHTML = await V[t](); } catch (e) { $('#pane').innerHTML = `<div class="notice">${esc(e.message)}</div>`; } }
window.show = show; window.CACHE = CACHE;

window.saveCat = (id) => act(() => api('/admin/categories/' + id, 'PUT', { status: $('#cs' + id).value, description: $('#cd' + id).value, announcement: $('#ca' + id).value }));
window.setCat = (id, status) => act(() => api('/admin/categories/' + id, 'PUT', { status }));
window.togglePlan = (id, on) => act(() => api('/admin/plans/' + id, 'PUT', { active: on }));
window.delPlan = (id) => confirm('Delete this plan?') && act(() => api('/admin/plans/' + id, 'DELETE'), 'Deleted');
window.uStatus = (id, status) => act(() => api(`/admin/users/${id}/status`, 'PUT', { status }));
window.resetPw = async (id) => { if (!confirm('Generate a temporary password for this user?')) return; try { const d = await api(`/admin/users/${id}/reset-password`, 'POST', {}); prompt('Temporary password (send it to the user securely):', d.temp_password); show('users'); } catch (e) { toast(e.message); } };
window.replyT = (id, status) => act(() => api('/admin/tickets/' + id, 'PUT', { reply: $('#tr' + id).value, status }));
window.userOrders = async (id) => { const o = await api(`/admin/users/${id}/orders`); modal(`<h3>User orders</h3>${tbl(['#', 'Plan', 'Price', 'Status'], o.map((r) => `<tr><td>${r.id}</td><td>${esc(r.plan_name)}</td><td>${inr(r.price)}</td><td>${badge(r.status)}</td></tr>`))}`); };

function modal(html) { const m = document.createElement('div'); m.className = 'modal'; m.innerHTML = `<div class="card">${html}<div style="margin-top:12px"><button class="btn alt sm" data-x>Close</button></div></div>`; m.addEventListener('click', (e) => { if (e.target === m || e.target.dataset.x !== undefined) m.remove(); }); document.body.append(m); return m; }
window.planModal = (id) => {
  const p = CACHE.plans.find((x) => x.id === id) || { name: '', ram: '', cpu: '', storage: '', price: '', active: 1, category_id: CACHE.cats[0].id };
  const m = modal(`<h3>${id ? 'Edit' : 'Add'} plan</h3><form class="f" id="pmf"><div><label>Category</label><select name="category_id">${CACHE.cats.map((c) => `<option value="${c.id}" ${c.id === p.category_id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select></div>
  ${['name', 'ram', 'cpu', 'storage'].map((k) => `<div><label>${k.toUpperCase()}</label><input name="${k}" value="${esc(p[k])}" required></div>`).join('')}<div><label>Price (₹/month)</label><input name="price" type="number" min="1" step="1" value="${esc(p.price)}" required></div>
  <label style="display:flex;gap:8px;align-items:center"><input type="checkbox" name="active" style="width:auto" ${p.active ? 'checked' : ''}> Active</label><button class="btn">Save</button></form>`);
  $('#pmf', m).onsubmit = (e) => { e.preventDefault(); const f = new FormData(e.target), b = Object.fromEntries(f); b.category_id = +b.category_id; b.price = +b.price; b.active = f.has('active'); act(() => api(id ? '/admin/plans/' + id : '/admin/plans', id ? 'PUT' : 'POST', b)).then(() => m.remove()); };
};
window.orderModal = (id) => {
  const o = CACHE.orders.find((x) => x.id === id), canVps = ['approved', 'completed'].includes(o.status);
  const m = modal(`<h3>Order #${o.id} · ${esc(o.plan_name)} · ${inr(o.price)}</h3><p>${esc(o.user_name)} · ${esc(o.user_email)}<br>Txn ref: <b>${esc(o.txn_ref || 'not submitted')}</b> · ${badge(o.status)}</p>
  <form class="f" id="omf" style="max-width:none"><div><label>Status ${o.status === 'completed' ? '(completed – VPS delivered)' : ''}</label><select name="status" ${o.status === 'completed' ? 'disabled' : ''}>${opts(OS, o.status)}</select></div><div><label>Admin notes</label><textarea name="admin_notes">${esc(o.admin_notes)}</textarea></div><button class="btn">Save order</button></form>
  <h4>VPS details (create the VPS manually at your provider first)</h4>${canVps ? `<form class="f" id="ovf" style="max-width:none"><div><label>IP address</label><input name="ip" value="${esc(o.ip || '')}" required></div><div><label>Login username</label><input name="login_user" value="${esc(o.login_user || '')}" required></div><div><label>Login password ${o.login_password ? '(leave blank to keep)' : ''}</label><input name="login_password" type="text" autocomplete="off"></div>
  <div><label>VPS status</label><select name="status">${opts(['active', 'suspended', 'terminated'], o.vps_status || 'active')}</select></div><button class="btn sec">Save VPS details &amp; mark completed</button></form>` : '<p class="sub">Approve the order to enter VPS details.</p>'}`);
  $('#omf', m).onsubmit = (e) => { e.preventDefault(); const b = Object.fromEntries(new FormData(e.target)); if (o.status === 'completed') delete b.status; act(() => api('/admin/orders/' + id, 'PUT', b)).then(() => m.remove()); };
  if (canVps) $('#ovf', m).onsubmit = (e) => { e.preventDefault(); const b = Object.fromEntries(new FormData(e.target)); if (!b.login_password) delete b.login_password; act(() => api(`/admin/orders/${id}/vps`, 'PUT', b)).then(() => m.remove()); };
};
document.addEventListener('submit', (e) => { if (e.target.id !== 'sf') return; e.preventDefault(); act(() => api('/admin/settings', 'PUT', Object.fromEntries(new FormData(e.target)))); });

function login() {
  $('#out').hidden = true;
  app.innerHTML = `<div class="card authbox"><h2>Admin login</h2><form class="f" id="alf"><div><label>Email</label><input type="email" name="email" required></div><div><label>Password</label><input type="password" name="password" required></div><div class="err" id="ae"></div><button class="btn">Login</button></form></div>`;
  $('#alf').onsubmit = async (e) => { e.preventDefault(); try { const d = await api('/auth/login', 'POST', Object.fromEntries(new FormData(e.target))); if (d.user.role !== 'admin') { await api('/auth/logout', 'POST', {}); throw new Error('Not an admin account'); } start(d.user); } catch (er) { $('#ae').textContent = er.message; } };
}
function start(u) { ME = u; $('#out').hidden = false; show('dashboard'); }
$('#out').onclick = async (e) => { e.preventDefault(); await api('/auth/logout', 'POST', {}); login(); };
(async () => { app.innerHTML = loading; try { const { user } = await api('/auth/me'); user.role === 'admin' ? start(user) : login(); } catch { login(); } })();
