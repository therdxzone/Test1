const S = { cat: null, user: null };
const app = $('#app');

async function loadCatalog() { S.cat = await api('/catalog'); }
async function loadUser() { try { S.user = (await api('/auth/me')).user; } catch { S.user = null; } }

function chrome() {
  const s = S.cat.settings;
  document.title = s.site_name + ' – Premium VPS Hosting';
  $('#brand').innerHTML = (s.logo_url ? `<img src="${esc(s.logo_url)}" alt="">` : '') + `<b>${esc(s.site_name)}</b>`;
  $('#discord').href = s.discord_url;
  $('#foot').textContent = `© ${new Date().getFullYear()} ${s.site_name}`;
  const msgs = [s.maintenance ? 'Site is under maintenance. Ordering is temporarily paused.' : '', s.announcement].filter(Boolean);
  $('#ann').innerHTML = msgs.map((m) => `<div class="ann">${esc(m)}</div>`).join('');
  $('#links').innerHTML = ['#/|Home', '#/vps|VPS Hosting', '#/pricing|Pricing', '#/about|About', '#/contact|Contact'].map((l) => { const [h, t] = l.split('|'); return `<a href="${h}">${t}</a>`; }).join('')
    + (S.user ? `<a href="#/dashboard">Dashboard</a>${S.user.role === 'admin' ? '<a href="/admin.html">Admin</a>' : ''}` : '<a href="#/login">Login</a><a class="btn sm" href="#/register">Get Started</a>');
}
$('#burger').onclick = () => $('#links').classList.toggle('open');

/* ---------- plans ---------- */
const statusText = { available: 'Available', coming_soon: 'Coming Soon', unavailable: 'Unavailable' };
const catBadge = (c) => `<span class="badge b-${c.status}">${statusText[c.status]}</span>`;
function planCard(p, c) {
  const can = c.status === 'available' && !S.cat.settings.maintenance;
  return `<div class="card hov"><h3>${esc(p.ram)}</h3><div class="price">${inr(p.price)}<small>/month</small></div>
  <ul class="spec"><li>RAM <b>${esc(p.ram)}</b></li><li>CPU <b>${esc(p.cpu)}</b></li><li>Storage <b>${esc(p.storage)}</b></li></ul>
  <button class="btn" style="width:100%" ${can ? '' : 'disabled'} onclick="buy(${p.id},this)">${can ? 'Buy Now' : statusText[c.status] === 'Available' ? 'Paused' : statusText[c.status]}</button></div>`;
}
function catBlock(c) {
  return `<div class="cathead"><h2>${esc(c.name)}</h2>${catBadge(c)}</div><p class="sub">${esc(c.description)}</p>
  ${c.announcement ? `<div class="notice ${c.status === 'available' ? 'info' : ''}">${esc(c.announcement)}</div>` : ''}
  ${c.status !== 'available' ? `<div class="notice">${c.status === 'coming_soon' ? 'Coming soon – ordering opens when this category launches.' : 'Currently unavailable for new orders.'}</div>` : ''}
  <div class="grid">${c.plans.map((p) => planCard(p, c)).join('') || '<p class="sub">No plans listed.</p>'}</div>`;
}
window.buy = async (id, btn) => {
  if (!S.user) { location.hash = '#/login'; toast('Please log in to order'); return; }
  try { await busy(btn, () => api('/me/orders', 'POST', { plan_id: id })); toast('Order created. Submit your payment reference.'); location.hash = '#/dashboard/orders'; }
  catch (e) { toast(e.message); await loadCatalog(); route(); }
};

/* ---------- public pages ---------- */
const P = {};
P.home = () => `<div class="hero"><div class="wrap"><h1>Premium VPS Hosting,<br><span class="grad">Forged for Performance</span></h1>
<p>Intel Platinum, AMD EPYC and AMD Ryzen servers with NVMe storage, 24/7 support and honest pricing in ₹.</p>
<a class="btn" href="#/pricing">View Plans</a> <a class="btn alt" href="#/register">Create Account</a></div></div>
<section class="s"><div class="wrap"><h2>Why Choose ${esc(S.cat.settings.site_name)}</h2><div class="grid">
${[['⚡', 'NVMe Speed', 'Fast storage on every plan.'], ['🛡️', 'Reliable Uptime', 'Enterprise-grade hardware and networking.'], ['💬', 'Discord Support', 'Talk to real people, fast.'], ['💸', 'Simple Pricing', 'Monthly plans in rupees, no hidden fees.']].map(([i, t, d]) => `<div class="card hov"><div style="font-size:28px">${i}</div><h3>${t}</h3><p class="sub">${d}</p></div>`).join('')}</div></div></section>
<section class="s"><div class="wrap"><h2>VPS Plan Categories</h2><div class="grid">${S.cat.categories.map((c) => `<div class="card hov"><div class="row" style="justify-content:space-between"><h3>${esc(c.name)}</h3>${catBadge(c)}</div><p class="sub">${esc(c.description)}</p>${c.plans.length ? `<p>From <b>${inr(Math.min(...c.plans.map((p) => p.price)))}</b>/month</p>` : ''}${c.announcement ? `<div class="notice">${esc(c.announcement)}</div>` : ''}<a class="btn alt sm" href="#/pricing">View plans</a></div>`).join('')}</div></div></section>
<section class="s"><div class="wrap"><h2>Features</h2><div class="grid">${['Full root access', 'Dedicated resources', 'DDoS protection', 'Fast manual provisioning after payment verification', 'Dashboard to track orders and VPS', 'Support tickets'].map((f) => `<div class="card">✔ ${f}</div>`).join('')}</div></div></section>
<section class="s"><div class="wrap"><h2>Server Performance</h2><p class="sub">Choose the hardware that matches your workload:</p><div class="grid">
<div class="card"><h3>Intel Platinum</h3><p class="sub">Balanced, stable performance for websites, bots and apps.</p></div>
<div class="card"><h3>AMD EPYC</h3><p class="sub">Many cores for databases, builds and heavy multitasking.</p></div>
<div class="card"><h3>AMD Ryzen 5/7</h3><p class="sub">Top single-thread speed for game servers.</p></div></div></div></section>
<section class="s"><div class="wrap"><h2>FAQ</h2>
<details><summary>How fast is my VPS delivered?</summary><p class="sub">VPS servers are created manually after an admin verifies your payment.</p></details>
<details><summary>How do I pay?</summary><p class="sub">Pay externally, then submit the transaction reference in your dashboard for verification.</p></details>
<details><summary>Why is a category Coming Soon?</summary><p class="sub">We open categories as capacity becomes ready. Check back or join our Discord.</p></details></div></section>`;
P.vps = P.pricing = () => `<section class="s"><div class="wrap"><h1>VPS Hosting Plans</h1>${S.cat.settings.maintenance ? '<div class="notice">Ordering is paused during maintenance.</div>' : ''}${S.cat.categories.map(catBlock).join('')}</div></section>`;
P.about = () => `<section class="s"><div class="wrap"><h1>About Us</h1><p class="sub">${esc(S.cat.settings.site_name)} provides straightforward, high-performance VPS hosting. Every server is set up by a real person, so you get a verified, hands-on start.</p></div></section>`;
P.contact = () => `<section class="s"><div class="wrap"><h1>Contact Us</h1><p>The fastest way to reach us is Discord.</p><a class="btn" href="${esc(S.cat.settings.discord_url)}" target="_blank" rel="noopener">Join Discord Support</a><p class="sub">Logged-in customers can also open a support ticket from the dashboard.</p></div></section>`;
P.terms = () => `<section class="s"><div class="wrap"><h1>Terms &amp; Conditions</h1><p class="sub">Replace this text with your legal terms before launch.</p><p>Services are billed monthly. Orders are activated manually after payment verification. Abuse, illegal activity or spam leads to suspension without refund.</p></div></section>`;
P.privacy = () => `<section class="s"><div class="wrap"><h1>Privacy Policy</h1><p class="sub">Replace this text with your privacy policy before launch.</p><p>We store your name, email and order details to provide the service. Passwords are hashed. We do not sell your data.</p></div></section>`;

function authForm(kind) {
  const reg = kind === 'register', fg = kind === 'forgot';
  return `<div class="wrap"><div class="card authbox"><h2>${reg ? 'Create account' : fg ? 'Forgot password' : 'Welcome back'}</h2>
  <form class="f" id="af">${reg ? '<div><label>Name</label><input name="name" required minlength="2" autocomplete="name"></div>' : ''}
  <div><label>Email</label><input type="email" name="email" required autocomplete="email"></div>
  ${fg ? '' : `<div><label>Password</label><input type="password" name="password" required minlength="8" autocomplete="${reg ? 'new' : 'current'}-password"></div>`}
  <div class="err" id="ae"></div><button class="btn">${reg ? 'Register' : fg ? 'Request reset' : 'Login'}</button></form>
  <p class="sub">${reg ? '<a href="#/login">Have an account? Login</a>' : fg ? '<a href="#/login">Back to login</a>' : '<a href="#/register">Create account</a> · <a href="#/forgot">Forgot password?</a>'}</p></div></div>`;
}
P.login = () => authForm('login'); P.register = () => authForm('register'); P.forgot = () => authForm('forgot');
document.addEventListener('submit', async (e) => {
  if (e.target.id !== 'af') return; e.preventDefault();
  const kind = location.hash.slice(2), body = Object.fromEntries(new FormData(e.target)), btn = e.target.querySelector('button');
  try {
    const d = await busy(btn, () => api('/auth/' + kind, 'POST', body));
    if (kind === 'forgot') { $('#ae').className = 'okmsg'; $('#ae').textContent = d.message; return; }
    S.user = d.user; chrome(); location.hash = '#/dashboard';
  } catch (er) { $('#ae').textContent = er.message; }
});

/* ---------- dashboard ---------- */
const NAV = [['', 'Overview'], ['plans', 'Available VPS Plans'], ['orders', 'My Orders'], ['vps', 'My VPS'], ['payments', 'Payment History'], ['tickets', 'Support Tickets'], ['profile', 'Profile Settings']];
const table = (cols, rows) => `<div class="tw"><table><tr>${cols.map((c) => `<th>${c}</th>`).join('')}</tr>${rows.join('') || `<tr><td colspan="${cols.length}" class="sub">Nothing here yet.</td></tr>`}</table></div>`;
const D = {
  async '' () { const o = await api('/me/overview'); return `<h2>Hello, ${esc(S.user.name)}</h2><div class="grid">${[['Orders', o.orders], ['Active VPS', o.active_vps], ['In progress', o.pending], ['Open tickets', o.open_tickets]].map(([t, n]) => `<div class="card"><div class="sub">${t}</div><div class="stat">${n}</div></div>`).join('')}</div>`; },
  async plans() { return `<h2>Available VPS Plans</h2>${S.cat.categories.map(catBlock).join('')}`; },
  async orders() {
    const o = await api('/me/orders'); const catStatus = Object.fromEntries(S.cat.categories.map((c) => [c.name, c.status]));
    return `<h2>My Orders</h2>${table(['#', 'Plan', 'Price', 'Status', 'Date', ''], o.map((r) => `<tr><td>${r.id}</td><td>${esc(r.plan_name)}</td><td>${inr(r.price)}</td><td>${badge(r.status)}</td><td>${date(r.created_at)}</td><td>${r.status === 'pending_payment' ? (catStatus[r.category_name] === 'available' ? `<button class="btn sm" onclick="payForm(${r.id},${r.price})">Submit payment</button>` : '<span class="sub">Ordering paused</span>') : ''}</td></tr>`))}`;
  },
  async vps() {
    const v = await api('/me/vps');
    return `<h2>My VPS</h2>${v.map((x) => `<div class="card" style="margin-bottom:12px"><div class="row" style="justify-content:space-between"><h3>${esc(x.plan_name)}</h3>${badge(x.status)}</div>
    ${x.status === 'active' ? `<ul class="spec"><li>IP address <b>${esc(x.ip)}</b></li><li>Username <b>${esc(x.login_user)}</b></li><li>Password <b>${esc(x.login_password) || '—'}</b></li></ul>` : '<p class="sub">Access is disabled for this VPS. Contact support.</p>'}</div>`).join('') || '<p class="sub">No VPS yet. Once an admin approves and provisions your order it appears here.</p>'}`;
  },
  async payments() { const p = await api('/me/payments'); return `<h2>Payment History</h2>${table(['Order', 'Reference', 'Amount', 'Status', 'Date'], p.map((r) => `<tr><td>#${r.order_id}</td><td>${esc(r.txn_ref)}</td><td>${inr(r.amount)}</td><td>${badge(r.status)}</td><td>${date(r.created_at)}</td></tr>`))}`; },
  async tickets() {
    const t = await api('/me/tickets');
    return `<h2>Support Tickets</h2><form class="f" id="tf" style="max-width:560px;margin-bottom:20px"><div><label>Subject</label><input name="subject" required minlength="3" maxlength="120"></div><div><label>Message</label><textarea name="message" required minlength="5" maxlength="3000"></textarea></div><div class="err" id="te"></div><button class="btn">Open ticket</button></form>
    ${t.map((x) => `<div class="card" style="margin-bottom:10px"><div class="row" style="justify-content:space-between"><b>${esc(x.subject)}</b>${badge(x.status)}</div><p>${esc(x.message)}</p>${x.reply ? `<div class="notice info"><b>Support:</b> ${esc(x.reply)}</div>` : ''}</div>`).join('')}`;
  },
  async profile() { return `<h2>Profile Settings</h2><div class="grid"><form class="card f" id="pf"><h3>Profile</h3><div><label>Name</label><input name="name" value="${esc(S.user.name)}" required></div><div><label>Email</label><input value="${esc(S.user.email)}" disabled></div><div class="err" id="pe"></div><button class="btn">Save</button></form>
    <form class="card f" id="pwf"><h3>Change password</h3><div><label>Current password</label><input type="password" name="current" required></div><div><label>New password</label><input type="password" name="password" required minlength="8"></div><div class="err" id="pwe"></div><button class="btn">Update</button></form></div><p><a href="#" id="lo">Logout</a></p>`; },
};
window.payForm = (id, price) => {
  const m = document.createElement('div'); m.className = 'modal';
  m.innerHTML = `<div class="card"><h3>Submit payment for order #${id}</h3><p class="sub">Pay ${inr(price)} using the method provided by support (see Discord), then enter your transaction ID.</p><form class="f" id="pyf"><div><label>Transaction reference / ID</label><input name="txn_ref" required minlength="6" maxlength="64"></div><div class="err" id="pye"></div><div class="row"><button class="btn">Submit</button><button type="button" class="btn alt" id="pyc">Cancel</button></div></form></div>`;
  document.body.append(m); $('#pyc').onclick = () => m.remove();
  $('#pyf').onsubmit = async (e) => { e.preventDefault(); try { await busy(e.target.querySelector('.btn'), () => api(`/me/orders/${id}/payment`, 'POST', { txn_ref: new FormData(e.target).get('txn_ref') })); m.remove(); toast('Payment submitted for review'); route(); } catch (er) { $('#pye').textContent = er.message; } };
};
document.addEventListener('submit', async (e) => {
  const id = e.target.id; if (!['tf', 'pf', 'pwf'].includes(id)) return; e.preventDefault();
  const body = Object.fromEntries(new FormData(e.target)), er = $(id === 'tf' ? '#te' : id === 'pf' ? '#pe' : '#pwe');
  try { await busy(e.target.querySelector('.btn'), () => api(id === 'tf' ? '/me/tickets' : id === 'pf' ? '/auth/profile' : '/auth/password', id === 'tf' ? 'POST' : 'PUT', body)); toast('Saved'); if (id === 'pf') S.user.name = body.name; id === 'pwf' ? e.target.reset() : route(); } catch (x) { er.textContent = x.message; }
});
document.addEventListener('click', async (e) => { if (e.target.id === 'lo') { e.preventDefault(); await api('/auth/logout', 'POST', {}); S.user = null; chrome(); location.hash = '#/'; } });

/* ---------- router ---------- */
async function route() {
  const [, page = '', sub = ''] = location.hash.split('/'); $('#links').classList.remove('open'); window.scrollTo(0, 0);
  try {
    if (page === 'dashboard') {
      if (!S.user) { location.hash = '#/login'; return; }
      app.innerHTML = loading; await loadCatalog(); const fn = D[sub]; if (!fn) { location.hash = '#/dashboard'; return; }
      const html = await fn();
      app.innerHTML = `<div class="wrap dash"><div class="side">${NAV.map(([k, t]) => `<a href="#/dashboard${k ? '/' + k : ''}" class="${k === sub ? 'on' : ''}">${t}</a>`).join('')}<a href="#" id="lo">Logout</a></div><div>${html}</div></div>`;
      return;
    }
    if (['login', 'register', 'forgot'].includes(page) && S.user) { location.hash = '#/dashboard'; return; }
    app.innerHTML = (P[page || 'home'] || P.home)();
  } catch (e) {
    if (e.status === 401 || e.status === 403) { S.user = null; chrome(); location.hash = '#/login'; return; }
    app.innerHTML = `<div class="wrap"><div class="notice" style="margin-top:30px">${esc(e.message)}</div></div>`;
  }
}
window.addEventListener('hashchange', async () => { if (['', '#/', '#/pricing', '#/vps'].includes(location.hash)) { try { await loadCatalog(); chrome(); } catch {} } route(); });
(async () => { app.innerHTML = loading; try { await Promise.all([loadCatalog(), loadUser()]); chrome(); route(); } catch { app.innerHTML = '<div class="wrap"><div class="notice" style="margin-top:30px">Cannot reach the server. Please try again shortly.</div></div>'; } })();
