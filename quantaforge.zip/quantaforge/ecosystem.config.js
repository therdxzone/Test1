module.exports = { apps: [{ name: 'quantaforge', script: 'src/server.js', instances: 1, env: { NODE_ENV: 'production' }, max_memory_restart: '300M' }] };
