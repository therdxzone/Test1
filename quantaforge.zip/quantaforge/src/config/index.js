require('dotenv').config();
const crypto = require('crypto');
const c = {
  port: +process.env.PORT || 3000,
  prod: process.env.NODE_ENV === 'production',
  jwt: process.env.JWT_SECRET,
  dbPath: process.env.DB_PATH || './data/quantaforge.db',
  adminEmail: process.env.ADMIN_EMAIL,
  adminPassword: process.env.ADMIN_PASSWORD,
};
if (!c.jwt || c.jwt.length < 32) throw new Error('JWT_SECRET missing or shorter than 32 chars (see .env.example)');
if (!process.env.VPS_SECRET || process.env.VPS_SECRET.length < 32) throw new Error('VPS_SECRET missing or shorter than 32 chars');
c.vpsKey = crypto.createHash('sha256').update(process.env.VPS_SECRET).digest();
module.exports = c;
