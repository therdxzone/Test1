const jwt = require('jsonwebtoken');
const cfg = require('../config');
const db = require('../database/db');

exports.sign = (u) => jwt.sign({ id: u.id }, cfg.jwt, { expiresIn: '7d' });
exports.cookieOpts = { httpOnly: true, sameSite: 'strict', secure: cfg.prod, maxAge: 7 * 864e5, path: '/' };

exports.auth = (req, res, next) => {
  try {
    const { id } = jwt.verify(req.cookies.qf_token || '', cfg.jwt);
    const u = db.prepare('SELECT id,name,email,role,status FROM users WHERE id=?').get(id);
    if (!u) return res.status(401).json({ error: 'Please log in' });
    if (u.status !== 'active') return res.status(403).json({ error: 'Account suspended. Contact support.' });
    req.user = u; next();
  } catch { res.status(401).json({ error: 'Please log in' }); }
};
exports.admin = (req, res, next) =>
  req.user && req.user.role === 'admin' ? next() : res.status(403).json({ error: 'Admin only' });
