const router = require('express').Router();
const db = require('../database/db');
const { auth } = require('../middleware/auth');
const { decrypt } = require('../services/crypto');
const { settings } = require('./public');
router.use(auth);

router.get('/orders', (req, res) =>
  res.json(db.prepare('SELECT id,plan_name,category_name,price,status,created_at FROM orders WHERE user_id=? ORDER BY id DESC').all(req.user.id)));

// Place an order. Server enforces category availability regardless of what the UI shows.
router.post('/orders', (req, res) => {
  if (settings().maintenance === '1') return res.status(503).json({ error: 'Site is in maintenance mode. Orders are paused.' });
  const plan = db.prepare(`SELECT p.*,c.name cname,c.status cstatus FROM plans p JOIN categories c ON c.id=p.category_id WHERE p.id=?`).get(+req.body?.plan_id);
  if (!plan || !plan.active) return res.status(404).json({ error: 'Plan not found' });
  if (plan.cstatus !== 'available') return res.status(409).json({ error: `${plan.cname} is not available for ordering right now` });
  const id = db.prepare('INSERT INTO orders(user_id,plan_id,plan_name,category_name,price) VALUES(?,?,?,?,?)')
    .run(req.user.id, plan.id, plan.name, plan.cname, plan.price).lastInsertRowid;
  res.status(201).json({ id });
});

// Submit payment reference (payment itself happens externally).
router.post('/orders/:id/payment', (req, res) => {
  const o = db.prepare('SELECT o.*,c.status cstatus FROM orders o JOIN plans p ON p.id=o.plan_id JOIN categories c ON c.id=p.category_id WHERE o.id=? AND o.user_id=?').get(+req.params.id, req.user.id);
  if (!o) return res.status(404).json({ error: 'Order not found' });
  if (o.status !== 'pending_payment') return res.status(409).json({ error: 'Payment already submitted for this order' });
  if (o.cstatus !== 'available') return res.status(409).json({ error: 'This category is not available for orders right now' });
  const ref = String(req.body?.txn_ref || '').trim();
  if (ref.length < 6 || ref.length > 64 || !/^[\w\-\/ ]+$/.test(ref)) return res.status(400).json({ error: 'Enter a valid transaction reference (6-64 chars)' });
  if (db.prepare('SELECT 1 FROM payments WHERE txn_ref=?').get(ref)) return res.status(409).json({ error: 'This reference was already used' });
  db.transaction(() => {
    db.prepare('INSERT INTO payments(order_id,user_id,txn_ref,amount) VALUES(?,?,?,?)').run(o.id, req.user.id, ref, o.price);
    db.prepare("UPDATE orders SET status='payment_submitted',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(o.id);
  })();
  res.json({ ok: true });
});

router.get('/payments', (req, res) =>
  res.json(db.prepare('SELECT pm.id,pm.order_id,pm.txn_ref,pm.amount,pm.status,pm.created_at FROM payments pm WHERE pm.user_id=? ORDER BY pm.id DESC').all(req.user.id)));

router.get('/vps', (req, res) => {
  const rows = db.prepare(`SELECT v.id,v.order_id,v.ip,v.login_user,v.login_password_enc,v.status,o.plan_name,o.category_name
    FROM vps v JOIN orders o ON o.id=v.order_id WHERE v.user_id=? AND v.status!='pending' ORDER BY v.id DESC`).all(req.user.id);
  res.json(rows.map(({ login_password_enc, ...v }) => ({ ...v, login_password: v.status === 'active' ? decrypt(login_password_enc) : '' })));
});

router.get('/tickets', (req, res) =>
  res.json(db.prepare('SELECT id,subject,message,reply,status,created_at FROM tickets WHERE user_id=? ORDER BY id DESC').all(req.user.id)));
router.post('/tickets', (req, res) => {
  const { subject, message } = req.body || {};
  if (typeof subject !== 'string' || subject.trim().length < 3 || subject.length > 120) return res.status(400).json({ error: 'Subject must be 3-120 characters' });
  if (typeof message !== 'string' || message.trim().length < 5 || message.length > 3000) return res.status(400).json({ error: 'Message must be 5-3000 characters' });
  const id = db.prepare('INSERT INTO tickets(user_id,subject,message) VALUES(?,?,?)').run(req.user.id, subject.trim(), message.trim()).lastInsertRowid;
  res.status(201).json({ id });
});

router.get('/overview', (req, res) => {
  const q = (sql) => db.prepare(sql).get(req.user.id).n;
  res.json({ orders: q('SELECT COUNT(*) n FROM orders WHERE user_id=?'),
    active_vps: q("SELECT COUNT(*) n FROM vps WHERE user_id=? AND status='active'"),
    pending: q("SELECT COUNT(*) n FROM orders WHERE user_id=? AND status IN ('pending_payment','payment_submitted','under_review')"),
    open_tickets: q("SELECT COUNT(*) n FROM tickets WHERE user_id=? AND status='open'") });
});
module.exports = router;
