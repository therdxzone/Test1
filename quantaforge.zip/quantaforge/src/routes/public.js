const router = require('express').Router();
const db = require('../database/db');

const settings = () => Object.fromEntries(db.prepare('SELECT key,value FROM settings').all().map((r) => [r.key, r.value]));
exports.settings = settings;

// Everything the storefront needs, straight from the DB: category status, announcements, plans, site settings.
router.get('/catalog', (req, res) => {
  const cats = db.prepare('SELECT id,slug,name,description,announcement,status FROM categories ORDER BY sort,id').all();
  const plans = db.prepare('SELECT id,category_id,name,ram,cpu,storage,price FROM plans WHERE active=1 ORDER BY sort,price').all();
  for (const c of cats) c.plans = plans.filter((p) => p.category_id === c.id);
  const s = settings();
  res.set('Cache-Control', 'no-store');
  res.json({ settings: { site_name: s.site_name, logo_url: s.logo_url, discord_url: s.discord_url,
    announcement: s.announcement, maintenance: s.maintenance === '1' }, categories: cats });
});
exports.router = router;
