const router = require('express').Router();
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const db = require('../database/db');
const { auth, admin } = require('../middleware/auth');
const { encrypt, decrypt } = require('../services/crypto');
router.use(auth, admin);

const CAT_STATUS = ['available', 'coming_soon', 'unavailable'];
const ORDER_STATUS = ['pending_payment', 'payment_submitted', 'under_review', 'approved', 'rejected', 'completed'];
const VPS_STATUS = ['pending', 'active', 'suspended', 'terminated'];
const str = (v, max) => typeof v === 'string' && v.trim().length > 0 && v.length <= max;

router.get('/stats', (req, res) => {
  const n = (sql) => db.prepare(sql).get().n;
  res.json({ users: n("SELECT COUNT(*) n FROM users WHERE role='user'"), orders: n('SELECT COUNT(*) n FROM orders'),
    revenue: n("SELECT COALESCE(SUM(price),0) n FROM orders WHERE status IN ('approved','completed')"),
    pending: n("SELECT COUNT(*) n FROM orders WHERE status IN ('pending_payment','payment_submitted','under_review')"),
    approved: n("SELECT COUNT(*) n FROM orders WHERE status IN ('approved','completed')"),
    rejected: n("SELECT COUNT(*) n FROM orders WHERE status='rejected'"),
    open_tickets: n("SELECT COUNT(*) n FROM tickets WHERE status='open'") });
});

/* ---- Categories ---- */
router.get('/categories', (req, res) => res.json(db.prepare('SELECT * FROM categories ORDER BY sort,id').all()));
router.put('/categories/:id', (req, res) => {
  const c = db.prepare('SELECT * FROM categories WHERE id=?').get(+req.params.id);
  if (!c) return res.status(404).json({ error: 'Category not found' });
  const b = req.body || {};
  const status = b.status ?? c.status, desc = b.description ?? c.description, ann = b.announcement ?? c.announcement;
  if (!CAT_STATUS.includes(status)) return res.status(400).json({ error: 'Invalid status' });
  if (typeof desc !== 'string' || desc.length > 500 || typeof ann !== 'string' || ann.length > 500) return res.status(400).json({ error: 'Text too long (max 500)' });
  db.prepare('UPDATE categories SET status=?,description=?,announcement=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status, desc, ann, c.id);
  res.json({ ok: true });
});

/* ---- Plans ---- */
const planBody = (b) => {
  const price = Number(b.price);
  if (!str(b.name, 80) || !str(b.ram, 30) || !str(b.cpu, 40) || !str(b.storage, 40)) return 'Name, RAM, CPU and storage are required';
  if (!Number.isInteger(price) || price < 1 || price > 1e7) return 'Price must be a whole number of rupees';
  if (!db.prepare('SELECT 1 FROM categories WHERE id=?').get(+b.category_id)) return 'Invalid category';
};
router.get('/plans', (req, res) => res.json(db.prepare('SELECT p.*,c.name category_name FROM plans p JOIN categories c ON c.id=p.category_id ORDER BY c.sort,p.sort,p.price').all()));
router.post('/plans', (req, res) => {
  const err = planBody(req.body || {}); if (err) return res.status(400).json({ error: err });
  const b = req.body;
  const id = db.prepare('INSERT INTO plans(category_id,name,ram,cpu,storage,price,active) VALUES(?,?,?,?,?,?,?)')
    .run(+b.category_id, b.name.trim(), b.ram.trim(), b.cpu.trim(), b.storage.trim(), +b.price, b.active === false ? 0 : 1).lastInsertRowid;
  res.status(201).json({ id });
});
router.put('/plans/:id', (req, res) => {
  const p = db.prepare('SELECT * FROM plans WHERE id=?').get(+req.params.id);
  if (!p) return res.status(404).json({ error: 'Plan not found' });
  const b = { ...p, ...req.body }; const err = planBody(b); if (err) return res.status(400).json({ error: err });
  db.prepare('UPDATE plans SET category_id=?,name=?,ram=?,cpu=?,storage=?,price=?,active=? WHERE id=?')
    .run(+b.category_id, b.name.trim(), b.ram.trim(), b.cpu.trim(), b.storage.trim(), +b.price, b.active ? 1 : 0, p.id);
  res.json({ ok: true });
});
router.delete('/plans/:id', (req, res) => {
  const id = +req.params.id;
  if (db.prepare('SELECT 1 FROM orders WHERE plan_id=?').get(id))
    return res.status(409).json({ error: 'Plan has orders; disable it instead of deleting' });
  db.prepare('DELETE FROM plans WHERE id=?').run(id); res.json({ ok: true });
});

/* ---- Orders ---- */
const orderSelect = `SELECT o.*,u.name user_name,u.email user_email,pm.txn_ref,v.ip,v.login_user,v.login_password_enc,v.status vps_status
  FROM orders o JOIN users u ON u.id=o.user_id
  LEFT JOIN payments pm ON pm.order_id=o.id LEFT JOIN vps v ON v.order_id=o.id`;
const outOrder = ({ login_password_enc, ...o }) => ({ ...o, login_password: decrypt(login_password_enc) });
router.get('/orders', (req, res) => {
  const st = req.query.status;
  const rows = st ? db.prepare(orderSelect + ' WHERE o.status=? ORDER BY o.id DESC').all(st) : db.prepare(orderSelect + ' ORDER BY o.id DESC').all();
  res.json(rows.map(outOrder));
});
router.put('/orders/:id', (req, res) => {
  const o = db.prepare('SELECT * FROM orders WHERE id=?').get(+req.params.id);
  if (!o) return res.status(404).json({ error: 'Order not found' });
  const { status, admin_notes } = req.body || {};
  if (status !== undefined) {
    if (!ORDER_STATUS.includes(status)) return res.status(400).json({ error: 'Invalid status' });
    if (status === 'completed') return res.status(400).json({ error: 'Use "Save VPS details" to complete an order' });
    if (['approved'].includes(status) && !db.prepare('SELECT 1 FROM payments WHERE order_id=?').get(o.id))
      return res.status(409).json({ error: 'No payment reference submitted yet' });
  }
  if (admin_notes !== undefined && (typeof admin_notes !== 'string' || admin_notes.length > 2000)) return res.status(400).json({ error: 'Notes too long' });
  db.transaction(() => {
    db.prepare('UPDATE orders SET status=?,admin_notes=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(status ?? o.status, admin_notes ?? o.admin_notes, o.id);
    if (status === 'approved' || status === 'rejected')
      db.prepare('UPDATE payments SET status=? WHERE order_id=?').run(status === 'approved' ? 'verified' : 'rejected', o.id);
  })();
  res.json({ ok: true });
});
// Manual provisioning: admin creates the VPS at the provider, then records details here. Nothing is auto-created.
router.put('/orders/:id/vps', (req, res) => {
  const o = db.prepare('SELECT * FROM orders WHERE id=?').get(+req.params.id);
  if (!o) return res.status(404).json({ error: 'Order not found' });
  if (!['approved', 'completed'].includes(o.status)) return res.status(409).json({ error: 'Approve the order first' });
  const { ip, login_user, login_password, status } = req.body || {};
  const cur = db.prepare('SELECT * FROM vps WHERE order_id=?').get(o.id);
  const vstatus = status || (cur && cur.status !== 'pending' ? cur.status : 'active');
  if (!VPS_STATUS.includes(vstatus)) return res.status(400).json({ error: 'Invalid VPS status' });
  if (!str(ip, 100) || !str(login_user, 100)) return res.status(400).json({ error: 'IP and login username are required' });
  if (login_password !== undefined && (typeof login_password !== 'string' || login_password.length > 200)) return res.status(400).json({ error: 'Invalid password' });
  const pw = login_password ? encrypt(login_password) : cur ? cur.login_password_enc : '';
  db.transaction(() => {
    if (cur) db.prepare('UPDATE vps SET ip=?,login_user=?,login_password_enc=?,status=?,updated_at=CURRENT_TIMESTAMP WHERE id=?').run(ip.trim(), login_user.trim(), pw, vstatus, cur.id);
    else db.prepare('INSERT INTO vps(order_id,user_id,ip,login_user,login_password_enc,status) VALUES(?,?,?,?,?,?)').run(o.id, o.user_id, ip.trim(), login_user.trim(), pw, vstatus);
    db.prepare("UPDATE orders SET status='completed',updated_at=CURRENT_TIMESTAMP WHERE id=?").run(o.id);
  })();
  res.json({ ok: true });
});

/* ---- Users ---- */
router.get('/users', (req, res) => {
  const q = `%${String(req.query.q || '').replace(/[%_]/g, '')}%`;
  res.json({ users: db.prepare(`SELECT u.id,u.name,u.email,u.role,u.status,u.created_at,(SELECT COUNT(*) FROM orders WHERE user_id=u.id) orders
    FROM users u WHERE u.name LIKE ? OR u.email LIKE ? ORDER BY u.id DESC LIMIT 200`).all(q, q),
    reset_requests: db.prepare('SELECT * FROM reset_requests ORDER BY id DESC LIMIT 20').all() });
});
router.get('/users/:id/orders', (req, res) =>
  res.json(db.prepare('SELECT id,plan_name,category_name,price,status,created_at FROM orders WHERE user_id=? ORDER BY id DESC').all(+req.params.id)));
router.put('/users/:id/status', (req, res) => {
  const id = +req.params.id, st = req.body?.status;
  if (!['active', 'suspended'].includes(st)) return res.status(400).json({ error: 'Invalid status' });
  if (id === req.user.id) return res.status(400).json({ error: "You can't suspend yourself" });
  db.prepare("UPDATE users SET status=? WHERE id=? AND role='user'").run(st, id); res.json({ ok: true });
});
router.post('/users/:id/reset-password', (req, res) => {
  const u = db.prepare("SELECT email FROM users WHERE id=? AND role='user'").get(+req.params.id);
  if (!u) return res.status(404).json({ error: 'User not found' });
  const tmp = crypto.randomBytes(9).toString('base64url');
  db.prepare('UPDATE users SET password_hash=? WHERE email=?').run(bcrypt.hashSync(tmp, 12), u.email);
  db.prepare('DELETE FROM reset_requests WHERE email=?').run(u.email);
  res.json({ temp_password: tmp });
});

/* ---- Tickets ---- */
router.get('/tickets', (req, res) => res.json(db.prepare('SELECT t.*,u.email user_email FROM tickets t JOIN users u ON u.id=t.user_id ORDER BY t.id DESC').all()));
router.put('/tickets/:id', (req, res) => {
  const { reply, status } = req.body || {};
  if (reply !== undefined && (typeof reply !== 'string' || reply.length > 3000)) return res.status(400).json({ error: 'Reply too long' });
  if (status !== undefined && !['open', 'closed'].includes(status)) return res.status(400).json({ error: 'Invalid status' });
  const t = db.prepare('SELECT * FROM tickets WHERE id=?').get(+req.params.id);
  if (!t) return res.status(404).json({ error: 'Ticket not found' });
  db.prepare('UPDATE tickets SET reply=?,status=? WHERE id=?').run(reply ?? t.reply, status ?? t.status, t.id); res.json({ ok: true });
});

/* ---- Website settings ---- */
router.get('/settings', (req, res) => res.json(require('./public').settings()));
router.put('/settings', (req, res) => {
  const b = req.body || {}, up = db.prepare('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
  const rules = { site_name: (v) => str(v, 60), logo_url: (v) => typeof v === 'string' && v.length <= 500 && (v === '' || /^https?:\/\//.test(v) || v.startsWith('/images/')),
    discord_url: (v) => typeof v === 'string' && /^https?:\/\//.test(v) && v.length <= 300, announcement: (v) => typeof v === 'string' && v.length <= 500,
    maintenance: (v) => v === '0' || v === '1' };
  for (const k of Object.keys(b)) if (!rules[k] || !rules[k](b[k])) return res.status(400).json({ error: `Invalid value for ${k}` });
  db.transaction(() => Object.entries(b).forEach(([k, v]) => up.run(k, v)))();
  res.json({ ok: true });
});
module.exports = router;
