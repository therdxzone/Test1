const router = require('express').Router();
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const db = require('../database/db');
const { sign, cookieOpts, auth } = require('../middleware/auth');

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many attempts. Try again in 15 minutes.' } });
const emailOk = (e) => typeof e === 'string' && e.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
const DUMMY = bcrypt.hashSync('dummy-password', 12);

router.post('/register', limiter, (req, res) => {
  const { name, email, password } = req.body || {};
  if (typeof name !== 'string' || name.trim().length < 2 || name.length > 80) return res.status(400).json({ error: 'Enter your name' });
  if (!emailOk(email)) return res.status(400).json({ error: 'Enter a valid email' });
  if (typeof password !== 'string' || password.length < 8 || password.length > 128) return res.status(400).json({ error: 'Password must be 8-128 characters' });
  const e = email.toLowerCase();
  if (db.prepare('SELECT 1 FROM users WHERE email=?').get(e)) return res.status(409).json({ error: 'Email already registered' });
  const id = db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(name.trim(), e, bcrypt.hashSync(password, 12)).lastInsertRowid;
  res.cookie('qf_token', sign({ id }), cookieOpts).status(201).json({ user: { id, name: name.trim(), email: e, role: 'user' } });
});

router.post('/login', limiter, (req, res) => {
  const { email, password } = req.body || {};
  const u = emailOk(email) && typeof password === 'string' ? db.prepare('SELECT * FROM users WHERE email=?').get(email.toLowerCase()) : null;
  const ok = bcrypt.compareSync(password || '', u ? u.password_hash : DUMMY);
  if (!u || !ok) return res.status(401).json({ error: 'Invalid email or password' });
  if (u.status !== 'active') return res.status(403).json({ error: 'Account suspended. Contact support.' });
  res.cookie('qf_token', sign(u), cookieOpts).json({ user: { id: u.id, name: u.name, email: u.email, role: u.role } });
});

router.post('/logout', (req, res) => res.clearCookie('qf_token', { path: '/' }).json({ ok: true }));
router.get('/me', auth, (req, res) => res.json({ user: req.user }));

// No email service is configured, so this records the request for the admin (shown in Admin > Users).
router.post('/forgot', limiter, (req, res) => {
  const { email } = req.body || {};
  if (!emailOk(email)) return res.status(400).json({ error: 'Enter a valid email' });
  if (db.prepare('SELECT 1 FROM users WHERE email=?').get(email.toLowerCase()))
    db.prepare('INSERT INTO reset_requests(email) VALUES(?)').run(email.toLowerCase());
  res.json({ ok: true, message: 'If that account exists, an admin has been notified and will send you a temporary password via Discord support.' });
});

router.put('/password', auth, limiter, (req, res) => {
  const { current, password } = req.body || {};
  const u = db.prepare('SELECT password_hash FROM users WHERE id=?').get(req.user.id);
  if (!bcrypt.compareSync(current || '', u.password_hash)) return res.status(400).json({ error: 'Current password is wrong' });
  if (typeof password !== 'string' || password.length < 8 || password.length > 128) return res.status(400).json({ error: 'New password must be 8-128 characters' });
  db.prepare('UPDATE users SET password_hash=? WHERE id=?').run(bcrypt.hashSync(password, 12), req.user.id);
  res.json({ ok: true });
});

router.put('/profile', auth, (req, res) => {
  const { name } = req.body || {};
  if (typeof name !== 'string' || name.trim().length < 2 || name.length > 80) return res.status(400).json({ error: 'Enter your name' });
  db.prepare('UPDATE users SET name=? WHERE id=?').run(name.trim(), req.user.id);
  res.json({ ok: true });
});
module.exports = router;
