const crypto = require('crypto');
const { vpsKey } = require('../config');
exports.encrypt = (t) => {
  if (!t) return '';
  const iv = crypto.randomBytes(12), c = crypto.createCipheriv('aes-256-gcm', vpsKey, iv);
  const enc = Buffer.concat([c.update(String(t), 'utf8'), c.final()]);
  return [iv, c.getAuthTag(), enc].map((b) => b.toString('base64')).join('.');
};
exports.decrypt = (s) => {
  if (!s) return '';
  try {
    const [iv, tag, enc] = s.split('.').map((x) => Buffer.from(x, 'base64'));
    const d = crypto.createDecipheriv('aes-256-gcm', vpsKey, iv); d.setAuthTag(tag);
    return Buffer.concat([d.update(enc), d.final()]).toString('utf8');
  } catch { return ''; }
};
