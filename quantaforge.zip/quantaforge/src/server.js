const path = require('path');
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const cfg = require('./config');
require('./database/db');

const app = express();
app.set('trust proxy', 1); // behind Nginx
app.use(helmet({ contentSecurityPolicy: { directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"],
  styleSrc: ["'self'", "'unsafe-inline'"], imgSrc: ["'self'", 'data:', 'https:'], connectSrc: ["'self'"], objectSrc: ["'none'"], frameAncestors: ["'none'"] } } }));
app.use(express.json({ limit: '20kb' }));
app.use(cookieParser());
app.use('/api', rateLimit({ windowMs: 60 * 1000, max: 200, standardHeaders: true, legacyHeaders: false }));
// Block cross-site state changes (cookie is SameSite=Strict as well).
app.use('/api', (req, res, next) => {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  const o = req.get('origin');
  if (o && new URL(o).host !== req.get('host')) return res.status(403).json({ error: 'Bad origin' });
  if (!req.is('application/json')) return res.status(415).json({ error: 'JSON required' });
  next();
});

app.use('/api', require('./routes/public').router);
app.use('/api/auth', require('./routes/auth'));
app.use('/api/me', require('./routes/user'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));

app.use(express.static(path.join(__dirname, '..', 'public'), { extensions: ['html'] }));
app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid JSON' });
  console.error(err); res.status(500).json({ error: 'Server error' });
});
app.listen(cfg.port, () => console.log(`QuantaForge on :${cfg.port}`));
