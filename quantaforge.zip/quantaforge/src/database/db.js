const fs = require('fs'), path = require('path');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const cfg = require('../config');

fs.mkdirSync(path.dirname(path.resolve(cfg.dbPath)), { recursive: true });
const db = new Database(cfg.dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY, slug TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
  description TEXT DEFAULT '', announcement TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'unavailable',
  sort INTEGER DEFAULT 0, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS plans(id INTEGER PRIMARY KEY, category_id INTEGER NOT NULL REFERENCES categories(id),
  name TEXT NOT NULL, ram TEXT NOT NULL, cpu TEXT NOT NULL, storage TEXT NOT NULL, price INTEGER NOT NULL,
  active INTEGER NOT NULL DEFAULT 1, sort INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  plan_id INTEGER NOT NULL REFERENCES plans(id), plan_name TEXT NOT NULL, category_name TEXT NOT NULL,
  price INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'pending_payment', admin_notes TEXT DEFAULT '',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP, updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS payments(id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id),
  user_id INTEGER NOT NULL REFERENCES users(id), txn_ref TEXT NOT NULL UNIQUE, amount INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'submitted', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS vps(id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL UNIQUE REFERENCES orders(id),
  user_id INTEGER NOT NULL REFERENCES users(id), ip TEXT DEFAULT '', login_user TEXT DEFAULT '',
  login_password_enc TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'pending', updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  subject TEXT NOT NULL, message TEXT NOT NULL, reply TEXT DEFAULT '', status TEXT NOT NULL DEFAULT 'open',
  created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL DEFAULT '');
CREATE TABLE IF NOT EXISTS reset_requests(id INTEGER PRIMARY KEY, email TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);

function seed() {
  const defaults = { site_name: 'QuantaForge', logo_url: '', discord_url: 'https://discord.gg/your-invite',
    announcement: '', maintenance: '0' };
  const ins = db.prepare('INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)');
  for (const [k, v] of Object.entries(defaults)) ins.run(k, v);

  if (!db.prepare('SELECT COUNT(*) n FROM categories').get().n) {
    // Prices are the exact figures from the spec. CPU/storage are placeholders: edit in Admin > Plans.
    const cats = [
      ['intel', 'Intel Platinum', 'Reliable Intel Platinum servers for everyday workloads.', 'available', [
        ['2GiB', 249, '1 vCPU', '30 GB NVMe'], ['4GiB', 299, '2 vCPU', '50 GB NVMe'], ['8GiB', 399, '3 vCPU', '80 GB NVMe'],
        ['16GiB', 799, '4 vCPU', '150 GB NVMe'], ['24GiB', 1199, '6 vCPU', '200 GB NVMe'], ['64GiB Ultra', 3899, '12 vCPU', '500 GB NVMe']]],
      ['epyc', 'AMD EPYC', 'High core-count AMD EPYC servers for heavy multi-tasking.', 'coming_soon', [
        ['2GiB', 399, '1 vCPU', '30 GB NVMe'], ['4GiB', 449, '2 vCPU', '50 GB NVMe'], ['8GiB', 599, '3 vCPU', '80 GB NVMe'],
        ['16GiB', 1199, '4 vCPU', '150 GB NVMe'], ['24GiB', 1699, '6 vCPU', '200 GB NVMe']]],
      ['ryzen', 'AMD Ryzen 5/7', 'Best single-thread speed for game servers and bots.', 'coming_soon', [
        ['2GiB', 599, '1 vCPU', '30 GB NVMe'], ['4GiB', 699, '2 vCPU', '50 GB NVMe'], ['8GiB', 899, '3 vCPU', '80 GB NVMe'],
        ['16GiB', 1599, '4 vCPU', '150 GB NVMe'], ['24GiB', 1999, '6 vCPU', '200 GB NVMe']]],
    ];
    const ic = db.prepare('INSERT INTO categories(slug,name,description,status,sort) VALUES(?,?,?,?,?)');
    const ip = db.prepare('INSERT INTO plans(category_id,name,ram,cpu,storage,price,sort) VALUES(?,?,?,?,?,?,?)');
    db.transaction(() => cats.forEach(([slug, name, desc, st, plans], i) => {
      const id = ic.run(slug, name, desc, st, i).lastInsertRowid;
      plans.forEach(([ram, price, cpu, storage], j) => ip.run(id, `${name} ${ram}`, ram, cpu, storage, price, j));
    }))();
  }

  if (cfg.adminEmail && cfg.adminPassword && !db.prepare("SELECT 1 FROM users WHERE role='admin'").get()) {
    if (cfg.adminPassword.length < 10) throw new Error('ADMIN_PASSWORD must be at least 10 characters');
    db.prepare("INSERT INTO users(name,email,password_hash,role) VALUES('Admin',?,?, 'admin')")
      .run(cfg.adminEmail.toLowerCase(), bcrypt.hashSync(cfg.adminPassword, 12));
    console.log('Admin account created:', cfg.adminEmail);
  }
}
seed();
module.exports = db;
