require('./db'); console.log('Database initialised at', require('../config').dbPath);
