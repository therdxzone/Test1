# PunchTrack

Attendance and salary management (Next.js, Prisma, PostgreSQL). **Phases 1-4 written:** foundation, auth, storage, Render blueprint, registration, profiles, approvals, users, two-level attendance, salary, branding, announcements, reports (CSV/Excel), admin settings, activity logs. **Not yet built or run end to end:** see Status below.

## Deploy

1. Push this folder to your own GitHub repo.
2. Replace `YOUR_USER/YOUR_REPO` below, then click the button.

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://render.com/deploy?repo=https://github.com/YOUR_USER/YOUR_REPO)

Render reads `render.yaml`, creates the web service, PostgreSQL database and persistent disk, generates `SESSION_SECRET`, builds, and starts the app. On start it syncs the schema, creates storage folders and creates the first admin only if no admin exists.

## First login

Username `admin`, password `admin`. You are forced to choose a new username and password immediately. Do this before sharing the URL.

## Costs

The persistent disk (uploaded images) requires a paid web service plan; the blueprint uses `starter`, plus a paid PostgreSQL plan (`basic-256mb`) and disk storage. Prices and plan names change: check https://render.com/pricing. Free tier is not used, because files would be lost on redeploy.

## Notes

- Database setup uses `prisma db push` (safe: it refuses destructive changes). Run `npx prisma migrate dev --name init` once locally if you want versioned migration files.
- Images live in `/var/data/uploads` and are only served through `/api/files/...`, which checks the session and role on every request.
- Health check: `/api/health`.

## Local development

`DATABASE_URL=postgresql://... SESSION_SECRET=anything npm install && npx prisma db push && node scripts/init.mjs && npm run dev`

## Status

Phase 4 code was written without being able to install packages or run `next build` in the authoring environment. Before relying on it: run `npm install && npm run build`, fix any type errors, then walk through the 21-item test list.
