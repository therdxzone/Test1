// Runs on every start. Idempotent: never recreates or resets an existing admin.
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import fs from "node:fs";
import path from "node:path";

const prisma = new PrismaClient();
const storage = process.env.STORAGE_DIR || "./storage";
for (const d of ["faces", "qr", "punch", "proofs", "branding"]) {
  fs.mkdirSync(path.join(storage, d), { recursive: true });
}
const adminExists = await prisma.user.count({ where: { role: "ADMIN" } });
if (adminExists === 0) {
  await prisma.user.create({
    data: {
      username: "admin", fullName: "Administrator",
      passwordHash: await bcrypt.hash("admin", 12),
      role: "ADMIN", status: "ACTIVE", mustChangeCredentials: true,
    },
  });
  console.log("Initial admin created (admin/admin). Change it at first login.");
}
await prisma.brandingSetting.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } });
await prisma.adminSetting.upsert({ where: { id: 1 }, update: {}, create: { id: 1 } });
await prisma.$disconnect();
