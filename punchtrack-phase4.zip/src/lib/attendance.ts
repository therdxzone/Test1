import { prisma } from "./db";

const DEFAULTS = { id: 1, timezone: "Asia/Kolkata", halfDayRule: "Half Day requires an accepted morning photo only.", resubmitAllowed: true };
export async function getSettings() {
  return (await prisma.adminSetting.findUnique({ where: { id: 1 } })) ?? DEFAULTS;
}
/** YYYY-MM-DD in the configured timezone. The date flips automatically at local midnight. */
export function dateInTz(d: Date, tz: string) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
}
export async function todayStr() {
  const s = await getSettings();
  return dateInTz(new Date(), s.timezone);
}
export function fmtTime(d: Date, tz: string) {
  return d.toLocaleString("en-GB", { timeZone: tz, dateStyle: "medium", timeStyle: "short" });
}
/** Full Day needs both photos; Half Day needs the morning photo only (the default half-day policy). */
export function isComplete(type: "FULL" | "HALF", slots: string[]) {
  return slots.includes("MORNING") && (type === "HALF" || slots.includes("EVENING"));
}
export function rejectionMessage(date: string, today: string, reason: string, by: string) {
  const when = date === today
    ? "Please upload valid photos before 12:00 AM today."
    : `The deadline for ${date} has passed, so it cannot be resubmitted.`;
  return `Your attendance submission for ${date} has been rejected by the ${by}. ${when} Reason: ${reason}`;
}
export function validMonth(m: string | undefined | null) {
  return m && /^\d{4}-(0[1-9]|1[0-2])$/.test(m) ? m : null;
}
