import { prisma } from "./db";
import { getSettings, dateInTz } from "./attendance";

export async function monthlyReport(month: string) {
  const tz = (await getSettings()).timezone, today = dateInTz(new Date(), tz);
  const users = await prisma.user.findMany({
    where: { role: "USER" }, orderBy: { fullName: "asc" },
    include: {
      attendance: { where: { date: { startsWith: month } }, include: { photos: true } },
      salaries: { where: { month } },
    },
  });
  const attendance = users.map((u) => {
    const ok = u.attendance.filter((a) => a.status === "APPROVED");
    const rej = u.attendance.filter((a) => a.status === "REJECTED" || a.status === "VERIFIER_REJECTED");
    return {
      name: u.fullName, email: u.email ?? "", userStatus: u.status,
      fullDays: ok.filter((a) => a.type === "FULL").length, halfDays: ok.filter((a) => a.type === "HALF").length,
      rejectedPhotos: rej.reduce((n, a) => n + a.photos.length, 0),
      incompleteDays: u.attendance.filter((a) => a.date < today && a.status !== "APPROVED").length,
    };
  });
  const salary = users.flatMap((u) => u.salaries.map((s) => ({
    name: u.fullName, email: u.email ?? "", month: s.month, amount: Number(s.amount), status: s.status,
    paymentDate: s.paymentDate ? s.paymentDate.toISOString().slice(0, 10) : "", notes: s.notes ?? "",
  })));
  return { attendance, salary };
}

// Neutralise spreadsheet formula injection and quote CSV fields.
export const csvCell = (v: unknown) => {
  let s = String(v ?? ""); if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return `"${s.replace(/"/g, '""')}"`;
};
export const safeCell = (v: unknown) => (typeof v === "string" && /^[=+\-@\t\r]/.test(v) ? "'" + v : v);
