import { prisma } from "./db";
export async function getBranding() {
  return (await prisma.brandingSetting.findUnique({ where: { id: 1 } })) ?? {
    id: 1, siteName: "PunchTrack", logoPath: null, faviconPath: null,
    primaryColor: "#1f6f5c", secondaryColor: "#e8f1ee", sidebarColor: "#14332b",
    loginTagline: "Attendance and salary, in one place.",
  };
}
