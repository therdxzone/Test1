import crypto from "crypto";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import type { Role } from "@prisma/client";
import { prisma } from "./db";

export const COOKIE = "pt_session";
const SESSION_DAYS = 7;

const hash = (t: string) =>
  crypto.createHmac("sha256", process.env.SESSION_SECRET || "dev-secret").update(t).digest("hex");

export async function createSession(userId: string) {
  const token = crypto.randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 864e5);
  await prisma.session.create({ data: { tokenHash: hash(token), userId, expiresAt } });
  cookies().set(COOKIE, token, {
    httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production",
    path: "/", expires: expiresAt,
  });
}

export async function destroySession() {
  const t = cookies().get(COOKIE)?.value;
  if (t) await prisma.session.deleteMany({ where: { tokenHash: hash(t) } });
  cookies().delete(COOKIE);
}

export async function getCurrentUser() {
  const t = cookies().get(COOKIE)?.value;
  if (!t) return null;
  const s = await prisma.session.findUnique({ where: { tokenHash: hash(t) }, include: { user: true } });
  if (!s || s.expiresAt < new Date()) return null;
  return s.user;
}

/** Server-side guard. Role and status always come from the database, never the browser. */
export async function requireRole(role: Role) {
  const u = await getCurrentUser();
  if (!u) redirect("/login");
  if (u.mustChangeCredentials) redirect("/change-credentials");
  if (u.role !== role) redirect("/");
  return u;
}

export const homeFor = (r: Role) => (r === "ADMIN" ? "/admin" : r === "VERIFIER" ? "/verifier" : "/dashboard");

/** CSRF defence for mutating API calls: Origin must match Host (plus SameSite=Lax cookies). */
export function sameOrigin(req: Request) {
  const origin = req.headers.get("origin");
  const host = req.headers.get("host");
  if (!origin || !host) return false;
  try { return new URL(origin).host === host; } catch { return false; }
}

export async function audit(actorId: string | null, action: string, target?: string, detail?: string) {
  await prisma.auditLog.create({ data: { actorId, action, target, detail } });
}

/** API guard: origin check on writes, then role from the database. */
export async function guardApi(req: Request, role: Role) {
  if (req.method !== "GET" && !sameOrigin(req)) return { error: Response.json({ error: "Bad origin." }, { status: 403 }), user: null };
  const u = await getCurrentUser();
  if (!u || u.role !== role || u.mustChangeCredentials || u.status === "SUSPENDED")
    return { error: Response.json({ error: "Not allowed." }, { status: 403 }), user: null };
  return { error: null, user: u };
}

/** Page guard for end users (suspended users have no sessions, but check anyway). */
export async function requireUser() {
  const u = await getCurrentUser();
  if (!u) redirect("/login");
  if (u.role === "ADMIN") redirect("/admin");
  if (u.role === "VERIFIER") redirect("/verifier");
  if (u.status === "SUSPENDED") redirect("/login");
  return u;
}

export async function notify(userId: string, title: string, body: string) {
  await prisma.notification.create({ data: { userId, title, body } });
}
export async function notifyAdmins(title: string, body: string) {
  const admins = await prisma.user.findMany({ where: { role: "ADMIN" }, select: { id: true } });
  await prisma.notification.createMany({ data: admins.map((a) => ({ userId: a.id, title, body })) });
}
