import crypto from "crypto";
import fs from "node:fs/promises";
import path from "node:path";

export const STORAGE_DIR = process.env.STORAGE_DIR || "./storage";
export const MAX_IMAGE_BYTES = 5 * 1024 * 1024;
export type Folder = "faces" | "qr" | "punch" | "proofs" | "branding";

function sniff(b: Buffer): { mime: string; ext: string } | null {
  if (b.length > 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { mime: "image/jpeg", ext: "jpg" };
  if (b.length > 8 && b.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return { mime: "image/png", ext: "png" };
  if (b.length > 12 && b.subarray(0, 4).toString() === "RIFF" && b.subarray(8, 12).toString() === "WEBP") return { mime: "image/webp", ext: "webp" };
  return null;
}

/** Validates size and real file type (magic bytes, not the client's claim), then stores under a random name. */
export async function saveImage(file: File, folder: Folder) {
  if (file.size > MAX_IMAGE_BYTES) throw new Error("Image must be 5 MB or smaller.");
  const buf = Buffer.from(await file.arrayBuffer());
  const kind = sniff(buf);
  if (!kind) throw new Error("Only JPEG, PNG or WebP images are allowed.");
  const rel = `${folder}/${crypto.randomUUID()}.${kind.ext}`;
  const full = path.join(STORAGE_DIR, rel);
  await fs.mkdir(path.dirname(full), { recursive: true });
  await fs.writeFile(full, buf);
  return { path: rel, mime: kind.mime, size: buf.length };
}

export async function readStored(rel: string) {
  const full = path.resolve(STORAGE_DIR, rel);
  if (!full.startsWith(path.resolve(STORAGE_DIR) + path.sep)) throw new Error("bad path");
  return fs.readFile(full);
}

export async function deleteStored(rel?: string | null) {
  if (!rel) return;
  try {
    const full = path.resolve(STORAGE_DIR, rel);
    if (full.startsWith(path.resolve(STORAGE_DIR) + path.sep)) await fs.unlink(full);
  } catch {}
}
