import { prisma } from "./db";
export async function userLinks(userId: string, active: boolean) {
  const unread = await prisma.notification.count({ where: { userId, read: false } });
  const base = [{ href: "/dashboard", label: "Dashboard" }];
  const work = active ? [
    { href: "/dashboard/punch", label: "Daily Punch" },
    { href: "/dashboard/history", label: "Attendance History" },
    { href: "/dashboard/salary", label: "My Salary" },
  ] : [];
  return [
    ...base, ...work,
    { href: "/dashboard/profile", label: "My Profile" },
    { href: "/dashboard/notifications", label: "Notifications", badge: unread },
  ];
}
export async function verifierLinks(userId: string) {
  const [unread, pending] = await Promise.all([
    prisma.notification.count({ where: { userId, read: false } }),
    prisma.attendance.count({ where: { status: "SUBMITTED", user: { assignedTo: { verifierId: userId } } } }),
  ]);
  return [
    { href: "/verifier", label: "Dashboard", badge: pending },
    { href: "/dashboard/notifications", label: "Notifications", badge: unread },
  ];
}
export async function adminLinks(userId: string) {
  const [unread, pending, finals] = await Promise.all([
    prisma.notification.count({ where: { userId, read: false } }),
    prisma.profile.count({ where: { status: "SUBMITTED" } }),
    prisma.attendance.count({ where: { status: "VERIFIER_ACCEPTED" } }),
  ]);
  return [
    { href: "/admin", label: "Dashboard" },
    { href: "/admin/users", label: "Users" },
    { href: "/admin/pending", label: "Pending Profiles", badge: pending },
    { href: "/admin/verifiers", label: "Verifiers" },
    { href: "/admin/attendance", label: "Attendance" },
    { href: "/admin/approvals", label: "Final Approvals", badge: finals },
    { href: "/admin/salary", label: "Salary Management" },
    { href: "/admin/notifications", label: "Announcements" },
    { href: "/dashboard/notifications", label: "Notifications", badge: unread },
    { href: "/admin/reports", label: "Reports" },
    { href: "/admin/branding", label: "Branding Settings" },
    { href: "/admin/settings", label: "Admin Settings" },
    { href: "/admin/logs", label: "Activity Logs" },
  ];
}
