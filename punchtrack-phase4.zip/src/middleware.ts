import { NextResponse, type NextRequest } from "next/server";
// Cheap gate only (edge can't reach the DB). Real checks happen server-side in requireRole().
export function middleware(req: NextRequest) {
  if (!req.cookies.get("pt_session")) return NextResponse.redirect(new URL("/login", req.url));
  return NextResponse.next();
}
export const config = { matcher: ["/admin/:path*", "/dashboard/:path*", "/verifier/:path*", "/change-credentials"] };
