import { getBranding } from "@/lib/branding";
import LogoutButton from "@/app/LogoutButton";
import ThemeToggle from "@/components/ThemeToggle";

export default async function Shell({ links, who, children }: {
  links: { href: string; label: string; badge?: number }[]; who: string; children: React.ReactNode;
}) {
  const b = await getBranding();
  return (
    <div className="md:flex">
      <nav style={{ background: b.sidebarColor }} className="text-white md:w-56 md:min-h-screen md:sticky md:top-0 md:self-start">
        <div className="px-4 pt-3 md:pt-6 font-bold text-lg flex items-center gap-2">{b.logoPath && <img src="/api/branding/logo" alt="" className="h-7 w-auto" />}{b.siteName}</div>
        <ul className="flex md:flex-col gap-1 overflow-x-auto px-2 py-2 md:py-4">
          {links.map((l) => (
            <li key={l.href} className="shrink-0">
              <a href={l.href} className="block rounded-md px-3 py-2 text-sm hover:bg-white/10 focus-visible:outline focus-visible:outline-2 focus-visible:outline-white">
                {l.label}{l.badge ? <span className="ml-2 rounded-full bg-white text-black px-2 text-xs">{l.badge}</span> : null}
              </a>
            </li>
          ))}
        </ul>
        <div className="hidden md:block px-4 pt-4 text-sm opacity-80">{who}</div>
        <div className="px-4 pb-3 md:pt-1 text-sm flex gap-4 [&_button]:text-white"><ThemeToggle /><LogoutButton /></div>
      </nav>
      <main className="flex-1 min-w-0 px-4 py-6 md:px-8 max-w-5xl">{children}</main>
    </div>
  );
}
