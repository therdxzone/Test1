"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export function ActionButton({ url, method = "POST", body, label, confirmText, danger }: {
  url: string; method?: string; body?: unknown; label: string; confirmText?: string; danger?: boolean;
}) {
  const router = useRouter(); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  async function go() {
    if (confirmText && !window.confirm(confirmText)) return;
    setBusy(true); setErr("");
    const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body ?? {}) });
    if (!r.ok) setErr((await r.json().catch(() => ({}))).error || "Failed.");
    setBusy(false); router.refresh();
  }
  return (<span><button onClick={go} disabled={busy}
    className={`rounded-md px-3 py-2 text-sm font-semibold text-white disabled:opacity-60 ${danger ? "bg-red-600" : "bg-brand"}`}>{busy ? "Working…" : label}</button>
    {err && <span role="alert" className="ml-2 text-sm text-red-600">{err}</span>}</span>);
}

export function ReviewProfile({ userId }: { userId: string }) {
  const router = useRouter(); const [reason, setReason] = useState(""); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  async function send(action: "approve" | "reject") {
    if (action === "reject" && !reason.trim()) { setErr("Enter a reason for rejecting."); return; }
    if (!window.confirm(action === "approve" ? "Approve this profile?" : "Reject this profile?")) return;
    setBusy(true); setErr("");
    const r = await fetch(`/api/admin/profiles/${userId}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, reason }) });
    if (!r.ok) setErr((await r.json().catch(() => ({}))).error || "Failed.");
    setBusy(false); router.refresh();
  }
  return (
    <div className="space-y-2">
      <input className="input" placeholder="Reason (required to reject)" value={reason} onChange={(e) => setReason(e.target.value)} />
      <div className="flex gap-2">
        <button disabled={busy} onClick={() => send("approve")} className="rounded-md bg-brand px-3 py-2 text-sm font-semibold text-white">Approve</button>
        <button disabled={busy} onClick={() => send("reject")} className="rounded-md bg-red-600 px-3 py-2 text-sm font-semibold text-white">Reject</button>
      </div>
      {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
    </div>
  );
}

export function EditUser({ id, fullName, email, googlePay, otherPayment }: { id: string; fullName: string; email: string; googlePay: boolean; otherPayment: boolean }) {
  const router = useRouter(); const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  async function save(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMsg("");
    const f = new FormData(e.currentTarget);
    const r = await fetch(`/api/admin/users/${id}`, { method: "PATCH", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fullName: f.get("fullName"), email: f.get("email"), googlePay: f.get("googlePay") === "on", otherPayment: f.get("otherPayment") === "on" }) });
    setMsg(r.ok ? "Saved." : (await r.json().catch(() => ({}))).error || "Failed."); setBusy(false); router.refresh();
  }
  return (
    <form onSubmit={save} className="space-y-3">
      <input name="fullName" defaultValue={fullName} className="input" required aria-label="Full name" />
      <input name="email" type="email" defaultValue={email} className="input" required aria-label="Email" />
      <label className="flex gap-2 text-sm"><input type="checkbox" name="googlePay" defaultChecked={googlePay} /> Google Pay available</label>
      <label className="flex gap-2 text-sm"><input type="checkbox" name="otherPayment" defaultChecked={otherPayment} /> Other payment method available</label>
      <button className="btn sm:w-auto" disabled={busy}>{busy ? "Saving…" : "Save changes"}</button>
      {msg && <p role="status" className="text-sm">{msg}</p>}
    </form>
  );
}

export function MarkRead() {
  const router = useRouter();
  return <button className="text-sm underline" onClick={async () => { await fetch("/api/notifications", { method: "POST" }); router.refresh(); }}>Mark all as read</button>;
}
