"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

type B = { siteName: string; loginTagline: string; primaryColor: string; secondaryColor: string; sidebarColor: string; logo: boolean; favicon: boolean };
export default function BrandingForm({ b }: { b: B }) {
  const router = useRouter(); const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  async function save(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMsg("");
    const r = await fetch("/api/admin/branding", { method: "POST", body: new FormData(e.currentTarget) });
    setMsg(r.ok ? "Saved. Branding updated everywhere." : (await r.json().catch(() => ({}))).error || "Failed.");
    setBusy(false); router.refresh();
  }
  const color = (name: string, label: string, v: string) => <label className="text-sm">{label}<input type="color" name={name} defaultValue={v} className="input !p-1 h-11" /></label>;
  return (
    <form onSubmit={save} className="card p-4 grid gap-3 sm:grid-cols-2">
      <label className="text-sm sm:col-span-2">Website name<input name="siteName" required maxLength={40} defaultValue={b.siteName} className="input" /></label>
      <label className="text-sm sm:col-span-2">Login page tagline<input name="loginTagline" maxLength={120} defaultValue={b.loginTagline} className="input" /></label>
      {color("primaryColor", "Primary color", b.primaryColor)}{color("secondaryColor", "Secondary color", b.secondaryColor)}{color("sidebarColor", "Sidebar color", b.sidebarColor)}
      <div />
      <div className="text-sm">Logo (JPEG/PNG/WebP, max 5 MB){b.logo && <img src="/api/branding/logo" alt="Current logo" className="h-12 my-2" />}
        <input type="file" name="logo" accept="image/jpeg,image/png,image/webp" className="input" />
        {b.logo && <label className="flex gap-2 mt-1"><input type="checkbox" name="remove_logo" /> Remove logo</label>}</div>
      <div className="text-sm">Favicon{b.favicon && <img src="/api/branding/favicon" alt="Current favicon" className="h-8 my-2" />}
        <input type="file" name="favicon" accept="image/jpeg,image/png,image/webp" className="input" />
        {b.favicon && <label className="flex gap-2 mt-1"><input type="checkbox" name="remove_favicon" /> Remove favicon</label>}</div>
      <div className="sm:col-span-2"><button className="btn sm:w-auto" disabled={busy}>{busy ? "Saving…" : "Save branding"}</button>{msg && <p role="status" className="text-sm mt-2">{msg}</p>}</div>
    </form>
  );
}
