const tone: Record<string, string> = {
  ACTIVE: "bg-green-100 text-green-800", APPROVED: "bg-green-100 text-green-800", PAID: "bg-green-100 text-green-800",
  ACCEPTED: "bg-green-100 text-green-800", VERIFIER_ACCEPTED: "bg-blue-100 text-blue-800",
  PENDING: "bg-amber-100 text-amber-800", SUBMITTED: "bg-amber-100 text-amber-800", OPEN: "bg-gray-200 text-gray-800", DRAFT: "bg-gray-200 text-gray-800",
  SUSPENDED: "bg-red-100 text-red-800", REJECTED: "bg-red-100 text-red-800", VERIFIER_REJECTED: "bg-red-100 text-red-800",
};
const label = (v: string) => { const t = v.replace(/_/g, " ").toLowerCase(); return t.charAt(0).toUpperCase() + t.slice(1); };
export default function Badge({ value }: { value: string }) {
  return <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${tone[value] ?? "bg-gray-200 text-gray-800"}`}>{label(value)}</span>;
}
