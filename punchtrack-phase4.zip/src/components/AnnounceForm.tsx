"use client";
import { useState } from "react";
export default function AnnounceForm() {
  const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  async function send(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); const form = e.currentTarget; const f = new FormData(form);
    if (!window.confirm("Send this announcement now?")) return;
    setBusy(true); setMsg("");
    const r = await fetch("/api/admin/announce", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ title: f.get("title"), body: f.get("body"), audience: f.get("audience") }) });
    const j = await r.json().catch(() => ({}));
    if (r.ok) { setMsg(`Sent to ${j.sent} recipient(s).`); form.reset(); } else setMsg(j.error || "Failed.");
    setBusy(false);
  }
  return (
    <form onSubmit={send} className="card p-4 space-y-3">
      <input name="title" className="input" placeholder="Title" required maxLength={100} aria-label="Title" />
      <textarea name="body" className="input" rows={4} placeholder="Message" required maxLength={1000} aria-label="Message" />
      <select name="audience" className="input" aria-label="Audience"><option value="USERS">All users</option><option value="VERIFIERS">All verifiers</option><option value="ALL">Users and verifiers</option></select>
      <button className="btn sm:w-auto" disabled={busy}>{busy ? "Sending…" : "Send announcement"}</button>{msg && <p role="status" className="text-sm">{msg}</p>}
    </form>
  );
}
