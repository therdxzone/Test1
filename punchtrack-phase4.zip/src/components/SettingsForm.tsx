"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export default function SettingsForm({ timezone, halfDayRule, resubmitAllowed }: { timezone: string; halfDayRule: string; resubmitAllowed: boolean }) {
  const router = useRouter(); const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  async function save(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMsg(""); const f = new FormData(e.currentTarget);
    const r = await fetch("/api/admin/settings", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ timezone: f.get("timezone"), halfDayRule: f.get("halfDayRule"), resubmitAllowed: f.get("resubmitAllowed") === "on" }) });
    setMsg(r.ok ? "Saved." : (await r.json().catch(() => ({}))).error || "Failed."); setBusy(false); router.refresh();
  }
  return (
    <form onSubmit={save} className="card p-4 space-y-3">
      <label className="text-sm block">Timezone (IANA name, e.g. Asia/Kolkata). The daily deadline is midnight in this zone.<input name="timezone" defaultValue={timezone} required className="input mt-1" /></label>
      <label className="text-sm block">Half-day policy (shown to staff)<input name="halfDayRule" defaultValue={halfDayRule} required maxLength={300} className="input mt-1" /></label>
      <label className="flex gap-2 text-sm"><input type="checkbox" name="resubmitAllowed" defaultChecked={resubmitAllowed} /> Allow resubmission after a rejection (before the deadline)</label>
      <button className="btn sm:w-auto" disabled={busy}>{busy ? "Saving…" : "Save settings"}</button>{msg && <p role="status" className="text-sm">{msg}</p>}
    </form>
  );
}
