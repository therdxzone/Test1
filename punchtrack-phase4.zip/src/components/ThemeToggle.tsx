"use client";
import { useEffect, useState } from "react";
export default function ThemeToggle() {
  const [dark, setDark] = useState(false);
  useEffect(() => { setDark(document.documentElement.dataset.theme === "dark"); }, []);
  function flip() {
    const next = dark ? "light" : "dark";
    document.documentElement.dataset.theme = next;
    try { localStorage.setItem("pt_theme", next); } catch {}
    setDark(!dark);
  }
  return <button onClick={flip} className="text-sm underline" aria-label="Toggle light or dark mode">{dark ? "Light mode" : "Dark mode"}</button>;
}
