"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function SalaryForm({ users, month, initial }: {
  users: { id: string; name: string }[]; month: string;
  initial?: { userId: string; amount: string; paymentDate: string; status: string; notes: string };
}) {
  const router = useRouter(); const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  async function save(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setMsg("");
    const form = e.currentTarget;
    const r = await fetch("/api/admin/salary", { method: "POST", body: new FormData(form) });
    if (r.ok) { setMsg("Saved."); form.reset(); router.refresh(); } else setMsg((await r.json().catch(() => ({}))).error || "Failed.");
    setBusy(false);
  }
  return (
    <form onSubmit={save} className="card p-4 grid gap-3 sm:grid-cols-2 mb-6">
      <label className="text-sm">User<select name="userId" required defaultValue={initial?.userId ?? ""} className="input"><option value="" disabled>Select user</option>{users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select></label>
      <label className="text-sm">Month<input type="month" name="month" required defaultValue={month} className="input" /></label>
      <label className="text-sm">Amount<input type="number" step="0.01" min="0" name="amount" required defaultValue={initial?.amount} className="input" /></label>
      <label className="text-sm">Payment date<input type="date" name="paymentDate" defaultValue={initial?.paymentDate} className="input" /></label>
      <label className="text-sm">Status<select name="status" defaultValue={initial?.status ?? "PENDING"} className="input"><option value="PENDING">Pending</option><option value="PAID">Paid</option></select></label>
      <label className="text-sm">Payment proof (JPEG/PNG/WebP, max 5 MB)<input type="file" name="proof" accept="image/jpeg,image/png,image/webp" className="input" /></label>
      <label className="text-sm sm:col-span-2">Notes (optional)<input name="notes" maxLength={500} defaultValue={initial?.notes} className="input" /></label>
      <div className="sm:col-span-2"><button className="btn sm:w-auto" disabled={busy}>{busy ? "Saving…" : "Save salary record"}</button>{msg && <p role="status" className="text-sm mt-2">{msg}</p>}</div>
    </form>
  );
}
