"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

async function call(url: string, method: string, body?: unknown) {
  const r = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  return r.ok ? "" : ((await r.json().catch(() => ({}))).error as string) || "Failed.";
}

export function CreateVerifier() {
  const router = useRouter(); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setErr("");
    const form = e.currentTarget; const f = new FormData(form);
    const m = await call("/api/admin/verifiers", "POST", { username: f.get("username"), fullName: f.get("fullName"), password: f.get("password") });
    setErr(m); setBusy(false); if (!m) { form.reset(); router.refresh(); }
  }
  return (
    <form onSubmit={submit} className="card p-4 space-y-3 mb-6">
      <h2 className="font-semibold">Create verifier</h2>
      <input name="fullName" className="input" placeholder="Full name" required aria-label="Full name" />
      <input name="username" className="input" placeholder="Username" required aria-label="Username" autoCapitalize="none" />
      <input name="password" type="password" className="input" placeholder="Initial password (min 8)" required minLength={8} aria-label="Initial password" autoComplete="new-password" />
      <button className="btn sm:w-auto" disabled={busy}>{busy ? "Creating…" : "Create verifier"}</button>
      {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
    </form>
  );
}

export function VerifierActions({ id, suspended }: { id: string; suspended: boolean }) {
  const router = useRouter(); const [err, setErr] = useState(""); const [pw, setPw] = useState("");
  async function run(fn: () => Promise<string>) { setErr(await fn()); router.refresh(); }
  const b = "rounded-md px-3 py-2 text-sm font-semibold text-white";
  return (
    <div className="space-y-2 mt-3">
      <div className="flex gap-2">
        <input type="password" className="input" placeholder="New password (min 8)" value={pw} onChange={(e) => setPw(e.target.value)} aria-label="New password" autoComplete="new-password" />
        <button className={`${b} bg-brand shrink-0`} onClick={() => run(async () => { const m = await call(`/api/admin/verifiers/${id}`, "PATCH", { action: "password", password: pw }); if (!m) setPw(""); return m; })}>Set</button>
      </div>
      <div className="flex gap-2">
        <button className={`${b} ${suspended ? "bg-brand" : "bg-amber-600"}`}
          onClick={() => { if (window.confirm(suspended ? "Reactivate this verifier?" : "Suspend this verifier? They will be signed out.")) run(() => call(`/api/admin/verifiers/${id}`, "PATCH", { action: suspended ? "reactivate" : "suspend" })); }}>
          {suspended ? "Reactivate" : "Suspend"}</button>
        <button className={`${b} bg-red-600`} onClick={() => { if (window.confirm("Delete this verifier permanently?")) run(() => call(`/api/admin/verifiers/${id}`, "DELETE")); }}>Delete</button>
      </div>
      {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
    </div>
  );
}

export function AssignSelect({ userId, current, verifiers }: { userId: string; current: string | null; verifiers: { id: string; name: string }[] }) {
  const router = useRouter(); const [err, setErr] = useState("");
  async function change(v: string) { setErr(await call("/api/admin/assignments", "POST", { userId, verifierId: v || null })); router.refresh(); }
  return (
    <span>
      <select className="input !w-auto !py-1.5 text-sm" defaultValue={current ?? ""} onChange={(e) => change(e.target.value)} aria-label="Assigned verifier">
        <option value="">Unassigned</option>
        {verifiers.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
      </select>
      {err && <span role="alert" className="ml-2 text-sm text-red-600">{err}</span>}
    </span>
  );
}
