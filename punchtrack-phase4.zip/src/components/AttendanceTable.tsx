import Badge from "./Badge";
import { fmtTime } from "@/lib/attendance";

type Row = {
  id: string; user?: { fullName: string }; date: string; type: string; status: string;
  photos: { id: string; slot: string; capturedAt: Date }[];
  review: { decision: string; comment: string | null; decidedAt: Date } | null;
  approval: { decision: string; comment: string | null; decidedAt: Date } | null;
};

export function PhotoPair({ photos, tz }: { photos: Row["photos"]; tz: string }) {
  return (
    <div className="grid grid-cols-2 gap-2">
      {(["MORNING", "EVENING"] as const).map((slot) => {
        const p = photos.find((x) => x.slot === slot);
        return (
          <div key={slot}>
            <div className="text-xs muted mb-1">{slot === "MORNING" ? "Morning" : "Evening"}</div>
            {p ? (
              <a href={`/api/files/punch/${p.id}`} target="_blank" rel="noreferrer">
                <img src={`/api/files/punch/${p.id}`} alt={`${slot.toLowerCase()} punch photo`} loading="lazy" className="h-32 w-full rounded-lg object-cover" />
                <span className="text-xs muted">{fmtTime(p.capturedAt, tz)}</span>
              </a>
            ) : <div className="h-32 rounded-lg border border-dashed border-[var(--line)] grid place-items-center text-xs muted">No photo</div>}
          </div>
        );
      })}
    </div>
  );
}

export default function AttendanceTable({ rows, tz, empty = "No attendance records." }: { rows: Row[]; tz: string; empty?: string }) {
  if (rows.length === 0) return <p className="card p-4 muted">{empty}</p>;
  return (
    <div className="space-y-3">
      {rows.map((a) => (
        <div key={a.id} className="card p-4">
          <div className="flex flex-wrap items-center gap-2 mb-3">
            {a.user && <span className="font-semibold">{a.user.fullName}</span>}
            <span className={a.user ? "muted text-sm" : "font-semibold"}>{a.date}</span>
            <span className="text-sm muted">{a.type === "FULL" ? "Full day" : "Half day"}</span>
            <Badge value={a.status} />
          </div>
          <PhotoPair photos={a.photos} tz={tz} />
          <div className="text-sm mt-3 space-y-1">
            <div>Verifier: {a.review ? <><Badge value={a.review.decision} /> {a.review.comment && <span className="muted">— {a.review.comment}</span>}</> : <span className="muted">no decision yet</span>}</div>
            <div>Admin final: {a.approval ? <><Badge value={a.approval.decision} /> {a.approval.comment && <span className="muted">— {a.approval.comment}</span>}</> : <span className="muted">no decision yet</span>}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
