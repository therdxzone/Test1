"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

/** Accept/Reject control used by verifiers (level 1) and admin (level 2). */
export default function Decision({ url, acceptLabel = "Accept" }: { url: string; acceptLabel?: string }) {
  const router = useRouter();
  const [comment, setComment] = useState(""); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  async function send(action: "accept" | "reject") {
    if (action === "reject" && !comment.trim()) { setErr("Enter a reason for rejecting."); return; }
    if (!window.confirm(action === "accept" ? `${acceptLabel} this attendance?` : "Reject this attendance?")) return;
    setBusy(true); setErr("");
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ action, comment }) });
    if (!r.ok) setErr((await r.json().catch(() => ({}))).error || "Failed.");
    setBusy(false); router.refresh();
  }
  return (
    <div className="space-y-2 mt-3">
      <input className="input" placeholder="Comment (required to reject)" value={comment} maxLength={500} onChange={(e) => setComment(e.target.value)} aria-label="Comment" />
      <div className="flex gap-2">
        <button disabled={busy} onClick={() => send("accept")} className="rounded-md bg-brand px-3 py-2 text-sm font-semibold text-white disabled:opacity-60">{busy ? "Working…" : acceptLabel}</button>
        <button disabled={busy} onClick={() => send("reject")} className="rounded-md bg-red-600 px-3 py-2 text-sm font-semibold text-white disabled:opacity-60">Reject</button>
      </div>
      {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
    </div>
  );
}
