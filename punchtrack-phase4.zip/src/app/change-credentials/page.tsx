import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import Form from "./Form";
export default async function Page() {
  const u = await getCurrentUser();
  if (!u) redirect("/login");
  if (u.role === "USER") redirect("/dashboard");
  return (
    <main className="mx-auto max-w-sm px-4 pt-16">
      <h1 className="text-2xl font-bold">{u.mustChangeCredentials ? "Set your own login" : "Change username and password"}</h1>
      {u.mustChangeCredentials && <p className="muted mt-1 mb-6">You are using the default login. Choose a new username and password before continuing.</p>}
      <Form forced={u.mustChangeCredentials} currentUsername={u.username ?? ""} />
    </main>
  );
}
