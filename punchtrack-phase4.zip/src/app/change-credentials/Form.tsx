"use client";
import { useState } from "react";

export default function Form({ forced, currentUsername }: { forced: boolean; currentUsername: string }) {
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setError("");
    const f = new FormData(e.currentTarget);
    if (f.get("newPassword") !== f.get("confirm")) { setError("The new passwords don't match."); return; }
    setBusy(true);
    const r = await fetch("/api/auth/change-credentials", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ currentPassword: f.get("currentPassword"), username: f.get("username"), newPassword: f.get("newPassword") }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok) { window.location.href = j.next; return; }
    setError(j.error || "Could not save."); setBusy(false);
  }
  return (
    <form onSubmit={submit} className="card p-5 space-y-4">
      <label className="block"><span className="text-sm">Current password</span>
        <input name="currentPassword" type="password" className="input mt-1" required /></label>
      <label className="block"><span className="text-sm">New username</span>
        <input name="username" defaultValue={forced ? "" : currentUsername} className="input mt-1" autoComplete="username" required /></label>
      <label className="block"><span className="text-sm">New password (8+ characters)</span>
        <input name="newPassword" type="password" className="input mt-1" autoComplete="new-password" required minLength={8} /></label>
      <label className="block"><span className="text-sm">Confirm new password</span>
        <input name="confirm" type="password" className="input mt-1" autoComplete="new-password" required /></label>
      {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
      <button className="btn" disabled={busy}>{busy ? "Saving…" : "Save and continue"}</button>
    </form>
  );
}
