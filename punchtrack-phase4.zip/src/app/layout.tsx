import "./globals.css";
import type { Metadata } from "next";
import { getBranding } from "@/lib/branding";
export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const b = await getBranding();
  return { title: b.siteName, description: b.loginTagline, ...(b.faviconPath ? { icons: { icon: "/api/branding/favicon" } } : {}) };
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const b = await getBranding();
  return (
    <html lang="en" suppressHydrationWarning>
      <head><meta name="viewport" content="width=device-width, initial-scale=1" /><script dangerouslySetInnerHTML={{ __html: "try{var t=localStorage.getItem('pt_theme');if(t)document.documentElement.dataset.theme=t}catch(e){}" }} /></head>
      <body style={{ ["--brand" as string]: b.primaryColor, ["--brand2" as string]: b.secondaryColor }}>
        <div className="min-h-screen flex flex-col">
          <div className="flex-1">{children}</div>
          <footer className="py-4 text-center text-sm muted">© {new Date().getFullYear()} {b.siteName}</footer>
        </div>
      </body>
    </html>
  );
}
