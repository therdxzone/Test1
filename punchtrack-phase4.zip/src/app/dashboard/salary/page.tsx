import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { userLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import Badge from "@/components/Badge";
import { getSettings, dateInTz } from "@/lib/attendance";
export const dynamic = "force-dynamic";

export default async function MySalary() {
  const u = await requireUser();
  const tz = (await getSettings()).timezone;
  const month = dateInTz(new Date(), tz).slice(0, 7);
  const all = await prisma.salaryRecord.findMany({ where: { userId: u.id }, include: { proof: true }, orderBy: { month: "desc" } });
  const cur = all.find((s) => s.month === month), prev = all.filter((s) => s.month !== month);
  const line = (s: (typeof all)[number]) => (
    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
      <b>{s.month}</b><span>{s.amount.toString()}</span><Badge value={s.status} />
      <span className="muted">{s.paymentDate ? s.paymentDate.toLocaleDateString("en-GB") : "No payment date"}</span>
      {s.proof && <a className="underline" target="_blank" href={`/api/files/proof/${s.proof.id}`}>View payment screenshot</a>}
      {s.notes && <span className="muted w-full">{s.notes}</span>}
    </div>);
  return (
    <Shell links={await userLinks(u.id, u.status === "ACTIVE")} who={u.fullName}>
      <h1 className="text-2xl font-bold mb-4">My salary</h1>
      <section className="card p-4 mb-4"><h2 className="font-semibold mb-2">Current month ({month})</h2>
        {cur ? line(cur) : <p className="muted text-sm">No salary record for this month yet.</p>}</section>
      <section className="card p-4"><h2 className="font-semibold mb-2">Previous months</h2>
        {prev.length === 0 ? <p className="muted text-sm">No earlier records.</p> : <div className="space-y-3">{prev.map((s) => <div key={s.id}>{line(s)}</div>)}</div>}</section>
    </Shell>
  );
}
