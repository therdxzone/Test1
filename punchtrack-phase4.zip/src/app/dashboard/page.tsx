import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { userLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import Badge from "@/components/Badge";
import { dateInTz, getSettings } from "@/lib/attendance";
export const dynamic = "force-dynamic";

export default async function UserHome() {
  const u = await getCurrentUser();
  if (!u) redirect("/login");
  if (u.role === "ADMIN") redirect("/admin");
  if (u.role === "VERIFIER") redirect("/verifier");
  const profile = await prisma.profile.findUnique({ where: { userId: u.id } });
  const today = new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" });
  const approved = u.status === "ACTIVE";
  const tz = (await getSettings()).timezone;
  const todayKey = dateInTz(new Date(), tz);
  const att = await prisma.attendance.findMany({ where: { userId: u.id }, include: { photos: true } });
  const todayAtt = att.find((a) => a.date === todayKey) ?? null;
  const completed = att.filter((a) => a.status === "APPROVED").length;
  const accepted = att.filter((a) => a.status === "APPROVED").reduce((n, a) => n + a.photos.length, 0);
  const rejectedPhotos = att.filter((a) => a.status === "REJECTED" || a.status === "VERIFIER_REJECTED").reduce((n, a) => n + a.photos.length, 0);
  const incomplete = att.filter((a) => a.date < todayKey && a.status !== "APPROVED").length;
  const slotState = (slot: string) => { const p = todayAtt?.photos.find((x) => x.slot === slot); return !p ? "OPEN" : todayAtt!.status === "OPEN" ? "DRAFT" : todayAtt!.status; };
  const cards: [string, number][] = [["Total completed days", completed], ["Accepted photos", accepted], ["Rejected photos", rejectedPhotos], ["Incomplete days", incomplete]];
  return (
    <Shell links={await userLinks(u.id, approved)} who={u.fullName}>
      <h1 className="text-2xl font-bold">Hello, {u.fullName}</h1>
      <p className="muted mb-5">{today}</p>
      {u.role === "VERIFIER" ? (
        <p className="card p-4">Go to the <a className="underline" href="/verifier">verifier dashboard</a>.</p>
      ) : !approved ? (
        profile?.status === "SUBMITTED" ? (
          <p className="card p-4">Your profile is under review. Please wait for administrator approval.</p>
        ) : (
          <div className="card p-4 space-y-2">
            {profile?.status === "REJECTED" && <p className="text-red-600">Your profile was rejected: {profile.rejectionReason}</p>}
            <p>Complete your profile to get started.</p>
            <a href="/dashboard/profile" className="btn inline-block w-auto text-center">Complete profile</a>
          </div>
        )
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
          {cards.map(([l, n]) => <div key={l} className="card p-4"><div className="text-3xl font-semibold">{n}</div><div className="muted text-sm">{l}</div></div>)}
          <div className="card p-4"><div className="muted text-sm mb-1">Today's morning</div>{todayAtt?.photos.some((x) => x.slot === "MORNING") ? <Badge value={slotState("MORNING")} /> : <span className="text-sm">Not uploaded</span>}</div>
          <div className="card p-4"><div className="muted text-sm mb-1">Today's evening</div>{todayAtt?.photos.some((x) => x.slot === "EVENING") ? <Badge value={slotState("EVENING")} /> : <span className="text-sm">{todayAtt?.type === "HALF" ? "Not needed (half day)" : "Not uploaded"}</span>}</div>
          <a href="/dashboard/punch" className="btn text-center col-span-2 sm:col-span-3">Go to daily punch</a>
        </div>
      )}
    </Shell>
  );
}
