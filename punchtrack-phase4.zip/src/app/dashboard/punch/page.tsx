import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { userLinks } from "@/lib/nav";
import { getSettings, dateInTz, fmtTime } from "@/lib/attendance";
import Shell from "@/components/Shell";
import Badge from "@/components/Badge";
import PunchForm from "./PunchForm";
import TypeToggle from "./TypeToggle";
export const dynamic = "force-dynamic";

export default async function Punch({ searchParams }: { searchParams: { type?: string } }) {
  const u = await getCurrentUser();
  if (!u) redirect("/login");
  if (u.role !== "USER") redirect("/");
  const links = await userLinks(u.id, u.status === "ACTIVE");
  if (u.status !== "ACTIVE") return <Shell links={links} who={u.fullName}><p className="card p-4">Your profile is under review. Please wait for administrator approval.</p></Shell>;

  const s = await getSettings();
  const today = dateInTz(new Date(), s.timezone);
  const att = await prisma.attendance.findUnique({ where: { userId_date: { userId: u.id, date: today } }, include: { photos: true, review: true, approval: true } });
  const asg = await prisma.verifierAssignment.findUnique({ where: { userId: u.id } });
  const type: "FULL" | "HALF" = searchParams.type === "HALF" ? "HALF" : searchParams.type === "FULL" ? "FULL" : att?.type ?? "FULL";
  const rejected = att && (att.status === "VERIFIER_REJECTED" || att.status === "REJECTED");
  const locked = !!att && (att.status === "SUBMITTED" || att.status === "VERIFIER_ACCEPTED" || att.status === "APPROVED" || (rejected && !s.resubmitAllowed));
  const reason = att?.approval?.decision === "REJECTED" ? att.approval.comment : att?.review?.decision === "REJECTED" ? att.review.comment : null;
  const slots: { slot: "MORNING" | "EVENING"; label: string }[] = [{ slot: "MORNING", label: "Morning" }, ...(type === "FULL" ? [{ slot: "EVENING" as const, label: "Evening" }] : [])];

  return (
    <Shell links={links} who={u.fullName}>
      <h1 className="text-2xl font-bold">Daily punch</h1>
      <p className="muted mb-4">{new Date().toLocaleDateString("en-US", { timeZone: s.timezone, weekday: "long", year: "numeric", month: "long", day: "numeric" })} · submit before 12:00 AM</p>
      {att && <p className="mb-3">Today's status: <Badge value={att.status} /></p>}
      {rejected && <p role="alert" className="card p-3 mb-4 border-l-4 border-l-red-500 text-sm">Your attendance submission has been rejected. Please upload valid photos before 12:00 AM today.{reason && <> Reason: {reason}</>}</p>}
      {!asg && <p className="card p-3 mb-4 text-sm border-l-4 border-l-amber-500">No verifier is assigned to you yet. You can upload, but review starts once the administrator assigns one.</p>}
      <p className="text-sm muted mb-3">Upload photos of the required workplace item. These are not selfies. {s.halfDayRule}</p>
      {!locked && <div className="mb-4"><TypeToggle value={type} /></div>}
      {locked && <p className="card p-3 mb-4 text-sm">Today's attendance is {att!.status === "APPROVED" ? "approved" : "submitted and being reviewed"}. It can't be changed.</p>}
      <div className="grid gap-4 sm:grid-cols-2">
        {slots.map(({ slot, label }) => {
          const ph = att?.photos.find((p) => p.slot === slot);
          return (
            <div key={slot} className="card p-4">
              <div className="font-semibold mb-2">{label} punch</div>
              {ph ? (<div className="mb-3"><img src={`/api/files/punch/${ph.id}`} alt={`${label} punch`} className="h-40 w-full rounded-lg object-cover" /><p className="text-xs muted mt-1">Recorded {fmtTime(ph.capturedAt, s.timezone)}</p></div>) : <p className="text-sm muted mb-3">Not uploaded yet.</p>}
              <PunchForm slot={slot} type={type} label={label} disabled={locked} />
            </div>);
        })}
      </div>
    </Shell>
  );
}
