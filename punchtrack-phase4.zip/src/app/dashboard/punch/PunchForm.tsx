"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function PunchForm({ slot, type, label, disabled }: { slot: "MORNING" | "EVENING"; type: "FULL" | "HALF"; label: string; disabled: boolean }) {
  const router = useRouter(); const [busy, setBusy] = useState(false); const [msg, setMsg] = useState(""); const [err, setErr] = useState("");
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); if (busy) return;
    setBusy(true); setErr(""); setMsg("");
    const f = new FormData(e.currentTarget); f.set("slot", slot); f.set("type", type);
    const r = await fetch("/api/punch", { method: "POST", body: f });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) setErr(j.error || "Upload failed."); else setMsg(j.submitted ? "Submitted for review." : "Photo saved.");
    setBusy(false); router.refresh();
  }
  return (
    <form onSubmit={submit} className="space-y-2">
      <input type="file" name="photo" accept="image/jpeg,image/png,image/webp" required disabled={disabled || busy} className="input" aria-label={`${label} photo`} />
      <button className="btn" disabled={disabled || busy}>{busy ? "Uploading…" : `Upload ${label.toLowerCase()} photo`}</button>
      {msg && <p role="status" className="text-sm text-green-700">{msg}</p>}
      {err && <p role="alert" className="text-sm text-red-600">{err}</p>}
    </form>
  );
}
