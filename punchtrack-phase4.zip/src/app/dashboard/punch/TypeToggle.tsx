"use client";
export default function TypeToggle({ value }: { value: "FULL" | "HALF" }) {
  return (
    <div className="flex gap-2" role="group" aria-label="Attendance type">
      {(["FULL", "HALF"] as const).map((t) => (
        <a key={t} href={`/dashboard/punch?type=${t}`} aria-current={value === t} className={`rounded-full px-4 py-1.5 text-sm border border-[var(--line)] ${value === t ? "bg-brand text-white" : ""}`}>{t === "FULL" ? "Full day" : "Half day"}</a>
      ))}
    </div>
  );
}
