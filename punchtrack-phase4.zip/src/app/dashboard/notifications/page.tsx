import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { userLinks, adminLinks, verifierLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import { MarkRead } from "@/components/Actions";
export const dynamic = "force-dynamic";

export default async function Notifications() {
  const u = await getCurrentUser();
  if (!u) redirect("/login");
  const items = await prisma.notification.findMany({ where: { userId: u.id }, orderBy: { createdAt: "desc" }, take: 100 });
  const links = u.role === "ADMIN" ? await adminLinks(u.id) : u.role === "VERIFIER" ? await verifierLinks(u.id) : await userLinks(u.id, u.status === "ACTIVE");
  return (
    <Shell links={links} who={u.fullName}>
      <div className="flex items-center justify-between mb-4"><h1 className="text-2xl font-bold">Notifications</h1>{items.some((i) => !i.read) && <MarkRead />}</div>
      {items.length === 0 ? <p className="card p-4 muted">No notifications yet.</p> : (
        <ul className="space-y-2">{items.map((n) => (
          <li key={n.id} className={`card p-3 ${n.read ? "opacity-70" : "border-l-4 border-l-[var(--brand)]"}`}>
            <div className="font-semibold">{n.title}</div><div className="text-sm">{n.body}</div>
            <div className="text-xs muted mt-1">{n.createdAt.toLocaleString("en-GB")}</div></li>))}</ul>)}
    </Shell>
  );
}
