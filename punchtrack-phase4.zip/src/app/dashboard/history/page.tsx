import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { userLinks } from "@/lib/nav";
import { getSettings, validMonth, dateInTz } from "@/lib/attendance";
import Shell from "@/components/Shell";
import AttendanceTable from "@/components/AttendanceTable";
export const dynamic = "force-dynamic";

export default async function History({ searchParams }: { searchParams: { month?: string } }) {
  const u = await getCurrentUser();
  if (!u) redirect("/login");
  if (u.role !== "USER") redirect("/");
  const s = await getSettings();
  const month = validMonth(searchParams.month) ?? dateInTz(new Date(), s.timezone).slice(0, 7);
  const rows = u.status === "ACTIVE" ? await prisma.attendance.findMany({
    where: { userId: u.id, date: { startsWith: month } }, include: { photos: true, review: true, approval: true }, orderBy: { date: "desc" },
  }) : [];
  return (
    <Shell links={await userLinks(u.id, u.status === "ACTIVE")} who={u.fullName}>
      <h1 className="text-2xl font-bold mb-4">Attendance history</h1>
      <form className="flex gap-2 mb-4"><input type="month" name="month" defaultValue={month} className="input !w-auto" aria-label="Month" /><button className="btn !w-auto">Show</button></form>
      <AttendanceTable rows={rows} tz={s.timezone} empty="No attendance for this month." />
    </Shell>
  );
}
