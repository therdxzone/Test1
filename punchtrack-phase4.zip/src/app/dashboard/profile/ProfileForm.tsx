"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
export default function ProfileForm({ hasFace, hasQr, googlePay, otherPayment, userId }: { hasFace: boolean; hasQr: boolean; googlePay: boolean; otherPayment: boolean; userId: string }) {
  const router = useRouter(); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setError("");
    const f = new FormData(e.currentTarget);
    f.set("googlePay", f.get("googlePay") === "yes" ? "true" : "false");
    f.set("otherPayment", f.get("otherPayment") === "yes" ? "true" : "false");
    setBusy(true);
    const r = await fetch("/api/profile", { method: "POST", body: f });
    if (r.ok) { router.refresh(); return; }
    setError((await r.json().catch(() => ({}))).error || "Could not submit."); setBusy(false);
  }
  const yn = (name: string, v: boolean, label: string) => (
    <label className="block"><span className="text-sm">{label}</span>
      <select name={name} defaultValue={v ? "yes" : "no"} className="input mt-1"><option value="yes">Available</option><option value="no">Not available</option></select></label>);
  return (
    <form onSubmit={submit} className="card p-5 space-y-4">
      <label className="block"><span className="text-sm">Face photo {hasFace && "(saved; choose a file to replace)"}</span>
        <input name="face" type="file" accept="image/jpeg,image/png,image/webp" className="input mt-1" required={!hasFace} /></label>
      <label className="block"><span className="text-sm">Payment QR code photo {hasQr && "(saved; choose a file to replace)"}</span>
        <input name="qr" type="file" accept="image/jpeg,image/png,image/webp" className="input mt-1" required={!hasQr} /></label>
      {yn("googlePay", googlePay, "Google Pay")}
      {yn("otherPayment", otherPayment, "Other payment method")}
      <p className="muted text-xs">JPEG, PNG or WebP, up to 5 MB each.</p>
      {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
      <button className="btn" disabled={busy}>{busy ? "Submitting…" : "Submit profile for review"}</button>
    </form>
  );
}
