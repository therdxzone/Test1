import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { userLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import Badge from "@/components/Badge";
import ProfileForm from "./ProfileForm";
export const dynamic = "force-dynamic";

export default async function ProfilePage() {
  const u = await getCurrentUser();
  if (!u) redirect("/login");
  if (u.role !== "USER") redirect("/dashboard");
  const p = await prisma.profile.findUnique({ where: { userId: u.id } });
  const editable = p?.status === "DRAFT" || p?.status === "REJECTED";
  return (
    <Shell links={await userLinks(u.id, u.status === "ACTIVE")} who={u.fullName}>
      <div className="flex items-center gap-3 mb-4"><h1 className="text-2xl font-bold">My profile</h1>{p && <Badge value={p.status} />}</div>
      {p?.status === "SUBMITTED" && <p className="card p-4 mb-4">Your profile is under review. Please wait for administrator approval.</p>}
      {p?.status === "REJECTED" && <p className="card p-4 mb-4 text-red-600">Rejected: {p.rejectionReason}</p>}
      <div className="card p-4 mb-4 text-sm space-y-1">
        <div><span className="muted">Name:</span> {u.fullName}</div><div><span className="muted">Email:</span> {u.email}</div>
      </div>
      {editable ? (
        <ProfileForm hasFace={!!p?.facePhotoPath} hasQr={!!p?.qrPhotoPath} googlePay={!!p?.googlePay} otherPayment={!!p?.otherPayment} userId={u.id} />
      ) : (
        <div className="card p-4 grid sm:grid-cols-2 gap-4">
          <div><div className="text-sm muted mb-1">Face photo</div><a href={`/api/files/face/${u.id}`} target="_blank"><img src={`/api/files/face/${u.id}`} alt="Your face photo" className="rounded-lg max-h-56" /></a></div>
          <div><div className="text-sm muted mb-1">Payment QR code</div><a href={`/api/files/qr/${u.id}`} target="_blank"><img src={`/api/files/qr/${u.id}`} alt="Your payment QR code" className="rounded-lg max-h-56" /></a></div>
          <div className="text-sm">Google Pay: {p?.googlePay ? "Available" : "Not available"}</div>
          <div className="text-sm">Other payment method: {p?.otherPayment ? "Available" : "Not available"}</div>
        </div>
      )}
    </Shell>
  );
}
