"use client";
export default function LogoutButton() {
  return (
    <button className="text-sm underline" onClick={async () => {
      await fetch("/api/auth/logout", { method: "POST" }); window.location.href = "/login";
    }}>Log out</button>
  );
}
