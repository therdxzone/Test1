import { requireRole } from "@/lib/auth";
import { adminLinks } from "@/lib/nav";
import { getSettings } from "@/lib/attendance";
import Shell from "@/components/Shell";
import SettingsForm from "@/components/SettingsForm";
export const dynamic = "force-dynamic";
export default async function AdminSettings() {
  const me = await requireRole("ADMIN"); const s = await getSettings();
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-4">Admin settings</h1>
      <SettingsForm timezone={s.timezone} halfDayRule={s.halfDayRule} resubmitAllowed={s.resubmitAllowed} />
      <section className="card p-4 mt-4"><h2 className="font-semibold mb-1">Your login</h2>
        <p className="text-sm muted mb-3">Change your administrator username and password.</p>
        <a href="/change-credentials" className="btn !w-auto inline-block text-center">Change username or password</a></section>
    </Shell>
  );
}
