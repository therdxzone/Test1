import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { adminLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import Badge from "@/components/Badge";
import { CreateVerifier, VerifierActions, AssignSelect } from "@/components/VerifierForms";
export const dynamic = "force-dynamic";

export default async function Verifiers() {
  const me = await requireRole("ADMIN");
  const [verifiers, users] = await Promise.all([
    prisma.user.findMany({ where: { role: "VERIFIER" }, include: { _count: { select: { assignments: true } } }, orderBy: { createdAt: "asc" } }),
    prisma.user.findMany({ where: { role: "USER" }, include: { assignedTo: true }, orderBy: { fullName: "asc" } }),
  ]);
  const active = verifiers.filter((v) => v.status === "ACTIVE").map((v) => ({ id: v.id, name: v.fullName }));
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-4">Verifiers</h1>
      <CreateVerifier />
      <div className="grid gap-3 sm:grid-cols-2 mb-8">
        {verifiers.length === 0 && <p className="card p-4 muted sm:col-span-2">No verifiers yet. Create one above.</p>}
        {verifiers.map((v) => (
          <div key={v.id} className="card p-4">
            <div className="font-semibold">{v.fullName} <Badge value={v.status} /></div>
            <div className="text-sm muted">@{v.username} · {v._count.assignments} assigned user(s)</div>
            <VerifierActions id={v.id} suspended={v.status === "SUSPENDED"} />
          </div>
        ))}
      </div>
      <h2 className="text-lg font-semibold mb-2">Assign users to verifiers</h2>
      {users.length === 0 ? <p className="card p-4 muted">No registered users yet.</p> : (
        <div className="space-y-2">{users.map((u) => (
          <div key={u.id} className="card p-3 flex flex-wrap items-center justify-between gap-2">
            <div><div className="font-medium">{u.fullName}</div><div className="text-xs muted">{u.email}</div></div>
            <AssignSelect userId={u.id} current={u.assignedTo?.verifierId ?? null} verifiers={active} />
          </div>))}</div>)}
    </Shell>
  );
}
