import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { adminLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
export const dynamic = "force-dynamic";
export default async function Logs() {
  const me = await requireRole("ADMIN");
  const logs = await prisma.auditLog.findMany({ orderBy: { createdAt: "desc" }, take: 200, include: { actor: { select: { username: true, fullName: true } } } });
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-4">Activity logs</h1>
      {logs.length === 0 ? <p className="card p-4 muted">No activity yet.</p> : (
        <div className="overflow-x-auto card"><table className="w-full text-sm"><thead><tr className="text-left muted"><th className="p-2">When</th><th className="p-2">Who</th><th className="p-2">Action</th><th className="p-2">Detail</th></tr></thead>
          <tbody>{logs.map((l) => <tr key={l.id} className="border-t border-[var(--line)] align-top"><td className="p-2 whitespace-nowrap">{l.createdAt.toLocaleString("en-GB")}</td><td className="p-2">{l.actor?.username ?? l.actor?.fullName ?? "—"}</td><td className="p-2">{l.action}</td><td className="p-2 break-all">{[l.target, l.detail].filter(Boolean).join(" · ")}</td></tr>)}</tbody></table></div>)}
    </Shell>
  );
}
