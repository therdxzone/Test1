import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { adminLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import { ReviewProfile } from "@/components/Actions";
export const dynamic = "force-dynamic";

export default async function Pending() {
  const me = await requireRole("ADMIN");
  const list = await prisma.profile.findMany({ where: { status: "SUBMITTED" }, include: { user: true }, orderBy: { submittedAt: "asc" } });
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-4">Pending profiles</h1>
      {list.length === 0 ? <p className="card p-4 muted">No profiles are waiting for review.</p> : (
        <div className="space-y-4">{list.map((p) => (
          <div key={p.id} className="card p-4">
            <div className="font-semibold">{p.user.fullName}</div>
            <div className="text-sm muted mb-3">{p.user.email} · Google Pay: {p.googlePay ? "Yes" : "No"} · Other: {p.otherPayment ? "Yes" : "No"}</div>
            <div className="flex gap-3 mb-3">
              <a href={`/api/files/face/${p.userId}`} target="_blank"><img src={`/api/files/face/${p.userId}`} alt={`${p.user.fullName} face photo`} className="h-32 rounded-lg" /></a>
              <a href={`/api/files/qr/${p.userId}`} target="_blank"><img src={`/api/files/qr/${p.userId}`} alt={`${p.user.fullName} payment QR`} className="h-32 rounded-lg" /></a>
            </div>
            <ReviewProfile userId={p.userId} />
          </div>))}</div>)}
    </Shell>
  );
}
