import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { adminLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import { getSettings, dateInTz } from "@/lib/attendance";
export const dynamic = "force-dynamic";

export default async function AdminHome() {
  const me = await requireRole("ADMIN");
  const [total, active, pending, suspended, verifiers, pendingVer, approvedAtt, rejectedAtt] = await Promise.all([
    prisma.user.count({ where: { role: "USER" } }),
    prisma.user.count({ where: { role: "USER", status: "ACTIVE" } }),
    prisma.profile.count({ where: { status: "SUBMITTED" } }),
    prisma.user.count({ where: { role: "USER", status: "SUSPENDED" } }),
    prisma.user.count({ where: { role: "VERIFIER" } }),
    prisma.attendance.count({ where: { status: "SUBMITTED" } }),
    prisma.attendance.count({ where: { status: "APPROVED" } }),
    prisma.attendance.count({ where: { status: { in: ["REJECTED", "VERIFIER_REJECTED"] } } }),
  ]);
  const month = dateInTz(new Date(), (await getSettings()).timezone).slice(0, 7);
  const sal = await prisma.salaryRecord.findMany({ where: { month }, select: { amount: true, status: true } });
  const sum = (st?: string) => sal.filter((x) => !st || x.status === st).reduce((n, x) => n + Number(x.amount), 0).toFixed(2);
  const stats: [string, number][] = [["Registered users", total], ["Active users", active], ["Pending profiles", pending], ["Suspended users", suspended], ["Verifiers", verifiers], ["Pending verifications", pendingVer], ["Approved attendance", approvedAtt], ["Rejected attendance", rejectedAtt]];
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-5">Admin dashboard</h1>
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {stats.map(([l, n]) => (<div key={l} className="card p-4"><div className="text-3xl font-semibold">{n}</div><div className="muted text-sm">{l}</div></div>))}
      </div>
      <section className="card p-4 mt-4"><h2 className="font-semibold mb-2">Monthly salary overview ({month})</h2>
        <p className="text-sm">Records: {sal.length} · Total: {sum()} · Paid: {sum("PAID")} · Pending: {sum("PENDING")}</p>
        <a className="underline text-sm" href="/admin/salary">Manage salaries</a></section>
    </Shell>
  );
}
