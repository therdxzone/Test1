import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { adminLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import Badge from "@/components/Badge";
export const dynamic = "force-dynamic";

export default async function Users({ searchParams }: { searchParams: { q?: string } }) {
  const me = await requireRole("ADMIN");
  const q = (searchParams.q ?? "").trim().slice(0, 80);
  const users = await prisma.user.findMany({
    where: { role: "USER", ...(q && { OR: [
      { fullName: { contains: q, mode: "insensitive" } }, { email: { contains: q, mode: "insensitive" } }, { id: { contains: q } } ] }) },
    include: { profile: { select: { facePhotoPath: true } } }, orderBy: { createdAt: "desc" }, take: 200,
  });
  const done = await prisma.attendance.groupBy({ by: ["userId"], where: { status: "APPROVED", userId: { in: users.map((u) => u.id) } }, _count: true });
  const days = new Map(done.map((d) => [d.userId, d._count]));
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-4">Users</h1>
      <form className="mb-4"><input name="q" defaultValue={q} placeholder="Search name, email or user ID" className="input" aria-label="Search users" /></form>
      {users.length === 0 ? <p className="card p-4 muted">{q ? "No users match your search." : "No users have registered yet."}</p> : (
        <ul className="grid sm:grid-cols-2 gap-3">{users.map((u) => (
          <li key={u.id}><a href={`/admin/users/${u.id}`} className="card p-3 flex gap-3 items-center hover:border-[var(--brand)]">
            {u.profile?.facePhotoPath ? <img src={`/api/files/face/${u.id}`} alt="" className="h-14 w-14 rounded-full object-cover" /> : <div className="h-14 w-14 rounded-full bg-[var(--brand2)]" />}
            <div className="min-w-0">
              <div className="font-semibold truncate">{u.fullName}</div>
              <div className="text-sm muted truncate">{u.email}</div>
              <div className="text-xs muted">ID …{u.id.slice(-8)} · {days.get(u.id) ?? 0} completed days</div>
            </div>
            <div className="ml-auto"><Badge value={u.status} /></div>
          </a></li>))}</ul>)}
    </Shell>
  );
}
