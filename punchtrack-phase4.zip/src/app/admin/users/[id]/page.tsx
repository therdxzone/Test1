import { notFound } from "next/navigation";
import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { adminLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import Badge from "@/components/Badge";
import { ActionButton, EditUser } from "@/components/Actions";
import AttendanceTable from "@/components/AttendanceTable";
import { getSettings, validMonth, dateInTz } from "@/lib/attendance";
export const dynamic = "force-dynamic";

export default async function UserDetails({ params, searchParams }: { params: { id: string }; searchParams: { month?: string } }) {
  const me = await requireRole("ADMIN");
  const u = await prisma.user.findUnique({ where: { id: params.id }, include: { profile: true, salaries: { include: { proof: true }, orderBy: { month: "desc" } } } });
  if (!u || u.role !== "USER") notFound();
  const att = await prisma.attendance.findMany({ where: { userId: u.id }, include: { photos: true, review: true, approval: true } });
  const tz = (await getSettings()).timezone;
  const month = validMonth(searchParams.month) ?? dateInTz(new Date(), tz).slice(0, 7);
  const monthRows = await prisma.attendance.findMany({ where: { userId: u.id, date: { startsWith: month } }, include: { photos: true, review: true, approval: true }, orderBy: { date: "desc" } });
  const approved = att.filter((a) => a.status === "APPROVED");
  const full = approved.filter((a) => a.type === "FULL").length, half = approved.filter((a) => a.type === "HALF").length;
  const rejectedPhotos = att.filter((a) => a.status === "REJECTED" || a.status === "VERIFIER_REJECTED").reduce((n, a) => n + a.photos.length, 0);
  const acceptedPhotos = approved.reduce((n, a) => n + a.photos.length, 0);
  const incomplete = att.filter((a) => a.photos.length < 2 && a.type === "FULL").length;
  const todayKey = dateInTz(new Date(), tz);
  const missing = att.filter((a) => a.date < todayKey).reduce((n, a) => n + Math.max(0, (a.type === "FULL" ? 2 : 1) - a.photos.length), 0);
  const p = u.profile;
  const row = (k: string, v: React.ReactNode) => (<div className="flex justify-between gap-4 py-1.5 border-b border-[var(--line)] text-sm"><span className="muted">{k}</span><span className="text-right break-all">{v}</span></div>);
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <a href="/admin/users" className="text-sm underline">← All users</a>
      <div className="flex items-center gap-3 mt-2 mb-4"><h1 className="text-2xl font-bold">{u.fullName}</h1><Badge value={u.status} /></div>

      <section className="card p-4 mb-4"><h2 className="font-semibold mb-2">Personal details</h2>
        {row("User ID", u.id)}{row("Full name", u.fullName)}{row("Email", u.email)}
        {row("Registered", u.createdAt.toLocaleDateString("en-GB"))}
        {row("Profile status", p ? <Badge value={p.status} /> : "—")}{row("Account status", <Badge value={u.status} />)}
        {row("Google Pay", p?.googlePay ? "Available" : "Not available")}{row("Other payment method", p?.otherPayment ? "Available" : "Not available")}
        {p?.rejectionReason && row("Last rejection reason", p.rejectionReason)}
      </section>

      <section className="card p-4 mb-4"><h2 className="font-semibold mb-2">Profile images</h2>
        {p?.facePhotoPath || p?.qrPhotoPath ? (
          <div className="grid grid-cols-2 gap-4">
            {p?.facePhotoPath && <a href={`/api/files/face/${u.id}`} target="_blank"><img src={`/api/files/face/${u.id}`} alt="Face photo" className="rounded-lg w-full" /><span className="text-sm underline">Face photo (open original)</span></a>}
            {p?.qrPhotoPath && <a href={`/api/files/qr/${u.id}`} target="_blank"><img src={`/api/files/qr/${u.id}`} alt="Payment QR code" className="rounded-lg w-full" /><span className="text-sm underline">QR code (open original)</span></a>}
          </div>) : <p className="muted text-sm">No images uploaded yet.</p>}
      </section>

      <section className="card p-4 mb-4"><h2 className="font-semibold mb-2">Attendance summary</h2>
        {row("Total full days", full)}{row("Total half days", half)}{row("Incomplete days", incomplete)}
        {row("Missing photos", missing)}{row("Accepted photos", acceptedPhotos)}{row("Rejected photos", rejectedPhotos)}
      </section>

      <section className="mb-4"><h2 className="font-semibold mb-2">Monthly attendance</h2>
        <form className="flex gap-2 mb-3"><input type="month" name="month" defaultValue={month} className="input !w-auto" aria-label="Month" /><button className="btn !w-auto">Show</button></form>
        <AttendanceTable rows={monthRows} tz={tz} empty="No attendance records for this month." />
      </section>

      <section className="card p-4 mb-4"><h2 className="font-semibold mb-2">Salary history</h2>
        {u.salaries.length === 0 ? <p className="muted text-sm">No salary records yet.</p> : u.salaries.map((s) => (
          <div key={s.id} className="py-2 border-b border-[var(--line)] text-sm flex flex-wrap gap-x-4 gap-y-1 items-center">
            <b>{s.month}</b><span>{s.amount.toString()}</span><Badge value={s.status} />
            <span className="muted">{s.paymentDate ? s.paymentDate.toLocaleDateString("en-GB") : "No payment date"}</span>
            {s.proof && <a className="underline" target="_blank" href={`/api/files/proof/${s.proof.id}`}>Payment proof</a>}
          </div>))}
      </section>

      <section className="card p-4 mb-4"><h2 className="font-semibold mb-3">Edit user details</h2>
        <EditUser id={u.id} fullName={u.fullName} email={u.email ?? ""} googlePay={!!p?.googlePay} otherPayment={!!p?.otherPayment} /></section>

      <section className="card p-4"><h2 className="font-semibold mb-2">Account</h2>
        <p className="muted text-sm mb-3">Suspending blocks sign-in. Profile, attendance, salary and images are kept.</p>
        {u.status === "SUSPENDED"
          ? <ActionButton url={`/api/admin/users/${u.id}/status`} body={{ status: "ACTIVE" }} label="Reactivate user" confirmText="Reactivate this user?" />
          : <ActionButton url={`/api/admin/users/${u.id}/status`} body={{ status: "SUSPENDED" }} label="Suspend user" danger confirmText="Suspend this user? They will be signed out." />}
      </section>
    </Shell>
  );
}
