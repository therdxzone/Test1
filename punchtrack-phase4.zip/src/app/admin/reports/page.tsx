import { requireRole } from "@/lib/auth";
import { adminLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import Badge from "@/components/Badge";
import { getSettings, validMonth, dateInTz } from "@/lib/attendance";
import { monthlyReport } from "@/lib/reports";
export const dynamic = "force-dynamic";

export default async function Reports({ searchParams }: { searchParams: { month?: string } }) {
  const me = await requireRole("ADMIN");
  const month = validMonth(searchParams.month) ?? dateInTz(new Date(), (await getSettings()).timezone).slice(0, 7);
  const { attendance, salary } = await monthlyReport(month);
  const dl = (type: string, format: string, label: string) => <a className="btn !w-auto text-center text-sm" href={`/api/admin/reports?month=${month}&type=${type}&format=${format}`}>{label}</a>;
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-4">Monthly reports</h1>
      <form className="flex gap-2 mb-3"><input type="month" name="month" defaultValue={month} className="input !w-auto" aria-label="Month" /><button className="btn !w-auto">Show</button></form>
      <div className="flex flex-wrap gap-2 mb-5">{dl("attendance", "csv", "Attendance CSV")}{dl("salary", "csv", "Salary CSV")}{dl("all", "xlsx", "Excel (both sheets)")}</div>
      <h2 className="font-semibold mb-2">User-wise attendance, {month}</h2>
      <div className="overflow-x-auto card mb-6"><table className="w-full text-sm"><thead><tr className="text-left muted">{["User", "Full days", "Half days", "Rejected photos", "Incomplete"].map((h) => <th key={h} className="p-2">{h}</th>)}</tr></thead>
        <tbody>{attendance.length === 0 ? <tr><td className="p-3 muted" colSpan={5}>No users yet.</td></tr> : attendance.map((r) => <tr key={r.email} className="border-t border-[var(--line)]"><td className="p-2">{r.name}</td><td className="p-2">{r.fullDays}</td><td className="p-2">{r.halfDays}</td><td className="p-2">{r.rejectedPhotos}</td><td className="p-2">{r.incompleteDays}</td></tr>)}</tbody></table></div>
      <h2 className="font-semibold mb-2">Salary and payment history, {month}</h2>
      <div className="overflow-x-auto card"><table className="w-full text-sm"><thead><tr className="text-left muted">{["User", "Amount", "Status", "Payment date"].map((h) => <th key={h} className="p-2">{h}</th>)}</tr></thead>
        <tbody>{salary.length === 0 ? <tr><td className="p-3 muted" colSpan={4}>No salary records for this month.</td></tr> : salary.map((r) => <tr key={r.email} className="border-t border-[var(--line)]"><td className="p-2">{r.name}</td><td className="p-2">{r.amount.toFixed(2)}</td><td className="p-2"><Badge value={r.status} /></td><td className="p-2">{r.paymentDate || "—"}</td></tr>)}</tbody></table></div>
    </Shell>
  );
}
