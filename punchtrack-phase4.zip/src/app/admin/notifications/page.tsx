import { requireRole } from "@/lib/auth";
import { adminLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import AnnounceForm from "@/components/AnnounceForm";
export const dynamic = "force-dynamic";
export default async function Announcements() {
  const me = await requireRole("ADMIN");
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-1">Announcements</h1>
      <p className="muted text-sm mb-4">Sent as in-app notifications. Suspended accounts are skipped. Your own inbox is under Notifications.</p>
      <AnnounceForm />
    </Shell>
  );
}
