import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { adminLinks } from "@/lib/nav";
import { getSettings } from "@/lib/attendance";
import Shell from "@/components/Shell";
import AttendanceTable from "@/components/AttendanceTable";
export const dynamic = "force-dynamic";

const STATUSES = ["OPEN", "SUBMITTED", "VERIFIER_ACCEPTED", "VERIFIER_REJECTED", "APPROVED", "REJECTED"] as const;

export default async function AllAttendance({ searchParams }: { searchParams: { status?: string; date?: string } }) {
  const me = await requireRole("ADMIN");
  const tz = (await getSettings()).timezone;
  const status = STATUSES.find((s) => s === searchParams.status);
  const date = searchParams.date && /^\d{4}-\d{2}-\d{2}$/.test(searchParams.date) ? searchParams.date : undefined;
  const rows = await prisma.attendance.findMany({
    where: { ...(status ? { status } : {}), ...(date ? { date } : {}) },
    include: { photos: true, review: true, approval: true, user: true }, orderBy: [{ date: "desc" }, { createdAt: "desc" }], take: 100,
  });
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-4">Attendance</h1>
      <form className="flex flex-wrap gap-2 mb-4">
        <select name="status" defaultValue={status ?? ""} className="input !w-auto" aria-label="Status">
          <option value="">All statuses</option>{STATUSES.map((s) => <option key={s} value={s}>{s.replace(/_/g, " ").toLowerCase()}</option>)}
        </select>
        <input type="date" name="date" defaultValue={date} className="input !w-auto" aria-label="Date" />
        <button className="btn !w-auto">Filter</button>
      </form>
      <div className="space-y-3">
        {rows.length === 0 ? <p className="card p-4 muted">No attendance records match.</p> : rows.map((a) => (
          <div key={a.id}><a className="text-sm font-semibold underline" href={`/admin/users/${a.userId}`}>{a.user.fullName}</a>
            <AttendanceTable rows={[a]} tz={tz} /></div>))}
      </div>
    </Shell>
  );
}
