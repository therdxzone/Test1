import { requireRole } from "@/lib/auth";
import { adminLinks } from "@/lib/nav";
import { getBranding } from "@/lib/branding";
import Shell from "@/components/Shell";
import BrandingForm from "@/components/BrandingForm";
export const dynamic = "force-dynamic";

export default async function BrandingPage() {
  const me = await requireRole("ADMIN"); const b = await getBranding();
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-4">Branding settings</h1>
      <BrandingForm b={{ siteName: b.siteName, loginTagline: b.loginTagline, primaryColor: b.primaryColor, secondaryColor: b.secondaryColor, sidebarColor: b.sidebarColor, logo: !!b.logoPath, favicon: !!b.faviconPath }} />
    </Shell>
  );
}
