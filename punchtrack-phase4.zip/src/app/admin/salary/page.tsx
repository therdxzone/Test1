import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { adminLinks } from "@/lib/nav";
import Shell from "@/components/Shell";
import Badge from "@/components/Badge";
import SalaryForm from "@/components/SalaryForm";
import { getSettings, validMonth, dateInTz } from "@/lib/attendance";
export const dynamic = "force-dynamic";

export default async function SalaryAdmin({ searchParams }: { searchParams: { month?: string; edit?: string } }) {
  const me = await requireRole("ADMIN");
  const tz = (await getSettings()).timezone;
  const month = validMonth(searchParams.month) ?? dateInTz(new Date(), tz).slice(0, 7);
  const [users, rows] = await Promise.all([
    prisma.user.findMany({ where: { role: "USER" }, orderBy: { fullName: "asc" }, select: { id: true, fullName: true } }),
    prisma.salaryRecord.findMany({ where: { month }, include: { user: true, proof: true }, orderBy: { user: { fullName: "asc" } } }),
  ]);
  const edit = rows.find((r) => r.id === searchParams.edit);
  const total = rows.reduce((n, r) => n + Number(r.amount), 0), paid = rows.filter((r) => r.status === "PAID").reduce((n, r) => n + Number(r.amount), 0);
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-4">Salary management</h1>
      <SalaryForm key={edit?.id ?? "new"} month={month} users={users.map((u) => ({ id: u.id, name: u.fullName }))}
        initial={edit ? { userId: edit.userId, amount: edit.amount.toString(), paymentDate: edit.paymentDate?.toISOString().slice(0, 10) ?? "", status: edit.status, notes: edit.notes ?? "" } : undefined} />
      <form className="flex gap-2 mb-3"><input type="month" name="month" defaultValue={month} className="input !w-auto" aria-label="Month" /><button className="btn !w-auto">Show</button></form>
      <p className="muted text-sm mb-3">{month}: total {total.toFixed(2)}, paid {paid.toFixed(2)}, pending {(total - paid).toFixed(2)}</p>
      {rows.length === 0 ? <p className="card p-4 muted">No salary records for this month.</p> : (
        <div className="space-y-2">{rows.map((r) => (
          <div key={r.id} className="card p-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-sm">
            <a className="font-semibold underline" href={`/admin/users/${r.userId}`}>{r.user.fullName}</a>
            <span>{r.amount.toString()}</span><Badge value={r.status} />
            <span className="muted">{r.paymentDate ? r.paymentDate.toLocaleDateString("en-GB") : "No payment date"}</span>
            {r.proof && <a className="underline" target="_blank" href={`/api/files/proof/${r.proof.id}`}>Payment proof</a>}
            <a className="underline ml-auto" href={`/admin/salary?month=${month}&edit=${r.id}`}>Edit</a>
          </div>))}</div>)}
    </Shell>
  );
}
