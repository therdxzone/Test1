import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { adminLinks } from "@/lib/nav";
import { getSettings } from "@/lib/attendance";
import Shell from "@/components/Shell";
import Badge from "@/components/Badge";
import { PhotoPair } from "@/components/AttendanceTable";
import Decision from "@/components/Decision";
export const dynamic = "force-dynamic";

export default async function Approvals() {
  const me = await requireRole("ADMIN");
  const tz = (await getSettings()).timezone;
  const [rows, unassigned] = await Promise.all([
    prisma.attendance.findMany({ where: { status: "VERIFIER_ACCEPTED" }, include: { photos: true, review: { include: { verifier: true } }, user: true }, orderBy: { date: "asc" }, take: 100 }),
    prisma.attendance.count({ where: { status: "SUBMITTED", user: { assignedTo: null } } }),
  ]);
  return (
    <Shell links={await adminLinks(me.id)} who={me.username ?? "Admin"}>
      <h1 className="text-2xl font-bold mb-4">Final approvals</h1>
      {unassigned > 0 && <p className="card p-3 mb-4 text-sm border-l-4 border-l-amber-500">{unassigned} submission(s) are waiting because the user has no verifier. <a className="underline" href="/admin/verifiers">Assign a verifier</a>.</p>}
      {rows.length === 0 ? <p className="card p-4 muted">No attendance is waiting for final approval.</p> : (
        <div className="space-y-3">{rows.map((a) => (
          <div key={a.id} className="card p-4">
            <div className="flex flex-wrap items-center gap-2 mb-3"><a className="font-semibold underline" href={`/admin/users/${a.userId}`}>{a.user.fullName}</a><span className="muted text-sm">{a.date}</span><span className="text-sm muted">{a.type === "FULL" ? "Full day" : "Half day"}</span></div>
            <PhotoPair photos={a.photos} tz={tz} />
            <p className="text-sm mt-3">Verifier {a.review?.verifier.fullName}: {a.review && <Badge value={a.review.decision} />} {a.review?.comment && <span className="muted">— {a.review.comment}</span>}</p>
            <Decision url={`/api/admin/attendance/${a.id}`} acceptLabel="Approve" />
          </div>))}</div>)}
    </Shell>
  );
}
