import { requireRole } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { verifierLinks } from "@/lib/nav";
import { getSettings } from "@/lib/attendance";
import Shell from "@/components/Shell";
import Badge from "@/components/Badge";
import AttendanceTable, { PhotoPair } from "@/components/AttendanceTable";
import Decision from "@/components/Decision";
export const dynamic = "force-dynamic";

const TABS = [["pending", "Pending"], ["accepted", "Accepted"], ["rejected", "Rejected"], ["users", "Assigned users"]] as const;

export default async function VerifierHome({ searchParams }: { searchParams: { tab?: string } }) {
  const me = await requireRole("VERIFIER");
  const tab = TABS.some((t) => t[0] === searchParams.tab) ? searchParams.tab! : "pending";
  const scope = { user: { assignedTo: { verifierId: me.id } } };
  const tz = (await getSettings()).timezone;
  const [pending, accepted, rejected, assigned] = await Promise.all([
    prisma.attendance.count({ where: { ...scope, status: "SUBMITTED" } }),
    prisma.attendance.count({ where: { ...scope, review: { verifierId: me.id, decision: "ACCEPTED" } } }),
    prisma.attendance.count({ where: { ...scope, review: { verifierId: me.id, decision: "REJECTED" } } }),
    prisma.verifierAssignment.count({ where: { verifierId: me.id } }),
  ]);
  const include = { photos: true, review: true, approval: true, user: true } as const;
  const rows = tab === "pending" ? await prisma.attendance.findMany({ where: { ...scope, status: "SUBMITTED" }, include, orderBy: { date: "asc" }, take: 100 })
    : tab === "accepted" ? await prisma.attendance.findMany({ where: { ...scope, review: { verifierId: me.id, decision: "ACCEPTED" } }, include, orderBy: { date: "desc" }, take: 100 })
    : tab === "rejected" ? await prisma.attendance.findMany({ where: { ...scope, review: { verifierId: me.id, decision: "REJECTED" } }, include, orderBy: { date: "desc" }, take: 100 })
    : [];
  const users = tab === "users" ? await prisma.verifierAssignment.findMany({ where: { verifierId: me.id }, include: { user: true }, orderBy: { user: { fullName: "asc" } } }) : [];
  const cards: [string, number][] = [["Pending attendance", pending], ["Accepted", accepted], ["Rejected", rejected], ["Assigned users", assigned]];
  return (
    <Shell links={await verifierLinks(me.id)} who={me.fullName}>
      <h1 className="text-2xl font-bold mb-4">Verifier dashboard</h1>
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
        {cards.map(([l, n]) => <div key={l} className="card p-4"><div className="text-3xl font-semibold">{n}</div><div className="muted text-sm">{l}</div></div>)}
      </div>
      <div className="flex gap-2 overflow-x-auto mb-4">
        {TABS.map(([k, l]) => <a key={k} href={`/verifier?tab=${k}`} className={`shrink-0 rounded-full px-4 py-1.5 text-sm border border-[var(--line)] ${tab === k ? "bg-brand text-white" : ""}`}>{l}</a>)}
      </div>
      {tab === "users" ? (
        users.length === 0 ? <p className="card p-4 muted">No users are assigned to you yet.</p> :
          <div className="space-y-2">{users.map((a) => <div key={a.id} className="card p-3"><div className="font-medium">{a.user.fullName}</div><div className="text-xs muted">{a.user.email}</div></div>)}</div>
      ) : tab === "pending" ? (
        rows.length === 0 ? <p className="card p-4 muted">Nothing is waiting for review.</p> :
          <div className="space-y-3">{rows.map((a) => (
            <div key={a.id} className="card p-4">
              <div className="flex flex-wrap items-center gap-2 mb-3"><span className="font-semibold">{a.user.fullName}</span><span className="muted text-sm">{a.date}</span><span className="text-sm muted">{a.type === "FULL" ? "Full day" : "Half day"}</span><Badge value={a.status} /></div>
              <PhotoPair photos={a.photos} tz={tz} />
              <Decision url={`/api/verifier/review/${a.id}`} />
            </div>))}</div>
      ) : (
        <AttendanceTable rows={rows} tz={tz} empty="No records here yet." />
      )}
    </Shell>
  );
}
