"use client";
import { useState } from "react";

export default function LoginForm() {
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setError("");
    const f = new FormData(e.currentTarget);
    const r = await fetch("/api/auth/login", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ identifier: f.get("identifier"), password: f.get("password") }),
    });
    const j = await r.json().catch(() => ({}));
    if (r.ok) { window.location.href = j.next; return; }
    setError(j.error || "Sign-in failed."); setBusy(false);
  }
  return (
    <form onSubmit={submit} className="card p-5 space-y-4">
      <label className="block"><span className="text-sm">Username or email</span>
        <input name="identifier" className="input mt-1" autoComplete="username" required /></label>
      <label className="block"><span className="text-sm">Password</span>
        <input name="password" type="password" className="input mt-1" autoComplete="current-password" required /></label>
      {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
      <button className="btn" disabled={busy}>{busy ? "Signing in…" : "Sign in"}</button>
    </form>
  );
}
