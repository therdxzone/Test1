import { getBranding } from "@/lib/branding";
import LoginForm from "./LoginForm";
export default async function LoginPage() {
  const b = await getBranding();
  return (
    <main className="mx-auto max-w-sm px-4 pt-16">
      {b.logoPath && <img src="/api/branding/logo" alt="" className="h-12 mb-3" />}
      <h1 className="text-3xl font-bold">{b.siteName}</h1>
      <p className="muted mt-1 mb-6">{b.loginTagline}</p>
      <LoginForm />
      <p className="mt-4 text-sm">New here? <a className="underline" href="/register">Create an account</a></p>
    </main>
  );
}
