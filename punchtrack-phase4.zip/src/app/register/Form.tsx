"use client";
import { useState } from "react";
export default function Form() {
  const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setError("");
    const f = Object.fromEntries(new FormData(e.currentTarget));
    const r = await fetch("/api/register", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(f) });
    const j = await r.json().catch(() => ({}));
    if (r.ok) { window.location.href = j.next; return; }
    setError(j.error || "Registration failed."); setBusy(false);
  }
  return (
    <form onSubmit={submit} className="card p-5 space-y-4">
      <label className="block"><span className="text-sm">Real full name</span><input name="fullName" className="input mt-1" autoComplete="name" required /></label>
      <label className="block"><span className="text-sm">Email</span><input name="email" type="email" className="input mt-1" autoComplete="email" required /></label>
      <label className="block"><span className="text-sm">Password (8+ characters)</span><input name="password" type="password" minLength={8} className="input mt-1" autoComplete="new-password" required /></label>
      <label className="block"><span className="text-sm">Confirm password</span><input name="confirm" type="password" className="input mt-1" autoComplete="new-password" required /></label>
      {error && <p role="alert" className="text-sm text-red-600">{error}</p>}
      <button className="btn" disabled={busy}>{busy ? "Creating account…" : "Create account"}</button>
    </form>
  );
}
