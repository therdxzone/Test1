import { getBranding } from "@/lib/branding";
import Form from "./Form";
export default async function Register() {
  const b = await getBranding();
  return (
    <main className="mx-auto max-w-sm px-4 pt-12">
      <h1 className="text-3xl font-bold">{b.siteName}</h1>
      <p className="muted mt-1 mb-6">Create your account. An administrator reviews your profile before you can start.</p>
      <Form />
      <p className="mt-4 text-sm">Already registered? <a className="underline" href="/login">Sign in</a></p>
    </main>
  );
}
