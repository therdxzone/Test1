import { redirect } from "next/navigation";
import { getCurrentUser, homeFor } from "@/lib/auth";
export default async function Home() {
  const u = await getCurrentUser();
  if (!u) redirect("/login");
  if (u.mustChangeCredentials) redirect("/change-credentials");
  redirect(homeFor(u.role));
}
