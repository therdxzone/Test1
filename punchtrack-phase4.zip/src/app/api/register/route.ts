import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { createSession, sameOrigin, notifyAdmins } from "@/lib/auth";

const Body = z.object({
  fullName: z.string().trim().min(2, "Enter your real full name.").max(80),
  email: z.string().trim().toLowerCase().email("Enter a valid email.").max(120),
  password: z.string().min(8, "Password must be at least 8 characters.").max(200),
  confirm: z.string(),
}).refine((d) => d.password === d.confirm, { message: "Passwords don't match.", path: ["confirm"] });

export async function POST(req: Request) {
  if (!sameOrigin(req)) return Response.json({ error: "Bad origin." }, { status: 403 });
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: p.error.issues[0].message }, { status: 400 });

  const ip = req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
  const key = `reg|${ip}`;
  const n = await prisma.loginAttempt.count({ where: { key, createdAt: { gte: new Date(Date.now() - 3600_000) } } });
  if (n >= 10) return Response.json({ error: "Too many sign-ups from this network. Try again later." }, { status: 429 });
  await prisma.loginAttempt.create({ data: { key } });

  const { fullName, email, password } = p.data;
  if (await prisma.user.findUnique({ where: { email } }))
    return Response.json({ error: "An account with this email already exists." }, { status: 409 });
  try {
    const user = await prisma.user.create({
      data: { fullName, email, passwordHash: await bcrypt.hash(password, 12), role: "USER", status: "PENDING", profile: { create: {} } },
    });
    await createSession(user.id);
    await notifyAdmins("New registration", `${fullName} (${email}) registered.`);
    return Response.json({ next: "/dashboard/profile" });
  } catch {
    return Response.json({ error: "An account with this email already exists." }, { status: 409 });
  }
}
