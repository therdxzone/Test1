import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit, notify, notifyAdmins } from "@/lib/auth";
import { todayStr, rejectionMessage } from "@/lib/attendance";

const Body = z.object({ action: z.enum(["accept", "reject"]), comment: z.string().trim().max(500).optional() });

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const g = await guardApi(req, "VERIFIER"); if (g.error) return g.error;
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: "Invalid request." }, { status: 400 });
  if (p.data.action === "reject" && !p.data.comment) return Response.json({ error: "Enter a reason for rejecting." }, { status: 400 });

  const att = await prisma.attendance.findUnique({ where: { id: params.id } });
  // Only the assigned verifier may review, and never their own record.
  const asg = att ? await prisma.verifierAssignment.findFirst({ where: { verifierId: g.user.id, userId: att.userId } }) : null;
  if (!att || !asg || att.userId === g.user.id) return Response.json({ error: "Not found." }, { status: 404 });

  const accept = p.data.action === "accept";
  const claimed = await prisma.attendance.updateMany({ where: { id: att.id, status: "SUBMITTED" }, data: { status: accept ? "VERIFIER_ACCEPTED" : "VERIFIER_REJECTED" } });
  if (claimed.count === 0) return Response.json({ error: "This submission was already reviewed." }, { status: 409 });
  await prisma.verifierReview.upsert({
    where: { attendanceId: att.id },
    create: { attendanceId: att.id, verifierId: g.user.id, decision: accept ? "ACCEPTED" : "REJECTED", comment: p.data.comment || null },
    update: { verifierId: g.user.id, decision: accept ? "ACCEPTED" : "REJECTED", comment: p.data.comment || null, decidedAt: new Date() },
  });
  const user = await prisma.user.findUnique({ where: { id: att.userId } });
  if (accept) {
    await notify(att.userId, "Attendance accepted by verifier", `Your attendance for ${att.date} was accepted by the verifier and is waiting for final approval.`);
    await notifyAdmins("Attendance awaiting final approval", `${user?.fullName ?? "A user"}'s attendance for ${att.date} was accepted by a verifier.`);
  } else {
    await notify(att.userId, "Attendance rejected", rejectionMessage(att.date, await todayStr(), p.data.comment!, "verifier"));
  }
  await audit(g.user.id, accept ? "VERIFIER_ACCEPT" : "VERIFIER_REJECT", att.id, p.data.comment);
  return Response.json({ ok: true });
}
