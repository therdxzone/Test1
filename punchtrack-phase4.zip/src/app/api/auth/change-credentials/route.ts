import bcrypt from "bcryptjs";
import { z } from "zod";
import { cookies } from "next/headers";
import { prisma } from "@/lib/db";
import { getCurrentUser, sameOrigin, audit, createSession, COOKIE } from "@/lib/auth";

const Body = z.object({
  currentPassword: z.string().min(1).max(200),
  username: z.string().trim().toLowerCase().regex(/^[a-z0-9_.-]{3,32}$/, "Username: 3-32 letters, numbers, . _ -"),
  newPassword: z.string().min(8, "Password must be at least 8 characters.").max(200),
});

export async function POST(req: Request) {
  if (!sameOrigin(req)) return Response.json({ error: "Bad origin." }, { status: 403 });
  const me = await getCurrentUser();
  if (!me || me.role === "USER") return Response.json({ error: "Not allowed." }, { status: 403 });
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: p.error.issues[0].message }, { status: 400 });
  const { currentPassword, username, newPassword } = p.data;

  if (!(await bcrypt.compare(currentPassword, me.passwordHash)))
    return Response.json({ error: "Current password is incorrect." }, { status: 400 });
  if (me.mustChangeCredentials && (username === "admin" || newPassword === "admin"))
    return Response.json({ error: "Choose a new username and a new password; the defaults are not allowed." }, { status: 400 });
  const taken = await prisma.user.findFirst({ where: { username, NOT: { id: me.id } } });
  if (taken) return Response.json({ error: "That username is already taken." }, { status: 409 });

  await prisma.user.update({
    where: { id: me.id },
    data: { username, passwordHash: await bcrypt.hash(newPassword, 12), mustChangeCredentials: false },
  });
  // Sign out every other session, then start a fresh one.
  await prisma.session.deleteMany({ where: { userId: me.id } });
  cookies().delete(COOKIE);
  await createSession(me.id);
  await audit(me.id, "CREDENTIALS_CHANGED", me.id);
  return Response.json({ next: me.role === "ADMIN" ? "/admin" : "/dashboard" });
}
