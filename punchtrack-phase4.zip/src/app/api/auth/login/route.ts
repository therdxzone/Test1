import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { createSession, sameOrigin, audit } from "@/lib/auth";

const DUMMY = bcrypt.hashSync("not-a-real-password", 12);
const Body = z.object({ identifier: z.string().trim().min(1).max(100), password: z.string().min(1).max(200) });

export async function POST(req: Request) {
  if (!sameOrigin(req)) return Response.json({ error: "Bad origin." }, { status: 403 });
  const parsed = Body.safeParse(await req.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "Enter your username or email and password." }, { status: 400 });
  const id = parsed.data.identifier.toLowerCase();
  const ip = req.headers.get("x-forwarded-for")?.split(",")[0].trim() || "unknown";
  const key = `${ip}|${id}`;

  const since = new Date(Date.now() - 15 * 60_000);
  const recent = await prisma.loginAttempt.count({ where: { key, createdAt: { gte: since } } });
  if (recent >= 8) return Response.json({ error: "Too many attempts. Try again in 15 minutes." }, { status: 429 });

  const user = await prisma.user.findFirst({ where: { OR: [{ username: id }, { email: id }] } });
  const ok = await bcrypt.compare(parsed.data.password, user?.passwordHash ?? DUMMY);
  if (!user || !ok) {
    await prisma.loginAttempt.create({ data: { key } });
    return Response.json({ error: "Incorrect username/email or password." }, { status: 401 });
  }
  if (user.status === "SUSPENDED") return Response.json({ error: "This account is suspended. Contact the administrator." }, { status: 403 });

  await prisma.loginAttempt.deleteMany({ where: { key } });
  await prisma.session.deleteMany({ where: { expiresAt: { lt: new Date() } } });
  await createSession(user.id);
  await audit(user.id, "LOGIN", user.id);
  const next = user.mustChangeCredentials ? "/change-credentials" : user.role === "ADMIN" ? "/admin" : user.role === "VERIFIER" ? "/verifier" : "/dashboard";
  return Response.json({ next });
}
