import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit, notify } from "@/lib/auth";

const Body = z.object({ action: z.enum(["approve", "reject"]), reason: z.string().trim().max(500).optional() });

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: "Invalid request." }, { status: 400 });
  const profile = await prisma.profile.findUnique({ where: { userId: params.id } });
  if (!profile || profile.status !== "SUBMITTED") return Response.json({ error: "No submitted profile to review." }, { status: 409 });

  if (p.data.action === "approve") {
    await prisma.$transaction([
      prisma.profile.update({ where: { userId: params.id }, data: { status: "APPROVED", reviewedAt: new Date(), rejectionReason: null } }),
      prisma.user.update({ where: { id: params.id }, data: { status: "ACTIVE" } }),
    ]);
    await notify(params.id, "Profile approved", "Your profile has been approved. You can now use the full dashboard.");
  } else {
    if (!p.data.reason) return Response.json({ error: "Enter a reason for rejecting." }, { status: 400 });
    await prisma.profile.update({ where: { userId: params.id }, data: { status: "REJECTED", reviewedAt: new Date(), rejectionReason: p.data.reason } });
    await notify(params.id, "Profile rejected", `Your profile was rejected: ${p.data.reason}. Please fix it and submit again.`);
  }
  await audit(g.user.id, `PROFILE_${p.data.action.toUpperCase()}`, params.id, p.data.reason);
  return Response.json({ ok: true });
}
