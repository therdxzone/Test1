import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit } from "@/lib/auth";

const Body = z.object({
  timezone: z.string().refine((t) => { try { new Intl.DateTimeFormat("en", { timeZone: t }); return true; } catch { return false; } }, "Unknown timezone."),
  halfDayRule: z.string().trim().min(1).max(300),
  resubmitAllowed: z.boolean(),
});
export async function POST(req: Request) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: p.error.issues[0].message }, { status: 400 });
  await prisma.adminSetting.upsert({ where: { id: 1 }, update: p.data, create: { id: 1, ...p.data } });
  await audit(g.user.id, "SETTINGS_UPDATED", undefined, JSON.stringify(p.data));
  return Response.json({ ok: true });
}
