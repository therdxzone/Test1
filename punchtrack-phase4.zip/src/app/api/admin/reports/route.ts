import ExcelJS from "exceljs";
import { guardApi } from "@/lib/auth";
import { validMonth } from "@/lib/attendance";
import { monthlyReport, csvCell, safeCell } from "@/lib/reports";
export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const q = new URL(req.url).searchParams;
  const month = validMonth(q.get("month")); if (!month) return Response.json({ error: "Invalid month." }, { status: 400 });
  const format = q.get("format") === "xlsx" ? "xlsx" : "csv", type = q.get("type") === "salary" ? "salary" : "attendance";
  const { attendance, salary } = await monthlyReport(month);
  const attCols = [["Name", "name"], ["Email", "email"], ["Account status", "userStatus"], ["Full days", "fullDays"], ["Half days", "halfDays"], ["Rejected photos", "rejectedPhotos"], ["Incomplete days", "incompleteDays"]] as const;
  const salCols = [["Name", "name"], ["Email", "email"], ["Month", "month"], ["Amount", "amount"], ["Status", "status"], ["Payment date", "paymentDate"], ["Notes", "notes"]] as const;

  if (format === "csv") {
    const cols: readonly (readonly [string, string])[] = type === "salary" ? salCols : attCols;
    const rows = (type === "salary" ? salary : attendance) as Record<string, unknown>[];
    const csv = [cols.map((c) => csvCell(c[0])).join(","), ...rows.map((r) => cols.map((c) => csvCell(r[c[1]])).join(","))].join("\r\n");
    return new Response("\uFEFF" + csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": `attachment; filename="${type}-${month}.csv"` } });
  }
  const wb = new ExcelJS.Workbook();
  const add = (name: string, cols: readonly (readonly [string, string])[], rows: Record<string, unknown>[]) => {
    const ws = wb.addWorksheet(name);
    ws.columns = cols.map((c) => ({ header: c[0], key: c[1], width: 20 }));
    ws.getRow(1).font = { bold: true };
    rows.forEach((r) => ws.addRow(Object.fromEntries(Object.entries(r).map(([k, v]) => [k, safeCell(v)]))));
  };
  add("Attendance", attCols, attendance); add("Salary", salCols, salary as Record<string, unknown>[]);
  const buf = await wb.xlsx.writeBuffer();
  return new Response(new Uint8Array(buf as ArrayBuffer), { headers: { "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "Content-Disposition": `attachment; filename="punchtrack-${month}.xlsx"` } });
}
