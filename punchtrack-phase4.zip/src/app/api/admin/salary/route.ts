import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit, notify } from "@/lib/auth";
import { saveImage, deleteStored } from "@/lib/storage";
import { validMonth } from "@/lib/attendance";

const Body = z.object({
  userId: z.string().min(1),
  amount: z.coerce.number().positive("Enter a salary amount.").max(99999999),
  paymentDate: z.string().optional(),
  status: z.enum(["PAID", "PENDING"]),
  notes: z.string().max(500).optional(),
});

// Admin-only. Creates or updates the salary record for (user, month); users never reach this route.
export async function POST(req: Request) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const f = await req.formData().catch(() => null);
  if (!f) return Response.json({ error: "Invalid form." }, { status: 400 });
  const month = validMonth(String(f.get("month") ?? ""));
  if (!month) return Response.json({ error: "Select a valid month." }, { status: 400 });
  const p = Body.safeParse({ userId: f.get("userId"), amount: f.get("amount"), paymentDate: f.get("paymentDate") || undefined, status: f.get("status"), notes: f.get("notes") || undefined });
  if (!p.success) return Response.json({ error: p.error.issues[0].message }, { status: 400 });
  const d = p.data;
  const user = await prisma.user.findUnique({ where: { id: d.userId } });
  if (!user || user.role !== "USER") return Response.json({ error: "User not found." }, { status: 404 });
  let when: Date | null = null;
  if (d.paymentDate) { when = new Date(d.paymentDate + "T12:00:00Z"); if (isNaN(when.getTime())) return Response.json({ error: "Invalid payment date." }, { status: 400 }); }
  if (d.status === "PAID" && !when) return Response.json({ error: "Enter the payment date for a paid salary." }, { status: 400 });

  const existing = await prisma.salaryRecord.findUnique({ where: { userId_month: { userId: d.userId, month } }, include: { proof: true } });
  const proofFile = f.get("proof");
  const hasProof = proofFile instanceof File && proofFile.size > 0;
  let saved: { path: string; mime: string } | null = null;
  try { if (hasProof) saved = await saveImage(proofFile as File, "proofs"); }
  catch (e) { return Response.json({ error: e instanceof Error ? e.message : "Upload failed." }, { status: 400 }); }

  const data = { amount: d.amount, paymentDate: when, status: d.status, notes: d.notes ?? null };
  const rec = existing
    ? await prisma.salaryRecord.update({ where: { id: existing.id }, data })
    : await prisma.salaryRecord.create({ data: { ...data, userId: d.userId, month } });
  if (saved) {
    if (existing?.proof) await deleteStored(existing.proof.path);
    await prisma.salaryProof.upsert({ where: { salaryId: rec.id }, update: { path: saved.path, mime: saved.mime, uploadedAt: new Date() }, create: { salaryId: rec.id, path: saved.path, mime: saved.mime } });
  }
  await audit(g.user.id, existing ? "SALARY_UPDATED" : "SALARY_CREATED", d.userId, `${month} ${d.amount} ${d.status}`);
  if (d.status === "PAID" && existing?.status !== "PAID") await notify(d.userId, "Salary paid", `Your salary for ${month} (${d.amount}) has been marked as paid.`);
  if (saved) await notify(d.userId, "Salary proof uploaded", `A payment proof for ${month} is now available in My Salary.`);
  return Response.json({ ok: true });
}
