import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit } from "@/lib/auth";
import { saveImage, deleteStored } from "@/lib/storage";

const hex = z.string().regex(/^#[0-9a-fA-F]{6}$/, "Colors must look like #1f6f5c.");
const Body = z.object({
  siteName: z.string().trim().min(1, "Enter a website name.").max(40),
  loginTagline: z.string().trim().max(120),
  primaryColor: hex, secondaryColor: hex, sidebarColor: hex,
});

export async function POST(req: Request) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const f = await req.formData().catch(() => null);
  if (!f) return Response.json({ error: "Invalid form." }, { status: 400 });
  const p = Body.safeParse(Object.fromEntries(["siteName", "loginTagline", "primaryColor", "secondaryColor", "sidebarColor"].map((k) => [k, f.get(k) ?? ""])));
  if (!p.success) return Response.json({ error: p.error.issues[0].message }, { status: 400 });
  const cur = await prisma.brandingSetting.findUnique({ where: { id: 1 } });
  const data: Record<string, unknown> = { ...p.data };
  try {
    for (const [field, key, col] of [["logo", "logoPath", "logoPath"], ["favicon", "faviconPath", "faviconPath"]] as const) {
      const file = f.get(field);
      if (file instanceof File && file.size > 0) {
        const s = await saveImage(file, "branding");
        await deleteStored(cur?.[key]); data[col] = s.path;
      } else if (f.get(`remove_${field}`) === "on") { await deleteStored(cur?.[key]); data[col] = null; }
    }
  } catch (e) { return Response.json({ error: e instanceof Error ? e.message : "Upload failed." }, { status: 400 }); }
  await prisma.brandingSetting.upsert({ where: { id: 1 }, update: data, create: { id: 1, ...data } });
  await audit(g.user.id, "BRANDING_UPDATED", undefined, p.data.siteName);
  return Response.json({ ok: true });
}
