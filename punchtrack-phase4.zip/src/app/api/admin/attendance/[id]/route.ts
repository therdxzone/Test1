import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit, notify } from "@/lib/auth";
import { todayStr, rejectionMessage } from "@/lib/attendance";

const Body = z.object({ action: z.enum(["accept", "reject"]), comment: z.string().trim().max(500).optional() });

// Level 2: only attendance already accepted by a verifier can be finally approved. Only APPROVED counts as a completed day.
export async function POST(req: Request, { params }: { params: { id: string } }) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: "Invalid request." }, { status: 400 });
  if (p.data.action === "reject" && !p.data.comment) return Response.json({ error: "Enter a reason for rejecting." }, { status: 400 });
  const att = await prisma.attendance.findUnique({ where: { id: params.id } });
  if (!att) return Response.json({ error: "Not found." }, { status: 404 });

  const accept = p.data.action === "accept";
  const claimed = await prisma.attendance.updateMany({ where: { id: att.id, status: "VERIFIER_ACCEPTED" }, data: { status: accept ? "APPROVED" : "REJECTED" } });
  if (claimed.count === 0) return Response.json({ error: "This attendance is not waiting for final approval." }, { status: 409 });
  await prisma.adminApproval.upsert({
    where: { attendanceId: att.id },
    create: { attendanceId: att.id, adminId: g.user.id, decision: accept ? "ACCEPTED" : "REJECTED", comment: p.data.comment || null },
    update: { adminId: g.user.id, decision: accept ? "ACCEPTED" : "REJECTED", comment: p.data.comment || null, decidedAt: new Date() },
  });
  if (accept) await notify(att.userId, "Attendance approved", `Your attendance for ${att.date} has been approved.`);
  else await notify(att.userId, "Attendance rejected", rejectionMessage(att.date, await todayStr(), p.data.comment!, "administrator"));
  await audit(g.user.id, accept ? "ADMIN_APPROVE" : "ADMIN_REJECT", att.id, p.data.comment);
  return Response.json({ ok: true });
}
