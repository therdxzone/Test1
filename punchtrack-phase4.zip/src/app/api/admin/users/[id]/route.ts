import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit } from "@/lib/auth";

const Body = z.object({
  fullName: z.string().trim().min(2).max(80),
  email: z.string().trim().toLowerCase().email().max(120),
  googlePay: z.boolean(), otherPayment: z.boolean(),
});

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: "Check the name and email." }, { status: 400 });
  const u = await prisma.user.findUnique({ where: { id: params.id } });
  if (!u || u.role !== "USER") return Response.json({ error: "User not found." }, { status: 404 });
  const dup = await prisma.user.findFirst({ where: { email: p.data.email, NOT: { id: u.id } } });
  if (dup) return Response.json({ error: "That email is already used by another account." }, { status: 409 });
  await prisma.$transaction([
    prisma.user.update({ where: { id: u.id }, data: { fullName: p.data.fullName, email: p.data.email } }),
    prisma.profile.update({ where: { userId: u.id }, data: { googlePay: p.data.googlePay, otherPayment: p.data.otherPayment } }),
  ]);
  await audit(g.user.id, "USER_EDITED", u.id);
  return Response.json({ ok: true });
}
