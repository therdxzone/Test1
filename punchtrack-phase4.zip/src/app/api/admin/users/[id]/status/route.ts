import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit, notify } from "@/lib/auth";

const Body = z.object({ status: z.enum(["SUSPENDED", "ACTIVE"]) });

// Suspending changes status only. Profile, attendance, salary and images are never deleted.
export async function POST(req: Request, { params }: { params: { id: string } }) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: "Invalid request." }, { status: 400 });
  const u = await prisma.user.findUnique({ where: { id: params.id }, include: { profile: true } });
  if (!u || u.role !== "USER") return Response.json({ error: "User not found." }, { status: 404 });

  if (p.data.status === "SUSPENDED") {
    await prisma.user.update({ where: { id: u.id }, data: { status: "SUSPENDED" } });
    await prisma.session.deleteMany({ where: { userId: u.id } });
    await notify(u.id, "Account suspended", "Your account has been suspended by the administrator.");
    await audit(g.user.id, "USER_SUSPENDED", u.id);
  } else {
    const next = u.profile?.status === "APPROVED" ? "ACTIVE" : "PENDING";
    await prisma.user.update({ where: { id: u.id }, data: { status: next } });
    await notify(u.id, "Account reactivated", "Your account has been reactivated.");
    await audit(g.user.id, "USER_REACTIVATED", u.id);
  }
  return Response.json({ ok: true });
}
