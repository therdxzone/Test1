import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit, notify } from "@/lib/auth";

const Body = z.object({ userId: z.string().min(1), verifierId: z.string().min(1).nullable() });

export async function POST(req: Request) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: "Invalid request." }, { status: 400 });
  const user = await prisma.user.findUnique({ where: { id: p.data.userId } });
  if (!user || user.role !== "USER") return Response.json({ error: "User not found." }, { status: 404 });
  if (p.data.verifierId === null) {
    await prisma.verifierAssignment.deleteMany({ where: { userId: user.id } });
  } else {
    const v = await prisma.user.findUnique({ where: { id: p.data.verifierId } });
    if (!v || v.role !== "VERIFIER" || v.status !== "ACTIVE") return Response.json({ error: "Choose an active verifier." }, { status: 400 });
    await prisma.verifierAssignment.upsert({
      where: { userId: user.id }, create: { userId: user.id, verifierId: v.id }, update: { verifierId: v.id },
    });
    // Submissions already waiting for a first review now belong to the new verifier.
    const waiting = await prisma.attendance.count({ where: { userId: user.id, status: "SUBMITTED" } });
    if (waiting) await notify(v.id, "Attendance waiting", `${user.fullName} has ${waiting} submission(s) waiting for review.`);
  }
  await audit(g.user.id, "VERIFIER_ASSIGNED", user.id, p.data.verifierId ?? "none");
  return Response.json({ ok: true });
}
