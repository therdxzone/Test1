import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit } from "@/lib/auth";

const Body = z.object({
  username: z.string().trim().toLowerCase().regex(/^[a-z0-9._-]{3,30}$/, "Username: 3-30 letters, numbers, . _ -"),
  fullName: z.string().trim().min(2).max(80),
  password: z.string().min(8, "Password must be at least 8 characters.").max(100),
});

export async function POST(req: Request) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: p.error.issues[0]?.message ?? "Invalid request." }, { status: 400 });
  if (await prisma.user.findFirst({ where: { OR: [{ username: p.data.username }, { email: p.data.username }] } }))
    return Response.json({ error: "That username is already taken." }, { status: 409 });
  const v = await prisma.user.create({ data: {
    username: p.data.username, fullName: p.data.fullName, role: "VERIFIER", status: "ACTIVE",
    passwordHash: await bcrypt.hash(p.data.password, 12),
  } });
  await audit(g.user.id, "VERIFIER_CREATED", v.id, v.username ?? undefined);
  return Response.json({ ok: true });
}
