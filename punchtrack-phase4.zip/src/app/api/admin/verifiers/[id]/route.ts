import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit } from "@/lib/auth";

const Body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("password"), password: z.string().min(8, "Password must be at least 8 characters.").max(100) }),
  z.object({ action: z.literal("suspend") }),
  z.object({ action: z.literal("reactivate") }),
]);

async function load(id: string) {
  const v = await prisma.user.findUnique({ where: { id } });
  return v && v.role === "VERIFIER" ? v : null;
}

export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: p.error.issues[0]?.message ?? "Invalid request." }, { status: 400 });
  const v = await load(params.id); if (!v) return Response.json({ error: "Verifier not found." }, { status: 404 });
  if (p.data.action === "password") {
    await prisma.user.update({ where: { id: v.id }, data: { passwordHash: await bcrypt.hash(p.data.password, 12) } });
    await prisma.session.deleteMany({ where: { userId: v.id } });
    await audit(g.user.id, "VERIFIER_PASSWORD_CHANGED", v.id);
  } else if (p.data.action === "suspend") {
    await prisma.user.update({ where: { id: v.id }, data: { status: "SUSPENDED" } });
    await prisma.session.deleteMany({ where: { userId: v.id } });
    await audit(g.user.id, "VERIFIER_SUSPENDED", v.id);
  } else {
    await prisma.user.update({ where: { id: v.id }, data: { status: "ACTIVE" } });
    await audit(g.user.id, "VERIFIER_REACTIVATED", v.id);
  }
  return Response.json({ ok: true });
}

export async function DELETE(req: Request, { params }: { params: { id: string } }) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const v = await load(params.id); if (!v) return Response.json({ error: "Verifier not found." }, { status: 404 });
  // Past reviews are part of the attendance audit trail, so a verifier who made them can't be deleted.
  if (await prisma.verifierReview.count({ where: { verifierId: v.id } }) > 0)
    return Response.json({ error: "This verifier has review history that must be kept. Suspend the account instead." }, { status: 409 });
  await prisma.user.delete({ where: { id: v.id } });
  await audit(g.user.id, "VERIFIER_DELETED", v.id, v.username ?? undefined);
  return Response.json({ ok: true });
}
