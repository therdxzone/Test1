import { z } from "zod";
import { prisma } from "@/lib/db";
import { guardApi, audit } from "@/lib/auth";
const Body = z.object({ title: z.string().trim().min(1, "Enter a title.").max(100), body: z.string().trim().min(1, "Enter a message.").max(1000), audience: z.enum(["USERS", "VERIFIERS", "ALL"]) });
export async function POST(req: Request) {
  const g = await guardApi(req, "ADMIN"); if (g.error) return g.error;
  const p = Body.safeParse(await req.json().catch(() => null));
  if (!p.success) return Response.json({ error: p.error.issues[0].message }, { status: 400 });
  const roles = p.data.audience === "USERS" ? ["USER"] : p.data.audience === "VERIFIERS" ? ["VERIFIER"] : ["USER", "VERIFIER"];
  const targets = await prisma.user.findMany({ where: { role: { in: roles as ("USER" | "VERIFIER")[] }, status: { not: "SUSPENDED" } }, select: { id: true } });
  await prisma.notification.createMany({ data: targets.map((t) => ({ userId: t.id, title: p.data.title, body: p.data.body })) });
  await audit(g.user.id, "ANNOUNCEMENT_SENT", undefined, `${p.data.audience}: ${p.data.title} (${targets.length})`);
  return Response.json({ ok: true, sent: targets.length });
}
