import { getBranding } from "@/lib/branding";
import { readStored } from "@/lib/storage";
export const dynamic = "force-dynamic";

// Logo and favicon are public by design (shown on the login page); nothing else is served here.
export async function GET(_: Request, { params }: { params: { kind: string } }) {
  const b = await getBranding();
  const rel = params.kind === "logo" ? b.logoPath : params.kind === "favicon" ? b.faviconPath : null;
  if (!rel) return new Response("Not found", { status: 404 });
  try {
    const data = await readStored(rel);
    const mime = rel.endsWith(".png") ? "image/png" : rel.endsWith(".webp") ? "image/webp" : "image/jpeg";
    return new Response(new Uint8Array(data), { headers: { "Content-Type": mime, "Cache-Control": "public, max-age=300", "X-Content-Type-Options": "nosniff" } });
  } catch { return new Response("Not found", { status: 404 }); }
}
