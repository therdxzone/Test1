import { z } from "zod";
import { prisma } from "@/lib/db";
import { getCurrentUser, sameOrigin, notify, notifyAdmins } from "@/lib/auth";
import { saveImage, deleteStored } from "@/lib/storage";
import { getSettings, dateInTz, isComplete } from "@/lib/attendance";

const Meta = z.object({ slot: z.enum(["MORNING", "EVENING"]), type: z.enum(["FULL", "HALF"]) });
const EDITABLE = ["OPEN", "VERIFIER_REJECTED", "REJECTED"] as const;

export async function POST(req: Request) {
  if (!sameOrigin(req)) return Response.json({ error: "Bad origin." }, { status: 403 });
  const me = await getCurrentUser();
  if (!me || me.role !== "USER" || me.status !== "ACTIVE") return Response.json({ error: "Your account is not active." }, { status: 403 });

  const f = await req.formData().catch(() => null);
  if (!f) return Response.json({ error: "Invalid form." }, { status: 400 });
  const meta = Meta.safeParse({ slot: f.get("slot"), type: f.get("type") });
  const photo = f.get("photo");
  if (!meta.success) return Response.json({ error: "Choose a slot and attendance type." }, { status: 400 });
  if (!(photo instanceof File) || photo.size === 0) return Response.json({ error: "Choose a photo to upload." }, { status: 400 });
  const { slot, type } = meta.data;
  if (type === "HALF" && slot === "EVENING") return Response.json({ error: "A half day only needs the morning photo." }, { status: 400 });

  // Server decides the date. Clients can never choose or backdate it.
  const settings = await getSettings();
  const date = dateInTz(new Date(), settings.timezone);

  let att = await prisma.attendance.findUnique({ where: { userId_date: { userId: me.id, date } }, include: { photos: true } });
  if (!att) {
    try { att = await prisma.attendance.create({ data: { userId: me.id, date, type }, include: { photos: true } }); }
    catch { att = await prisma.attendance.findUnique({ where: { userId_date: { userId: me.id, date } }, include: { photos: true } }); }
  }
  if (!att) return Response.json({ error: "Could not start today's attendance." }, { status: 500 });
  if (!(EDITABLE as readonly string[]).includes(att.status)) return Response.json({ error: "Today's attendance is already submitted and can't be changed." }, { status: 409 });
  const wasRejected = att.status === "VERIFIER_REJECTED" || att.status === "REJECTED";
  if (wasRejected && !settings.resubmitAllowed) return Response.json({ error: "Resubmission is turned off." }, { status: 409 });

  let saved;
  try { saved = await saveImage(photo, "punch"); }
  catch (e) { return Response.json({ error: e instanceof Error ? e.message : "Upload failed." }, { status: 400 }); }

  const old = att.photos.find((p) => p.slot === slot);
  const now = new Date();
  const slots = new Set(att.photos.map((p) => p.slot as string)); slots.add(slot);
  const complete = isComplete(type, [...slots]);

  await prisma.$transaction(async (tx) => {
    await tx.punchPhoto.upsert({
      where: { attendanceId_slot: { attendanceId: att!.id, slot } },
      create: { attendanceId: att!.id, slot, path: saved.path, mime: saved.mime, size: saved.size, capturedAt: now },
      update: { path: saved.path, mime: saved.mime, size: saved.size, capturedAt: now },
    });
    if (wasRejected) {
      await tx.verifierReview.deleteMany({ where: { attendanceId: att!.id } });
      await tx.adminApproval.deleteMany({ where: { attendanceId: att!.id } });
    }
    await tx.attendance.update({ where: { id: att!.id }, data: { type, status: complete ? "SUBMITTED" : "OPEN" } });
  });
  if (old) await deleteStored(old.path);

  if (complete) {
    const asg = await prisma.verifierAssignment.findUnique({ where: { userId: me.id } });
    const msg = `${me.fullName} submitted attendance for ${date}.`;
    if (asg) await notify(asg.verifierId, "Attendance submitted", msg); else await notifyAdmins("Attendance submitted (no verifier assigned)", `${msg} Assign a verifier so it can be reviewed.`);
    await notify(me.id, "Attendance submitted", `Your attendance for ${date} was submitted for review.`);
  }
  return Response.json({ ok: true, submitted: complete });
}
