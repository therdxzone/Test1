import { prisma } from "@/lib/db";
import { getCurrentUser, sameOrigin } from "@/lib/auth";
export async function POST(req: Request) {
  if (!sameOrigin(req)) return Response.json({ error: "Bad origin." }, { status: 403 });
  const me = await getCurrentUser();
  if (!me) return Response.json({ error: "Not allowed." }, { status: 403 });
  await prisma.notification.updateMany({ where: { userId: me.id, read: false }, data: { read: true } });
  return Response.json({ ok: true });
}
