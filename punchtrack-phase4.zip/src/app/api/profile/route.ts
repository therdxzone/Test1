import { prisma } from "@/lib/db";
import { getCurrentUser, sameOrigin, notifyAdmins } from "@/lib/auth";
import { saveImage, deleteStored } from "@/lib/storage";

export async function POST(req: Request) {
  if (!sameOrigin(req)) return Response.json({ error: "Bad origin." }, { status: 403 });
  const me = await getCurrentUser();
  if (!me || me.role !== "USER" || me.status === "SUSPENDED") return Response.json({ error: "Not allowed." }, { status: 403 });
  const profile = await prisma.profile.findUnique({ where: { userId: me.id } });
  if (!profile) return Response.json({ error: "Profile not found." }, { status: 404 });
  if (profile.status === "SUBMITTED" || profile.status === "APPROVED")
    return Response.json({ error: "Your profile can't be edited right now." }, { status: 409 });

  const f = await req.formData().catch(() => null);
  if (!f) return Response.json({ error: "Invalid form." }, { status: 400 });
  const face = f.get("face"), qr = f.get("qr");
  const hasFace = face instanceof File && face.size > 0, hasQr = qr instanceof File && qr.size > 0;
  if (!hasFace && !profile.facePhotoPath) return Response.json({ error: "Upload your face photo." }, { status: 400 });
  if (!hasQr && !profile.qrPhotoPath) return Response.json({ error: "Upload your payment QR code photo." }, { status: 400 });

  try {
    const data: Record<string, unknown> = {};
    if (hasFace) { const s = await saveImage(face as File, "faces"); await deleteStored(profile.facePhotoPath); data.facePhotoPath = s.path; data.facePhotoMime = s.mime; }
    if (hasQr) { const s = await saveImage(qr as File, "qr"); await deleteStored(profile.qrPhotoPath); data.qrPhotoPath = s.path; data.qrPhotoMime = s.mime; }
    await prisma.profile.update({ where: { userId: me.id }, data: {
      ...data, googlePay: f.get("googlePay") === "true", otherPayment: f.get("otherPayment") === "true",
      status: "SUBMITTED", submittedAt: new Date(), rejectionReason: null,
    } });
  } catch (e) {
    return Response.json({ error: e instanceof Error ? e.message : "Upload failed." }, { status: 400 });
  }
  await notifyAdmins("Profile submitted", `${me.fullName} submitted a profile for review.`);
  return Response.json({ ok: true });
}
