import { prisma } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { readStored } from "@/lib/storage";
export const dynamic = "force-dynamic";

// Private image viewer. IDs are random; access is decided here from the database on every request.
export async function GET(_: Request, { params }: { params: { kind: string; id: string } }) {
  const me = await getCurrentUser();
  if (!me || me.status === "SUSPENDED") return new Response("Unauthorized", { status: 401 });
  const { kind, id } = params;
  let file: { path: string | null; mime: string | null } | null = null;
  let ownerId: string | null = null;

  if (kind === "face" || kind === "qr") {
    const p = await prisma.profile.findUnique({ where: { userId: id } });
    if (p) { ownerId = p.userId; file = kind === "face" ? { path: p.facePhotoPath, mime: p.facePhotoMime } : { path: p.qrPhotoPath, mime: p.qrPhotoMime }; }
  } else if (kind === "punch") {
    const ph = await prisma.punchPhoto.findUnique({ where: { id }, include: { attendance: true } });
    if (ph) {
      ownerId = ph.attendance.userId; file = { path: ph.path, mime: ph.mime };
      if (me.role === "VERIFIER") {
        const a = await prisma.verifierAssignment.findFirst({ where: { verifierId: me.id, userId: ownerId } });
        if (!a) return new Response("Forbidden", { status: 403 });
      }
    }
  } else if (kind === "proof") {
    const pr = await prisma.salaryProof.findUnique({ where: { id }, include: { salary: true } });
    if (pr) { ownerId = pr.salary.userId; file = { path: pr.path, mime: pr.mime }; }
  }
  if (!file?.path || !file.mime || !ownerId) return new Response("Not found", { status: 404 });

  const allowed = me.role === "ADMIN" || (me.id === ownerId && me.role === "USER") || (kind === "punch" && me.role === "VERIFIER");
  if (!allowed) return new Response("Forbidden", { status: 403 });

  const data = await readStored(file.path);
  return new Response(new Uint8Array(data), {
    headers: { "Content-Type": file.mime, "Cache-Control": "private, no-store", "X-Content-Type-Options": "nosniff" },
  });
}
