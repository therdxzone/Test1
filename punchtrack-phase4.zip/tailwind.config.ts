import type { Config } from "tailwindcss";
export default {
  content: ["./src/**/*.{ts,tsx}"],
  darkMode: "media",
  theme: { extend: { colors: { brand: "var(--brand)", brand2: "var(--brand2)" } } },
  plugins: [],
} satisfies Config;
