# CloudPlay: Android Cloud Gaming Platform

Upload an APK as admin, publish it, and players run it in a browser. The game executes in a per-session Android emulator on your VPS; the screen is streamed to the browser over WebRTC and input is sent back.

```
Browser ──HTTPS/WSS──> Nginx ──> Node/Express ──docker exec adb──> [ Android emulator container (1 per session) ]
   ^                              │  WebSocket signaling                         │ adb exec-out screenrecord (H.264)
   └──────── WebRTC video <───────┴── ffmpeg decode ── wrtc VideoSource <────────┘
   └──────── WebRTC data channel (touch/keys) ──> sendevent via persistent adb shell
```

## Requirements
- Ubuntu 22.04 / 24.04, x86_64, **hardware virtualization with /dev/kvm** (bare metal or a VPS with nested virtualization)
- 4 GB RAM minimum (about 2.2 GB per concurrent emulator), 25 GB free disk
- Ports 80/443 open. ADB and emulator ports are never published.

## Install (one command)
```bash
sudo bash install.sh
# with HTTPS:
sudo DOMAIN=play.example.com EMAIL=you@example.com bash install.sh
```
The installer checks the OS, virtualization, RAM and disk, installs Docker, Node 20, Nginx, ffmpeg and PM2, creates the database, generates random admin and user passwords (saved to `/root/cloudplay-credentials.txt`, root-only), builds the emulator image, configures Nginx and PM2, and starts the site. Sign in with the **Admin** tab first and change both passwords under *User Settings*.

## Using it
- **Admin**: Upload APK (metadata is read from the APK; name, icon, description, package, RAM, CPU and orientation are editable) → it appears for players immediately.
- **Game controls** (APK Manager): Start/Stop/Restart open an admin test emulator session, Logs shows per-game events, Enable toggle publishes/unpublishes, Delete removes the APK.
- **Player**: Games → Play. The loading screen shows real progress (boot → install → launch). The launch is verified by checking the app's process; if it does not start, the session fails with the reason instead of pretending to run.
- **Controls**: touch the video directly (multi-touch), keyboard (arrows/WASD/space etc.), mouse (acts as a touch). Virtual joystick and buttons are mapped onto screen points: press **Layout**, drag controls, select one, press *Set tap target* and tap the spot in the game. Layouts are saved per game in the browser.

## Persistent installs
Each game has one **persistent emulator instance**: a Docker volume (`cp-inst-<gameId>`) holding that Android system's data, plus a row in the `installations` table (package, version, APK hash, status, install count, timestamps). Play sessions only start and stop a *container* on top of that volume.
- **First Play**: the emulator boots on a fresh instance, the APK is installed, the registry is written, the game launches.
- **Later Plays** (any user, any login, after restarts): the registry and the device are checked; if the game is installed and the APK hash and version match, it is **not** reinstalled and launches directly.
- **Reinstall happens only** when the APK was replaced, the package is missing from the device (corruption) or its version differs, a previous install failed, or an admin chose Reinstall.
- Logging out, exiting, timeouts, crashes, `pm2 restart` and server reboots end the *stream and container* but never delete the volume or registry. Containers are stopped cleanly so Android flushes its data. Only **deleting the game** removes its instance.
- **Admin > APK Manager > Installation**: Verify, Update (install new APK over the old, keeping data), Reinstall, Clear data, Uninstall, plus full status. To publish an update: Edit game > Replace APK, then Update (or let the next launch apply it).

Trade-offs: the instance is per game, so **all players share one game's saves**, and only **one player can use a game at a time** (others get a clear "in use" message). Every game costs disk for its Android data (several GB). Android reboots at each Play (about a minute); only the install is skipped. Per-player instances would need per-user identities, which the shared-password model does not have.

## Configuration
Operational limits (max emulators, RAM/CPU caps, play duration, upload size, login timeout, concurrent logins, user access on/off) are stored in the database and edited in the admin UI. Infrastructure settings live in `.env` (see `.env.example`): emulator image, allowed ABIs, network mode, STUN/TURN.

**Android version / image**: rebuild with build args, then set `EMULATOR_IMAGE`:
```bash
docker build --build-arg API_LEVEL=30 --build-arg TARGET=google_apis_playstore -t cloudplay/android-emulator:api30 emulator/image
```
**TURN (needed for players behind strict NAT)**: install coturn with `use-auth-secret`, then set `TURN_URL=turn:your.host:3478` and `TURN_SECRET=<same secret>`. Credentials handed to browsers are short-lived HMACs.

**Network restriction**: `EMULATOR_NETWORK=cloudplay-emu` (default) is a bridge with inter-container traffic disabled. Use `none` to give games no network at all.

## Security model
Argon2id password hashes; role decided by the server from which hash matched; HttpOnly + SameSite=Strict (+Secure) session cookie holding a random token stored only as a hash; CSRF token on every state-changing request plus Origin checks; login rate limiting; WebSocket auth by the same cookie and ownership of the play session; APK validation (ZIP signature, manifest, dex, path checks, SHA-256 integrity, size cap, ABI compatibility); APKs and icons stored in `storage/`, outside the web root; containers run with memory/CPU/PID limits, `no-new-privileges`, no published ports; audit log of admin and login actions.

Notes: the `cloudplay` service user is in the `docker` group, which is root-equivalent on the host; keep the app host dedicated to this service. Only upload APKs you have the right to distribute and stream.

## Limits you should know about
- Not every APK works: ARM-only games need an image with ARM translation (`EMULATOR_ARM_TRANSLATION=true`), and games that require Google Play services, DRM or GPU features may fail. The platform reports this rather than hiding it.
- Software GPU rendering (`swiftshader_indirect`) is CPU heavy; expect modest frame rates for 3D games. A GPU host and a different emulator GPU mode would improve this.
- Streaming uses `screenrecord` + ffmpeg re-encoding path for simplicity; end-to-end latency is typically a few hundred ms. Touch is injected with `sendevent`; both can be replaced with scrcpy/minitouch-class tooling if you need lower latency.
- SQLite is used now. `DATABASE_URL` is reserved for PostgreSQL; the data layer (`backend/database/db.js`) would need a Postgres adapter.
- The UI uses hand-written CSS using the specified palette, not Tailwind.

## Troubleshooting
| Symptom | Fix |
|---|---|
| Installer: "/dev/kvm is missing" | Enable nested virtualization / choose a KVM-capable plan |
| Play says "Emulator image not found" | `docker build -t cloudplay/android-emulator:latest emulator/image` |
| "All N emulator slots in use" / "Not enough free RAM" | Raise limits in Admin > User Settings or add RAM |
| Stuck on "Booting" then fails | Check `docker ps -a`, `docker logs cp-...`; confirm KVM and enough RAM |
| "The app did not start" | APK incompatible with the emulator (ABI, Play services); see Logs in APK Manager |
| Video never appears, state "Failed" | Configure TURN; check ffmpeg is installed (`node scripts/check.js`) |
| Login works but you are bounced back | Serving over HTTP with `COOKIE_SECURE=true`; use HTTPS or set it to false for testing |
| Large APK upload fails | Raise *Max upload size*; Nginx allows up to 4 GB by default |

Run `node scripts/check.js` for a quick environment self-test. App logs: `pm2 logs cloudplay` as the `cloudplay` user.

## Layout
`backend/` (config, controllers, routes, middleware, services, database, emulator, streaming, security) · `frontend/` · `emulator/image/` (Dockerfile) · `storage/` (APKs, icons, database; private) · `logs/` · `install.sh` · `.env.example`
