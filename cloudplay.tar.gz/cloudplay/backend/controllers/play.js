'use strict';
const { db } = require('../database/db');
const manager = require('../emulator/manager');
const { iceServers } = require('../streaming/signaling');
const { audit } = require('../services/audit');

const pub = (s) => ({ id: s.id, game_id: s.game_id, status: s.status, error: s.error, width: s.width, height: s.height, restarts: s.restarts, expires_at: s.expires_at });

function owned(req, res) {
  const s = manager.getSession(req.params.id);
  if (!s || (s.auth_session_id !== req.auth.id && req.auth.role !== 'admin')) { res.status(404).json({ error: 'Session not found.' }); return null; }
  return s;
}

async function start(req, res) {
  try {
    const gameId = String((req.body || {}).gameId || '');
    const r = await manager.startSession({ authId: req.auth.id, role: req.auth.role, gameId });
    audit(req, 'play_start', gameId);
    res.status(202).json(r);
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
}

function status(req, res) {
  const s = owned(req, res); if (!s) return;
  const g = db.prepare('SELECT name,orientation FROM games WHERE id=?').get(s.game_id) || {};
  res.json({ ...pub(s), game_name: g.name, orientation: g.orientation });
}

async function stop(req, res) {
  const s = owned(req, res); if (!s) return;
  await manager.stopSession(s.id, 'Exited by user');
  audit(req, 'play_stop', s.id);
  res.json({ ok: true });
}

// ICE config for the browser. TURN credentials are short-lived HMAC credentials, not a static secret.
function ice(req, res) {
  const s = owned(req, res); if (!s) return;
  res.json({ iceServers: iceServers() });
}

module.exports = { start, status, stop, ice };
