'use strict';
const { db, settings } = require('../database/db');
const pw = require('../security/passwords');
const sessions = require('../services/authSessions');
const system = require('../services/system');
const { audit } = require('../services/audit');
const manager = require('../emulator/manager');
const installs = require('../emulator/installs');

const ACTIVE = "('starting','booting','installing','launching','running')";

async function overview(_req, res) {
  const sys = await system.snapshot();
  const totalGames = db.prepare('SELECT COUNT(*) c FROM games').get().c;
  const runningGames = db.prepare(`SELECT COUNT(DISTINCT game_id) c FROM play_sessions WHERE status IN ${ACTIVE}`).get().c;
  const emu = db.prepare(`SELECT COUNT(*) c FROM play_sessions WHERE status IN ${ACTIVE}`).get().c;
  res.json({
    totalGames, runningGames, emulators: emu, maxEmulators: settings.int('max_emulators'),
    activeLogins: sessions.countActive(), system: sys, emulatorRuntime: await manager.runtimeStatus(),
  });
}

const sysStats = async (_req, res) => res.json({ ...(await system.snapshot()), emulators: db.prepare(`SELECT COUNT(*) c FROM play_sessions WHERE status IN ${ACTIVE}`).get().c, activeLogins: sessions.countActive() });

const INT_RULES = {
  max_concurrent_sessions: [1, 1000], session_timeout_min: [5, 10080], max_upload_mb: [1, 4096],
  max_emulators: [1, 64], ram_per_emulator_mb: [1024, 32768], cpu_per_emulator: [1, 32], play_duration_min: [5, 1440],
};

function getSettings(_req, res) { res.json(settings.all()); }

function putSettings(req, res) {
  const b = req.body || {};
  const changed = [];
  if (b.site_name !== undefined) {
    const n = String(b.site_name).trim();
    if (!n || n.length > 40) return res.status(400).json({ error: 'Site name must be 1-40 characters.' });
    settings.set('site_name', n); changed.push('site_name');
  }
  if (b.android_label !== undefined) { settings.set('android_label', String(b.android_label).slice(0, 60)); changed.push('android_label'); }
  if (b.user_access_enabled !== undefined) {
    const on = b.user_access_enabled === true || b.user_access_enabled === '1' || b.user_access_enabled === 1;
    settings.set('user_access_enabled', on ? '1' : '0'); changed.push('user_access_enabled=' + (on ? 1 : 0));
    if (!on) {
      for (const s of db.prepare("SELECT id FROM auth_sessions WHERE role='user'").all()) sessions.destroy(s.id);
    }
  }
  for (const [k, [min, max]] of Object.entries(INT_RULES)) {
    if (b[k] === undefined) continue;
    const n = parseInt(b[k], 10);
    if (!Number.isFinite(n) || n < min || n > max) return res.status(400).json({ error: `${k} must be between ${min} and ${max}.` });
    settings.set(k, n); changed.push(`${k}=${n}`);
  }
  audit(req, 'settings_update', changed.join(', '));
  res.json(settings.all());
}

async function changePassword(req, res) {
  const { which, password, currentAdminPassword } = req.body || {};
  if (which !== 'admin' && which !== 'user') return res.status(400).json({ error: 'which must be "admin" or "user".' });
  const bad = pw.validatePassword(password);
  if (bad) return res.status(400).json({ error: bad });
  // Re-authenticate: changing any password needs the current admin password.
  if (!(await pw.verify(settings.get('admin_hash'), String(currentAdminPassword || '')))) return res.status(403).json({ error: 'Current admin password is incorrect.' });
  settings.set(which === 'admin' ? 'admin_hash' : 'user_hash', await pw.hash(password));
  audit(req, 'password_change', which);
  if (which === 'admin') { // invalidate every other admin session
    for (const s of db.prepare("SELECT id FROM auth_sessions WHERE role='admin' AND id != ?").all(req.auth.id)) sessions.destroy(s.id);
  } else {
    for (const s of db.prepare("SELECT id FROM auth_sessions WHERE role='user'").all()) sessions.destroy(s.id);
  }
  res.json({ ok: true });
}

function listSessions(req, res) {
  const logins = sessions.list().map((s) => ({ id: s.id, role: s.role, ip: s.ip, user_agent: s.user_agent, created_at: s.created_at, last_seen: s.last_seen, expires_at: s.expires_at, current: s._full === req.auth.id }));
  const play = db.prepare(`SELECT p.id,p.status,p.error,p.role,p.started_at,p.expires_at,p.game_id,g.name game_name FROM play_sessions p LEFT JOIN games g ON g.id=p.game_id WHERE p.status IN ${ACTIVE} ORDER BY p.started_at DESC`).all();
  res.json({ logins, play });
}

function terminateLogin(req, res) {
  const ok = sessions.destroyByPrefix(String(req.params.id).replace(/[^a-f0-9]/gi, ''));
  if (!ok) return res.status(404).json({ error: 'Session not found.' });
  audit(req, 'session_terminate', req.params.id);
  res.json({ ok: true });
}

async function terminatePlay(req, res) {
  await manager.stopSession(req.params.id, 'Terminated by admin');
  audit(req, 'play_terminate', req.params.id);
  res.json({ ok: true });
}

function auditLogs(req, res) {
  const limit = Math.min(500, parseInt(req.query.limit, 10) || 200);
  res.json(db.prepare('SELECT ts,role,action,detail,ip FROM audit_logs ORDER BY id DESC LIMIT ?').all(limit));
}

// Admin game controls
async function gameStart(req, res) {
  try {
    const r = await manager.startSession({ authId: req.auth.id, role: 'admin', gameId: req.params.id, adminTest: true });
    audit(req, 'game_start', req.params.id);
    res.status(202).json(r);
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
}
async function gameStop(req, res) {
  const n = await manager.stopGame(req.params.id, 'Stopped by admin');
  audit(req, 'game_stop', `${req.params.id} (${n} sessions)`);
  res.json({ ok: true, stopped: n });
}
async function gameRestart(req, res) {
  try {
    await manager.stopGame(req.params.id, 'Restart by admin');
    const r = await manager.startSession({ authId: req.auth.id, role: 'admin', gameId: req.params.id, adminTest: true });
    audit(req, 'game_restart', req.params.id);
    res.status(202).json(r);
  } catch (e) { res.status(e.status || 500).json({ error: e.message }); }
}

async function installStatus(req, res) {
  const g = db.prepare('SELECT * FROM games WHERE id=?').get(req.params.id);
  if (!g) return res.status(404).json({ error: 'Game not found.' });
  const inst = installs.ensure(g);
  const active = db.prepare(`SELECT id,status,op,role,started_at FROM play_sessions WHERE game_id=? AND status IN ${ACTIVE}`).all(g.id);
  res.json({
    registry: inst,
    game: { name: g.name, package_name: g.package_name, version_name: g.version_name, sha256: g.sha256 },
    instance: { volume: inst.volume, exists: await installs.volumeExists(g.id) },
    pendingReason: installs.reason(g, inst), // null = installed & current, will NOT be reinstalled
    activeSessions: active,
  });
}

const INSTALL_OPS = { reinstall: 'reinstall', update: 'update', uninstall: 'uninstall', 'clear-data': 'clear-data', verify: 'verify' };
async function installOp(req, res) {
  const op = INSTALL_OPS[req.params.op];
  if (!op) return res.status(400).json({ error: 'Unknown operation.' });
  const g = db.prepare('SELECT * FROM games WHERE id=?').get(req.params.id);
  if (!g) return res.status(404).json({ error: 'Game not found.' });
  try {
    const inst = installs.ensure(g);
    if (inst.busy_op) return res.status(409).json({ error: `Operation "${inst.busy_op}" is already running for this game.` });
    if (op === 'reinstall') installs.set(g.id, { force_reinstall: 1 });
    await manager.stopGame(g.id, `Stopped for maintenance (${op})`);
    const r = await manager.startSession({ authId: req.auth.id, role: 'admin', gameId: g.id, adminTest: true, op });
    audit(req, 'install_' + op.replace('-', '_'), `${g.name} (${g.id})`);
    res.status(202).json({ ...r, message: `"${op}" started on the game's persistent instance. Check Installation status for the result.` });
  } catch (e) {
    if (op === 'reinstall') installs.set(g.id, { force_reinstall: 0 });
    res.status(e.status || 500).json({ error: e.message });
  }
}

module.exports = { installStatus, installOp, overview, sysStats, getSettings, putSettings, changePassword, listSessions, terminateLogin, terminatePlay, auditLogs, gameStart, gameStop, gameRestart };
