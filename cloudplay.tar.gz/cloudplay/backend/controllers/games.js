'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const multer = require('multer');
const { db, settings } = require('../database/db');
const cfg = require('../config');
const apk = require('../services/apk');
const { audit } = require('../services/audit');
const installs = require('../emulator/installs');

const PUBLIC_COLS = 'id,name,description,package_name,version_name,orientation,enabled,icon_file IS NOT NULL AS has_icon,updated_at';

function runningGameIds() {
  return new Set(db.prepare("SELECT DISTINCT game_id FROM play_sessions WHERE status IN ('starting','booting','installing','launching','running')").all().map((r) => r.game_id));
}

function listForUsers(_req, res) {
  const running = runningGameIds();
  const rows = db.prepare(`SELECT ${PUBLIC_COLS} FROM games WHERE enabled=1 ORDER BY name COLLATE NOCASE`).all();
  res.json(rows.map((g) => ({ ...g, has_icon: !!g.has_icon, running: running.has(g.id) })));
}

function listForAdmin(_req, res) {
  const running = runningGameIds();
  const counts = Object.fromEntries(db.prepare("SELECT game_id, COUNT(*) c FROM play_sessions WHERE status IN ('starting','booting','installing','launching','running') GROUP BY game_id").all().map((r) => [r.game_id, r.c]));
  const rows = db.prepare('SELECT id,name,description,package_name,main_activity,version_name,sha256,size_bytes,abis,orientation,min_ram_mb,cpu_cores,enabled,icon_file IS NOT NULL AS has_icon,created_at,updated_at FROM games ORDER BY created_at DESC').all();
  const inst = Object.fromEntries(db.prepare('SELECT game_id,status,version_name,busy_op,install_count,installed_at,last_launched_at,last_error FROM installations').all().map((r) => [r.game_id, r]));
  res.json(rows.map((g) => ({ ...g, has_icon: !!g.has_icon, enabled: !!g.enabled, running: running.has(g.id), active_sessions: counts[g.id] || 0,
    install: inst[g.id] || { status: 'not_installed', version_name: null, busy_op: null, install_count: 0 } })));
}

function icon(req, res) {
  const g = db.prepare('SELECT icon_file FROM games WHERE id=?').get(req.params.id);
  if (!g || !g.icon_file) return res.status(404).end();
  const f = path.join(cfg.iconDir, path.basename(g.icon_file));
  if (!fs.existsSync(f)) return res.status(404).end();
  res.set('Cache-Control', 'private, max-age=3600');
  res.set('X-Content-Type-Options', 'nosniff');
  res.sendFile(f);
}

// ---- upload handling --------------------------------------------------------------------------
function uploader() {
  const maxBytes = settings.int('max_upload_mb') * 1024 * 1024;
  return multer({
    storage: multer.diskStorage({
      destination: (_req, _file, cb) => cb(null, cfg.tmpDir),
      filename: (_req, _file, cb) => cb(null, crypto.randomUUID() + '.upload'),
    }),
    limits: { fileSize: maxBytes, files: 2, fields: 20, fieldSize: 20000 },
  }).fields([{ name: 'apk', maxCount: 1 }, { name: 'icon', maxCount: 1 }]);
}

function handleUpload(req, res, next) {
  uploader()(req, res, (err) => {
    if (!err) return next();
    const msg = err.code === 'LIMIT_FILE_SIZE' ? `File exceeds the maximum upload size of ${settings.get('max_upload_mb')} MB.` : 'Upload failed: ' + err.message;
    res.status(400).json({ error: msg });
  });
}

const rm = (f) => { try { if (f) fs.unlinkSync(f); } catch { /* ignore */ } };
function cleanupTmp(req) { for (const arr of Object.values(req.files || {})) arr.forEach((f) => rm(f.path)); }

function clampInt(v, min, max, d) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : d;
}

function saveIcon(file, id) {
  const ext = apk.detectImageExt(file.path);
  if (!ext) throw new Error('Icon must be a PNG, JPEG or WebP image.');
  if (file.size > 2 * 1024 * 1024) throw new Error('Icon must be 2 MB or smaller.');
  const name = `${id}${ext}`;
  fs.renameSync(file.path, path.join(cfg.iconDir, name));
  return name;
}

async function create(req, res) {
  try {
    const apkFile = req.files && req.files.apk && req.files.apk[0];
    if (!apkFile) return res.status(400).json({ error: 'APK file is required.' });
    const name = String(req.body.name || '').trim();
    if (!name || name.length > 80) return res.status(400).json({ error: 'Game name is required (max 80 characters).' });

    const meta = await apk.inspect(apkFile.path);
    const packageName = String(req.body.package_name || meta.packageName || '').trim();
    if (!apk.PKG_RE.test(packageName)) return res.status(400).json({ error: 'A valid package name is required. ' + (meta.warning || '') });

    const dup = db.prepare('SELECT id,name FROM games WHERE sha256=?').get(meta.sha256);
    if (dup) return res.status(409).json({ error: `This exact APK is already uploaded as "${dup.name}".` });

    const id = crypto.randomUUID();
    const finalPath = path.join(cfg.apkDir, id + '.apk');
    fs.renameSync(apkFile.path, finalPath);
    // integrity re-check after the move
    if ((await apk.sha256File(finalPath)) !== meta.sha256) { rm(finalPath); return res.status(500).json({ error: 'File integrity check failed after storing the APK.' }); }
    fs.chmodSync(finalPath, 0o640);

    let iconName = null;
    if (req.files.icon && req.files.icon[0]) {
      try { iconName = saveIcon(req.files.icon[0], id); } catch (e) { rm(finalPath); return res.status(400).json({ error: e.message }); }
    }
    const now = Date.now();
    db.prepare(`INSERT INTO games(id,name,description,package_name,main_activity,version_name,sha256,size_bytes,abis,orientation,min_ram_mb,cpu_cores,enabled,icon_file,created_at,updated_at)
      VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      id, name, String(req.body.description || '').slice(0, 2000), packageName, String(req.body.main_activity || meta.mainActivity || ''),
      meta.versionName, meta.sha256, meta.sizeBytes, meta.abis.join(','),
      req.body.orientation === 'portrait' ? 'portrait' : 'landscape',
      clampInt(req.body.min_ram_mb, 1024, 32768, settings.int('ram_per_emulator_mb')),
      clampInt(req.body.cpu_cores, 1, 32, settings.int('cpu_per_emulator')),
      req.body.enabled === '0' || req.body.enabled === 'false' ? 0 : 1, iconName, now, now);
    audit(req, 'game_upload', `${name} (${packageName}) sha256=${meta.sha256.slice(0, 12)}`);
    res.status(201).json({ id, package_name: packageName, warning: meta.warning || null, abis: meta.abis });
  } catch (e) {
    res.status(400).json({ error: e.message });
  } finally {
    cleanupTmp(req);
  }
}

async function update(req, res) {
  try {
    const g = db.prepare('SELECT * FROM games WHERE id=?').get(req.params.id);
    if (!g) return res.status(404).json({ error: 'Game not found.' });
    const b = req.body || {};
    const name = b.name !== undefined ? String(b.name).trim() : g.name;
    if (!name || name.length > 80) return res.status(400).json({ error: 'Invalid name.' });
    const pkg = b.package_name !== undefined ? String(b.package_name).trim() : g.package_name;
    if (!apk.PKG_RE.test(pkg)) return res.status(400).json({ error: 'Invalid package name.' });
    // Optional new APK: becomes the "update". The installed copy is NOT touched until an admin runs
    // Update/Reinstall, or the next launch notices the APK hash changed.
    let newMeta = null;
    if (req.files && req.files.apk && req.files.apk[0]) {
      const f = req.files.apk[0];
      try { newMeta = await apk.inspect(f.path); } catch (e) { return res.status(400).json({ error: e.message }); }
      if (newMeta.packageName && newMeta.packageName !== pkg) return res.status(400).json({ error: `The new APK's package is ${newMeta.packageName}, which differs from this game's package (${pkg}). Upload it as a new game instead.` });
      const dup = db.prepare('SELECT name FROM games WHERE sha256=? AND id<>?').get(newMeta.sha256, g.id);
      if (dup) return res.status(409).json({ error: `This APK is already uploaded as "${dup.name}".` });
      if (newMeta.sha256 === g.sha256) return res.status(400).json({ error: 'This APK is identical to the current one.' });
      await require('../emulator/manager').stopGame(g.id, 'APK being replaced');
      const dest = path.join(cfg.apkDir, g.id + '.apk');
      fs.renameSync(f.path, dest); fs.chmodSync(dest, 0o640);
      if ((await apk.sha256File(dest)) !== newMeta.sha256) return res.status(500).json({ error: 'File integrity check failed after storing the APK.' });
      db.prepare('UPDATE games SET sha256=?,size_bytes=?,version_name=?,abis=? WHERE id=?').run(newMeta.sha256, newMeta.sizeBytes, newMeta.versionName, newMeta.abis.join(','), g.id);
      audit(req, 'game_apk_replace', `${g.name} ${g.version_name || '?'} -> ${newMeta.versionName || '?'}`);
    }
    let iconName = g.icon_file;
    if (req.files && req.files.icon && req.files.icon[0]) {
      try { iconName = saveIcon(req.files.icon[0], g.id); } catch (e) { return res.status(400).json({ error: e.message }); }
    }
    db.prepare(`UPDATE games SET name=?,description=?,package_name=?,main_activity=?,orientation=?,min_ram_mb=?,cpu_cores=?,enabled=?,icon_file=?,updated_at=? WHERE id=?`).run(
      name, b.description !== undefined ? String(b.description).slice(0, 2000) : g.description, pkg,
      b.main_activity !== undefined ? String(b.main_activity).trim() : g.main_activity,
      b.orientation ? (b.orientation === 'portrait' ? 'portrait' : 'landscape') : g.orientation,
      b.min_ram_mb !== undefined ? clampInt(b.min_ram_mb, 1024, 32768, g.min_ram_mb) : g.min_ram_mb,
      b.cpu_cores !== undefined ? clampInt(b.cpu_cores, 1, 32, g.cpu_cores) : g.cpu_cores,
      b.enabled !== undefined ? (b.enabled === true || b.enabled === '1' || b.enabled === 'true' || b.enabled === 1 ? 1 : 0) : g.enabled,
      iconName, Date.now(), g.id);
    if (b.enabled !== undefined && !(b.enabled === true || b.enabled === '1' || b.enabled === 'true' || b.enabled === 1)) {
      require('../emulator/manager').stopGame(g.id, 'Game disabled by admin');
    }
    audit(req, 'game_update', `${name} (${g.id})`);
    res.json({ ok: true, apkReplaced: !!newMeta, note: newMeta ? 'New APK stored. Use "Update" in Installation to apply it now, or it installs automatically on the next launch.' : null });
  } finally { cleanupTmp(req); }
}

async function remove(req, res) {
  const g = db.prepare('SELECT * FROM games WHERE id=?').get(req.params.id);
  if (!g) return res.status(404).json({ error: 'Game not found.' });
  await require('../emulator/manager').stopGame(g.id, 'Game deleted');
  rm(path.join(cfg.apkDir, g.id + '.apk'));
  if (g.icon_file) rm(path.join(cfg.iconDir, path.basename(g.icon_file)));
  db.prepare('DELETE FROM games WHERE id=?').run(g.id);
  db.prepare('DELETE FROM game_logs WHERE game_id=?').run(g.id);
  db.prepare('DELETE FROM installations WHERE game_id=?').run(g.id);
  await installs.removeVolume(g.id); // deleting a game is the only automatic removal of its persistent data
  audit(req, 'game_delete', `${g.name} (${g.id})`);
  res.json({ ok: true });
}

function logs(req, res) {
  const rows = db.prepare('SELECT ts,level,message,play_id FROM game_logs WHERE game_id=? ORDER BY id DESC LIMIT 300').all(req.params.id);
  res.json(rows.reverse());
}

module.exports = { listForUsers, listForAdmin, icon, handleUpload, create, update, remove, logs };
