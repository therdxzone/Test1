'use strict';
const argon2 = require('argon2');
const crypto = require('crypto');

const OPTS = { type: argon2.argon2id, memoryCost: 19456, timeCost: 2, parallelism: 1 };

const hash = (pw) => argon2.hash(pw, OPTS);
async function verify(h, pw) {
  if (!h) return false;
  try { return await argon2.verify(h, pw); } catch { return false; }
}
const sha256 = (s) => crypto.createHash('sha256').update(s).digest('hex');
const randomToken = (bytes = 32) => crypto.randomBytes(bytes).toString('base64url');
function randomPassword(len = 18) {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789';
  let out = '';
  const buf = crypto.randomBytes(len);
  for (let i = 0; i < len; i++) out += chars[buf[i] % chars.length];
  return out;
}
function validatePassword(pw) {
  if (typeof pw !== 'string' || pw.length < 8) return 'Password must be at least 8 characters.';
  if (pw.length > 200) return 'Password is too long.';
  return null;
}
module.exports = { hash, verify, sha256, randomToken, randomPassword, validatePassword };
