'use strict';
// Installation registry helpers. The registry (DB) is the source of truth for "what should be installed";
// the device is probed to confirm it. State outlives sessions, logouts and server restarts.
const { db } = require('../database/db');
const { adbShell, docker } = require('./docker');

const volumeName = (gameId) => 'cp-inst-' + gameId;
const SAFE_PKG = /^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$/;

const get = (gameId) => db.prepare('SELECT * FROM installations WHERE game_id=?').get(gameId);

function ensure(game) {
  let r = get(game.id);
  if (!r) {
    db.prepare('INSERT INTO installations(game_id,package_name,volume,status,updated_at) VALUES(?,?,?,?,?)')
      .run(game.id, game.package_name, volumeName(game.id), 'not_installed', Date.now());
    r = get(game.id);
  }
  return r;
}

function set(gameId, fields) {
  const keys = Object.keys(fields);
  if (!keys.length) return;
  db.prepare(`UPDATE installations SET ${keys.map((k) => `${k}=?`).join(',')},updated_at=? WHERE game_id=?`)
    .run(...keys.map((k) => fields[k]), Date.now(), gameId);
}

// Why would we have to (re)install? null means: already installed and compatible, do NOT reinstall.
function reason(game, inst) {
  if (inst.status === 'not_installed' || inst.status === 'uninstalled') return 'first install';
  if (inst.status !== 'installed') return `previous install ended in state "${inst.status}"`;
  if (inst.force_reinstall) return 'reinstall requested by admin';
  if (inst.package_name !== game.package_name) return 'package name changed';
  if (inst.apk_sha256 !== game.sha256) return 'APK was updated';
  return null;
}

async function deviceState(container, pkg) {
  if (!SAFE_PKG.test(pkg)) throw new Error('Invalid package name.');
  const p = await adbShell(container, `pm path ${pkg}`, { timeout: 15000 }).catch(() => ({ stdout: '' }));
  const installed = /package:/.test(p.stdout);
  let versionName = '';
  if (installed) {
    const d = await adbShell(container, `dumpsys package ${pkg} | grep -m1 versionName`, { timeout: 15000 }).catch(() => ({ stdout: '' }));
    const m = /versionName=(\S+)/.exec(d.stdout);
    if (m) versionName = m[1];
  }
  return { installed, versionName };
}

async function volumeExists(gameId) {
  try { await docker(['volume', 'inspect', volumeName(gameId)], { timeout: 8000 }); return true; } catch { return false; }
}
const removeVolume = (gameId) => docker(['volume', 'rm', '-f', volumeName(gameId)], { timeout: 30000 }).catch(() => {});

module.exports = { volumeName, get, ensure, set, reason, deviceState, volumeExists, removeVolume };
