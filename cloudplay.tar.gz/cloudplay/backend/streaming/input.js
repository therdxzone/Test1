'use strict';
// Forwards browser input into the emulator. Touch uses multitouch protocol-B sendevent through ONE
// persistent `adb shell`, so there is no per-event process start-up cost on the Android side.
const { spawnAdb, adbShell } = require('../emulator/docker');

const KEYMAP = { // browser KeyboardEvent.code -> Android keycode
  ArrowUp: 19, ArrowDown: 20, ArrowLeft: 21, ArrowRight: 22, Enter: 66, Space: 62, Escape: 4, Backspace: 67, Tab: 61,
  KeyW: 51, KeyA: 29, KeyS: 47, KeyD: 32, KeyQ: 45, KeyE: 33, KeyR: 46, KeyF: 34, KeyZ: 54, KeyX: 52, KeyC: 31, KeyV: 50,
  ShiftLeft: 59, ControlLeft: 113, Digit1: 8, Digit2: 9, Digit3: 10, Digit4: 11, Digit5: 12, Home: 3, F1: 82,
};

class InputBridge {
  constructor(container, width, height) {
    this.container = container; this.w = width; this.h = height;
    this.shell = null; this.ready = false; this.dev = null; this.max = null;
    this.slots = new Map(); // pointer id -> slot index
    this.pending = new Map(); // coalesced move events by slot
    this.timer = null; this.closed = false;
    this.init().catch((e) => { this.error = e.message; });
  }

  async init() {
    const out = (await adbShell(this.container, 'getevent -lp', { timeout: 15000 })).stdout;
    // find the device that reports ABS_MT_POSITION_X
    const blocks = out.split(/^add device \d+: /m).slice(1);
    for (const b of blocks) {
      if (!/ABS_MT_POSITION_X/.test(b)) continue;
      const path = b.split('\n')[0].trim();
      const mx = /ABS_MT_POSITION_X\s*:.*?max (\d+)/.exec(b); const my = /ABS_MT_POSITION_Y\s*:.*?max (\d+)/.exec(b);
      if (mx && my) { this.dev = path; this.max = { x: +mx[1], y: +my[1] }; break; }
    }
    if (!this.dev) throw new Error('No touchscreen input device found in emulator.');
    this.shell = spawnAdb(this.container, ['shell']);
    this.shell.on('exit', () => { this.ready = false; });
    this.shell.stdin.on('error', () => {});
    this.ready = true;
  }

  // Emulated panel orientation: touch panel axes follow the *natural* (portrait) orientation.
  // We lock rotation in the emulator, so map landscape coordinates accordingly.
  map(nx, ny, landscape) {
    nx = Math.min(1, Math.max(0, nx)); ny = Math.min(1, Math.max(0, ny));
    if (!landscape) return [Math.round(nx * this.max.x), Math.round(ny * this.max.y)];
    // rotation 90deg: screen x -> panel y, screen y inverted -> panel x
    return [Math.round((1 - ny) * this.max.x), Math.round(nx * this.max.y)];
  }

  send(lines) {
    if (!this.ready || this.closed) return;
    const d = this.dev;
    this.shell.stdin.write(lines.map(([t, c, v]) => `sendevent ${d} ${t} ${c} ${v}`).join('; ') + '\n');
  }

  slotFor(id) {
    if (this.slots.has(id)) return this.slots.get(id);
    for (let s = 0; s < 10; s++) if (![...this.slots.values()].includes(s)) { this.slots.set(id, s); return s; }
    return null;
  }

  touch(a, id, nx, ny) {
    if (!this.ready) return;
    const landscape = this.w > this.h;
    const EV_ABS = 3, EV_SYN = 0, MT_SLOT = 47, MT_ID = 57, MT_X = 53, MT_Y = 54, SYN_REPORT = 0;
    if (a === 'down') {
      const slot = this.slotFor(id); if (slot === null) return;
      const [x, y] = this.map(nx, ny, landscape);
      this.pending.delete(slot);
      this.send([[EV_ABS, MT_SLOT, slot], [EV_ABS, MT_ID, 1000 + slot], [EV_ABS, MT_X, x], [EV_ABS, MT_Y, y], [EV_SYN, SYN_REPORT, 0]]);
    } else if (a === 'move') {
      if (!this.slots.has(id)) return;
      const slot = this.slots.get(id); const [x, y] = this.map(nx, ny, landscape);
      this.pending.set(slot, [x, y]);
      if (!this.timer) this.timer = setTimeout(() => this.flush(), 16); // coalesce to ~60 Hz
    } else if (a === 'up') {
      if (!this.slots.has(id)) return;
      const slot = this.slots.get(id); this.slots.delete(id); this.pending.delete(slot);
      this.send([[EV_ABS, MT_SLOT, slot], [EV_ABS, MT_ID, 0xffffffff], [EV_SYN, SYN_REPORT, 0]]);
    }
  }

  flush() {
    this.timer = null;
    if (!this.pending.size) return;
    const EV_ABS = 3, EV_SYN = 0, MT_SLOT = 47, MT_X = 53, MT_Y = 54;
    const ev = [];
    for (const [slot, [x, y]] of this.pending) ev.push([EV_ABS, MT_SLOT, slot], [EV_ABS, MT_X, x], [EV_ABS, MT_Y, y]);
    ev.push([EV_SYN, 0, 0]);
    this.pending.clear();
    this.send(ev);
  }

  key(code) {
    const k = KEYMAP[code]; if (!k || !this.ready) return;
    this.shell.stdin.write(`input keyevent ${k}\n`);
  }
  back() { if (this.ready) this.shell.stdin.write('input keyevent 4\n'); }

  close() {
    this.closed = true;
    if (this.timer) clearTimeout(this.timer);
    try { this.shell && this.shell.kill(); } catch { /* ignore */ }
  }
}

module.exports = { InputBridge };
