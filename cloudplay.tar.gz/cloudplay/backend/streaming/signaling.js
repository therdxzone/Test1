'use strict';
// WebSocket signaling + per-session WebRTC peers. Auth = the same HttpOnly session cookie as the HTTP API,
// plus an Origin check; a user may only attach to the play session that belongs to their own login.
const { WebSocketServer } = require('ws');
const crypto = require('crypto');
const { RTCPeerConnection } = require('@roamhq/wrtc');
const cfg = require('../config');
const sessions = require('../services/authSessions');
const manager = require('../emulator/manager');
const { CapturePipeline } = require('./pipeline');
const { InputBridge } = require('./input');
const { db } = require('../database/db');

const live = new Map(); // playId -> { pipeline, input, peers:Set }

function iceServers() {
  const list = [];
  if (cfg.stream.stun.length) list.push({ urls: cfg.stream.stun });
  if (cfg.stream.turnUrl && cfg.stream.turnSecret) {
    const expiry = Math.floor(Date.now() / 1000) + 6 * 3600;
    const username = `${expiry}:cloudplay`;
    const credential = crypto.createHmac('sha1', cfg.stream.turnSecret).update(username).digest('base64');
    list.push({ urls: cfg.stream.turnUrl.split(',').map((s) => s.trim()), username, credential });
  }
  return list;
}

function ensureLive(play) {
  let l = live.get(play.id);
  if (l) return l;
  l = { pipeline: new CapturePipeline(play.container, play.width, play.height), input: new InputBridge(play.container, play.width, play.height), peers: new Set() };
  live.set(play.id, l);
  return l;
}
function teardown(playId) {
  const l = live.get(playId); if (!l) return;
  live.delete(playId);
  for (const p of l.peers) { try { p.pc.close(); } catch { /* ignore */ } try { p.ws.close(4000, 'session ended'); } catch { /* ignore */ } }
  l.pipeline.close(); l.input.close();
}
manager.events.on('stopped', teardown);

function attach(server) {
  const wss = new WebSocketServer({ noServer: true, maxPayload: 64 * 1024 });

  server.on('upgrade', (req, socket, head) => {
    try {
      const url = new URL(req.url, 'http://x');
      if (url.pathname !== '/ws/signal') return socket.destroy();
      const origin = req.headers.origin;
      if (!origin || new URL(origin).host !== req.headers.host) { socket.write('HTTP/1.1 403 Forbidden\r\n\r\n'); return socket.destroy(); }
      const cookies = {};
      for (const part of String(req.headers.cookie || '').split(';')) { const i = part.indexOf('='); if (i > 0) cookies[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim()); }
      const auth = sessions.lookup(cookies[sessions.COOKIE]);
      if (!auth) { socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n'); return socket.destroy(); }
      const play = db.prepare('SELECT * FROM play_sessions WHERE id=?').get(url.searchParams.get('session'));
      if (!play || play.auth_session_id !== auth.id) { socket.write('HTTP/1.1 403 Forbidden\r\n\r\n'); return socket.destroy(); }
      wss.handleUpgrade(req, socket, head, (ws) => onConnection(ws, auth, play.id));
    } catch { socket.destroy(); }
  });
}

function onConnection(ws, auth, playId) {
  const peer = { ws, pc: null };
  const send = (o) => { if (ws.readyState === 1) ws.send(JSON.stringify(o)); };
  const play = () => manager.getSession(playId);

  ws.on('message', async (raw) => {
    let m; try { m = JSON.parse(raw.toString()); } catch { return; }
    const p = play();
    if (!p || p.status !== 'running') return send({ type: 'error', message: 'Game is not running.' });
    const l = ensureLive(p);
    try {
      if (m.type === 'offer') {
        if (peer.pc) { try { peer.pc.close(); } catch { /* ignore */ } l.peers.delete(peer); }
        const pc = new RTCPeerConnection({ iceServers: iceServers() });
        peer.pc = pc; l.peers.add(peer);
        pc.onicecandidate = (e) => { if (e.candidate) send({ type: 'candidate', candidate: e.candidate }); };
        pc.onconnectionstatechange = () => send({ type: 'state', state: pc.connectionState });
        pc.ondatachannel = (ev) => {
          ev.channel.onmessage = (me) => handleInput(l.input, me.data);
        };
        await pc.setRemoteDescription(m.sdp);
        const tr = pc.getTransceivers().find((t) => t.receiver && t.receiver.track && t.receiver.track.kind === 'video');
        if (tr) { tr.direction = 'sendonly'; await tr.sender.replaceTrack(l.pipeline.track); } else pc.addTrack(l.pipeline.track);
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        send({ type: 'answer', sdp: pc.localDescription });
      } else if (m.type === 'candidate' && peer.pc && m.candidate) {
        await peer.pc.addIceCandidate(m.candidate);
      } else if (m.type === 'input') { // WebSocket fallback when the data channel is not open
        handleInput(l.input, JSON.stringify(m.data));
      } else if (m.type === 'ping') send({ type: 'pong' });
    } catch (e) { send({ type: 'error', message: e.message }); }
  });

  ws.on('close', () => {
    const l = live.get(playId);
    if (l) { l.peers.delete(peer); try { peer.pc && peer.pc.close(); } catch { /* ignore */ } }
  });
  send({ type: 'hello', ice: iceServers() });
}

function handleInput(input, data) {
  let e; try { e = JSON.parse(data); } catch { return; }
  if (!e || typeof e !== 'object') return;
  if (e.t === 'touch' && ['down', 'move', 'up'].includes(e.a) && Number.isInteger(e.id) && e.id >= 0 && e.id < 1000) {
    input.touch(e.a, e.id, Number(e.x) || 0, Number(e.y) || 0);
  } else if (e.t === 'key' && typeof e.code === 'string' && e.down) input.key(e.code);
  else if (e.t === 'back') input.back();
}

module.exports = { attach, iceServers, teardown };
