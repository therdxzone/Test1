'use strict';
// Real VPS statistics only: /proc, os, df. Nothing is simulated.
const os = require('os');
const fs = require('fs');
const { execFile } = require('child_process');
const cfg = require('../config');

let lastCpu = snapCpu();
let cpuPct = 0;
let lastNet = readNet();
let netRate = { rxBps: 0, txBps: 0 };
let lastNetTs = Date.now();

function snapCpu() {
  let idle = 0, total = 0;
  for (const c of os.cpus()) { for (const t of Object.values(c.times)) total += t; idle += c.times.idle; }
  return { idle, total };
}
function readNet() {
  try {
    let rx = 0, tx = 0;
    for (const line of fs.readFileSync('/proc/net/dev', 'utf8').split('\n').slice(2)) {
      const [name, rest] = line.split(':');
      if (!rest || name.trim() === 'lo') continue;
      const f = rest.trim().split(/\s+/).map(Number);
      rx += f[0]; tx += f[8];
    }
    return { rx, tx };
  } catch { return { rx: 0, tx: 0 }; }
}

function sample() {
  const c = snapCpu();
  const dIdle = c.idle - lastCpu.idle; const dTotal = c.total - lastCpu.total;
  cpuPct = dTotal > 0 ? Math.round((1 - dIdle / dTotal) * 1000) / 10 : 0;
  lastCpu = c;
  const n = readNet(); const now = Date.now(); const dt = (now - lastNetTs) / 1000;
  if (dt > 0) netRate = { rxBps: Math.max(0, (n.rx - lastNet.rx) / dt), txBps: Math.max(0, (n.tx - lastNet.tx) / dt) };
  lastNet = n; lastNetTs = now;
}
setInterval(sample, 2000).unref();

function memInfo() {
  let total = os.totalmem(); let avail = os.freemem();
  try {
    const m = fs.readFileSync('/proc/meminfo', 'utf8');
    const t = /MemTotal:\s+(\d+)/.exec(m); const a = /MemAvailable:\s+(\d+)/.exec(m);
    if (t) total = Number(t[1]) * 1024;
    if (a) avail = Number(a[1]) * 1024;
  } catch { /* fall back to os */ }
  return { totalBytes: total, availableBytes: avail, usedBytes: total - avail };
}

function disk() {
  return new Promise((resolve) => {
    execFile('df', ['-k', '--output=size,used,avail', cfg.dataDir], { timeout: 4000 }, (err, out) => {
      if (err) return resolve({ totalBytes: 0, usedBytes: 0, availableBytes: 0, error: err.message });
      const p = out.trim().split('\n').pop().trim().split(/\s+/).map((x) => Number(x) * 1024);
      resolve({ totalBytes: p[0], usedBytes: p[1], availableBytes: p[2] });
    });
  });
}

async function snapshot() {
  const mem = memInfo();
  return {
    cpu: { percent: cpuPct, cores: os.cpus().length, load: os.loadavg() },
    mem,
    disk: await disk(),
    net: netRate,
    uptimeSec: Math.round(os.uptime()),
    kvm: fs.existsSync('/dev/kvm'),
    ts: Date.now(),
  };
}

module.exports = { snapshot, memInfo, cpuPercent: () => cpuPct, cores: () => os.cpus().length };
