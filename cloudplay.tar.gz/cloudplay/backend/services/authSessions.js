'use strict';
const { db, settings } = require('../database/db');
const { randomToken, sha256 } = require('../security/passwords');

const COOKIE = 'cp_sid';

function create(role, req) {
  const now = Date.now();
  const timeoutMs = settings.int('session_timeout_min') * 60000;
  const token = randomToken(32);
  const csrf = randomToken(24);
  db.prepare(`INSERT INTO auth_sessions(id,role,csrf,ip,user_agent,created_at,last_seen,expires_at) VALUES(?,?,?,?,?,?,?,?)`)
    .run(sha256(token), role, csrf, req.ip || '', String(req.headers['user-agent'] || '').slice(0, 200), now, now, now + timeoutMs);
  return { token, csrf };
}

// Returns {id, role, csrf} or null. Slides expiry forward (idle timeout).
function lookup(token) {
  if (!token || typeof token !== 'string' || token.length > 100) return null;
  const id = sha256(token);
  const row = db.prepare('SELECT * FROM auth_sessions WHERE id = ?').get(id);
  if (!row) return null;
  const now = Date.now();
  if (row.expires_at < now) { destroy(id); return null; }
  if (row.role === 'user' && settings.get('user_access_enabled') !== '1') return null;
  const timeoutMs = settings.int('session_timeout_min') * 60000;
  db.prepare('UPDATE auth_sessions SET last_seen=?, expires_at=? WHERE id=?').run(now, now + timeoutMs, id);
  return { id: row.id, role: row.role, csrf: row.csrf };
}

function destroy(id) {
  db.prepare('DELETE FROM auth_sessions WHERE id = ?').run(id);
  // callback registered by emulator manager to stop emulators of this login
  for (const fn of destroy.hooks) { try { fn(id); } catch (e) { console.error(e); } }
}
destroy.hooks = [];

function purgeExpired() {
  const rows = db.prepare('SELECT id FROM auth_sessions WHERE expires_at < ?').all(Date.now());
  rows.forEach((r) => destroy(r.id));
}

function countActive(role) {
  const q = role ? 'SELECT COUNT(*) c FROM auth_sessions WHERE expires_at>? AND role=?' : 'SELECT COUNT(*) c FROM auth_sessions WHERE expires_at>?';
  return (role ? db.prepare(q).get(Date.now(), role) : db.prepare(q).get(Date.now())).c;
}

function list() {
  return db.prepare('SELECT id,role,ip,user_agent,created_at,last_seen,expires_at FROM auth_sessions WHERE expires_at>? ORDER BY last_seen DESC').all(Date.now())
    .map((r) => ({ ...r, id: r.id.slice(0, 16) , _full: r.id }));
}

function destroyByPrefix(prefix) {
  const row = db.prepare('SELECT id FROM auth_sessions WHERE id LIKE ? LIMIT 2').all(prefix + '%');
  if (row.length !== 1) return false;
  destroy(row[0].id);
  return true;
}

module.exports = { COOKIE, create, lookup, destroy, purgeExpired, countActive, list, destroyByPrefix };
