'use strict';
// Creates the database and seeds initial passwords. Prints them ONCE (stdout) if generated.
// Usage: node backend/database/init.js   (reads ADMIN_INITIAL_PASSWORD / USER_INITIAL_PASSWORD from env if set)
const { db, settings } = require('./db');
const pw = require('../security/passwords');

(async () => {
  const out = {};
  if (!settings.get('admin_hash')) {
    const p = process.env.ADMIN_INITIAL_PASSWORD || pw.randomPassword();
    settings.set('admin_hash', await pw.hash(p));
    out.admin = p;
  }
  if (!settings.get('user_hash')) {
    const p = process.env.USER_INITIAL_PASSWORD || pw.randomPassword();
    settings.set('user_hash', await pw.hash(p));
    out.user = p;
  }
  for (const [k, v] of Object.entries(settings.DEFAULTS)) {
    if (db.prepare('SELECT 1 FROM settings WHERE key=?').get(k) === undefined) settings.set(k, v);
  }
  if (out.admin) console.log('INITIAL_ADMIN_PASSWORD=' + out.admin);
  if (out.user) console.log('INITIAL_USER_PASSWORD=' + out.user);
  if (!out.admin && !out.user) console.log('Database already initialised; passwords unchanged.');
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });
