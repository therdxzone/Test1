'use strict';
const $ = (s, r = document) => r.querySelector(s);
const view = $('#view');
let ME = null; let timer = null;

const USER_NAV = [['games', 'Games']];
const ADMIN_NAV = [['overview', 'Overview'], ['games', 'Game Library'], ['apks', 'APK Manager'], ['settings', 'User Settings'], ['monitor', 'VPS Monitoring'], ['logs', 'Activity Logs']];

async function init() {
  try { ME = await API.get('/auth/me'); } catch { location.href = '/'; return; }
  API.csrf = ME.csrf;
  document.querySelectorAll('.site-name').forEach((e) => { e.textContent = ME.siteName; });
  document.title = ME.siteName;
  const nav = ME.role === 'admin' ? ADMIN_NAV : USER_NAV;
  $('#nav').innerHTML = nav.map(([k, l]) => `<a href="#${k}" data-k="${k}">${l}</a>`).join('');
  $('#burger').onclick = () => $('#sidebar').classList.toggle('open');
  $('#sidebar').addEventListener('click', (e) => { if (e.target.closest('a')) $('#sidebar').classList.remove('open'); });
  $('#logout').onclick = async () => { await API.post('/auth/logout').catch(() => {}); location.href = '/'; };
  window.addEventListener('hashchange', route);
  route();
}

function route() {
  clearInterval(timer); timer = null;
  const allowed = (ME.role === 'admin' ? ADMIN_NAV : USER_NAV).map((n) => n[0]);
  let k = location.hash.slice(1);
  if (!allowed.includes(k)) k = ME.role === 'admin' ? 'overview' : 'games';
  document.querySelectorAll('#nav a').forEach((a) => a.classList.toggle('active', a.dataset.k === k));
  view.innerHTML = '<div class="center"><span class="spin"></span></div>';
  ({ games: vGames, overview: vOverview, apks: vApks, settings: vSettings, monitor: vMonitor, logs: vLogs })[k]().catch((e) => { view.innerHTML = `<div class="card">${esc(e.message)}</div>`; });
}

const pct = (a, b) => (b ? Math.min(100, Math.round((a / b) * 100)) : 0);
const meter = (label, value, sub, p) => `<div class="card stat"><div class="l">${label}</div><div class="v">${value}</div><div class="l">${sub || ''}</div><div class="bar"><i style="width:${p}%"></i></div></div>`;

// ---------------- User dashboard ----------------
async function vGames() {
  const games = await API.get('/games');
  view.innerHTML = `<div class="page-head"><div><h1>Games</h1><div class="muted small">Games run on our servers and stream to you. Nothing is installed on your device.</div></div>
    <div style="min-width:min(260px,100%)"><input id="q" type="search" placeholder="Search games..."></div></div><div class="grid games" id="gl"></div>`;
  const draw = () => {
    const q = $('#q').value.trim().toLowerCase();
    const list = games.filter((g) => g.name.toLowerCase().includes(q));
    $('#gl').innerHTML = list.length ? list.map((g) => `
      <div class="card game"><div class="art">${g.has_icon ? `<img loading="lazy" alt="" src="/api/games/${g.id}/icon?v=${g.updated_at}">` : `<span class="ph">${esc(g.name[0] || '?')}</span>`}
        <span class="badge ${g.running ? 'ok' : 'off'}">${g.running ? 'Running' : 'Stopped'}</span></div>
        <div class="body"><b>${esc(g.name)}</b><p>${esc(g.description) || 'No description.'}</p>
        <button class="btn primary block" data-play="${g.id}">Play</button></div></div>`).join('')
      : `<div class="card center muted" style="grid-column:1/-1">${games.length ? 'No games match your search.' : 'No games have been published yet.'}</div>`;
  };
  $('#q').oninput = draw; draw();
  $('#gl').onclick = async (e) => {
    const b = e.target.closest('[data-play]'); if (!b) return;
    b.disabled = true; b.innerHTML = '<span class="spin"></span>';
    try { const r = await API.post('/play', { gameId: b.dataset.play }); location.href = `/player.html?s=${r.id}`; }
    catch (err) { toast(err.message, 'err'); b.disabled = false; b.textContent = 'Play'; }
  };
  timer = setInterval(async () => { try { const g = await API.get('/games'); g.forEach((n) => { const o = games.find((x) => x.id === n.id); if (o) o.running = n.running; }); if (!document.activeElement || document.activeElement.id !== 'q') draw(); } catch { /* ignore */ } }, 8000);
}

// ---------------- Admin: overview ----------------
async function vOverview() {
  const draw = async () => {
    const o = await API.get('/admin/overview'); const s = o.system; const rt = o.emulatorRuntime;
    const rtOk = rt.docker && rt.imagePresent && (rt.kvm || !rt.error);
    view.innerHTML = `<div class="page-head"><h1>Overview</h1></div>
    <div class="grid stats">
      <div class="card stat"><div class="l">Uploaded games</div><div class="v">${o.totalGames}</div></div>
      <div class="card stat"><div class="l">Running games</div><div class="v">${o.runningGames}</div></div>
      <div class="card stat"><div class="l">Active logins</div><div class="v">${o.activeLogins}</div></div>
      <div class="card stat"><div class="l">Emulators</div><div class="v">${o.emulators} / ${o.maxEmulators}</div></div>
    </div><div class="grid stats" style="margin-top:1rem">
      ${meter('CPU', s.cpu.percent + '%', s.cpu.cores + ' cores', s.cpu.percent)}
      ${meter('RAM', bytes(s.mem.usedBytes), 'of ' + bytes(s.mem.totalBytes), pct(s.mem.usedBytes, s.mem.totalBytes))}
      ${meter('Disk', bytes(s.disk.usedBytes), 'of ' + bytes(s.disk.totalBytes), pct(s.disk.usedBytes, s.disk.totalBytes))}
    </div>
    <div class="card" style="margin-top:1rem"><h2>Emulator runtime</h2><div class="row" style="margin-top:.7rem">
      <span class="badge ${rt.docker ? 'ok' : 'bad'}">Docker ${rt.docker ? 'ready' : 'unavailable'}</span>
      <span class="badge ${rt.imagePresent ? 'ok' : 'bad'}">Image ${rt.imagePresent ? 'present' : 'missing'}</span>
      <span class="badge ${rt.kvm ? 'ok' : 'bad'}">KVM ${rt.kvm ? 'available' : 'missing'}</span>
      <span class="badge ${rtOk ? 'ok' : 'warn'}">${rtOk ? 'Ready to launch' : 'Not ready'}</span></div>
      <div class="muted small" style="margin-top:.6rem">Image: <span class="mono">${esc(rt.image)}</span> &middot; ABIs: ${esc(rt.abis.join(', '))}</div>
      ${rt.error ? `<div class="err-text" style="margin-top:.6rem">${esc(rt.error)}</div>` : ''}</div>`;
  };
  await draw(); timer = setInterval(() => draw().catch(() => {}), 4000);
}

// ---------------- Admin: APK manager ----------------
async function vApks() {
  const games = await API.get('/admin/games');
  view.innerHTML = `<div class="page-head"><h1>APK Manager</h1><button class="btn primary" id="add">Upload APK</button></div>
  <div class="card scroll"><table class="tbl"><thead><tr><th>Game</th><th>Package</th><th>Runtime</th><th>Installation</th><th>Resources</th><th>Published</th><th></th></tr></thead><tbody>
  ${games.map((g) => `<tr><td><div class="row" style="flex-wrap:nowrap">${g.has_icon ? `<img class="thumb" alt="" src="/api/games/${g.id}/icon?v=${g.updated_at}">` : `<span class="thumb">${esc(g.name[0])}</span>`}<div><b>${esc(g.name)}</b><div class="muted small">v${esc(g.version_name || '?')} &middot; ${bytes(g.size_bytes)}</div></div></div></td>
   <td class="mono small">${esc(g.package_name)}</td>
   <td><span class="badge ${g.running ? 'ok' : 'off'}">${g.running ? `Running (${g.active_sessions})` : 'Stopped'}</span></td>
   <td>${installBadge(g.install)}</td>
   <td class="small">${g.min_ram_mb} MB / ${g.cpu_cores} CPU<br><span class="muted">${esc(g.orientation)}</span></td>
   <td><label class="row" style="margin:0"><input type="checkbox" data-en="${g.id}" ${g.enabled ? 'checked' : ''}> <span class="small">${g.enabled ? 'Enabled' : 'Disabled'}</span></label></td>
   <td><div class="row" style="justify-content:flex-end">
     <button class="btn sm" data-a="start" data-id="${g.id}">Start</button><button class="btn sm" data-a="stop" data-id="${g.id}">Stop</button><button class="btn sm" data-a="restart" data-id="${g.id}">Restart</button>
     <button class="btn sm" data-a="install" data-id="${g.id}">Installation</button><button class="btn sm" data-a="logs" data-id="${g.id}">Logs</button><button class="btn sm" data-a="edit" data-id="${g.id}">Edit</button><button class="btn sm danger" data-a="delete" data-id="${g.id}">Delete</button></div></td></tr>`).join('') || '<tr><td colspan="7" class="muted center">No games uploaded yet.</td></tr>'}
  </tbody></table></div>`;
  const byId = Object.fromEntries(games.map((g) => [g.id, g]));
  $('#add').onclick = () => gameModal(null);
  view.onchange = async (e) => {
    const id = e.target.dataset.en; if (!id) return;
    try { await API.put('/admin/games/' + id, { enabled: e.target.checked }); toast(e.target.checked ? 'Game enabled' : 'Game disabled', 'ok'); vApks(); } catch (err) { toast(err.message, 'err'); e.target.checked = !e.target.checked; }
  };
  view.onclick = async (e) => {
    const b = e.target.closest('[data-a]'); if (!b) return; const g = byId[b.dataset.id];
    try {
      if (b.dataset.a === 'edit') return gameModal(g);
      if (b.dataset.a === 'logs') return logsModal(g);
      if (b.dataset.a === 'install') return installModal(g);
      if (b.dataset.a === 'delete') { if (!confirm(`Delete "${g.name}"? This removes the APK and stops running sessions.`)) return; await API.del('/admin/games/' + g.id); toast('Game deleted', 'ok'); return vApks(); }
      b.disabled = true;
      const r = await API.post(`/admin/games/${g.id}/${b.dataset.a}`);
      if (b.dataset.a === 'stop') toast(`Stopped ${r.stopped} session(s)`, 'ok');
      else { toast('Emulator starting. Open the game in a test session once it is ready.', 'ok'); if (r.id && confirm('Open the live test session now?')) { location.href = `/player.html?s=${r.id}`; return; } }
      vApks();
    } catch (err) { toast(err.message, 'err'); b.disabled = false; }
  };
}

function modal(html) {
  const m = document.createElement('div'); m.className = 'modal'; m.innerHTML = `<div class="card">${html}</div>`;
  m.addEventListener('mousedown', (e) => { if (e.target === m) m.remove(); });
  document.body.appendChild(m); return m;
}

function gameModal(g) {
  const m = modal(`<h2>${g ? 'Edit game' : 'Upload APK'}</h2><form id="gf" style="margin-top:1rem">
    ${g ? '' : '<div class="field"><label>APK file *</label><input type="file" name="apk" accept=".apk" required></div>'}
    ${g ? '<div class="field"><label>Replace APK (publishes an update; the installed copy updates on next launch or via Installation > Update)</label><input type="file" name="apk" accept=".apk"></div>' : ''}
    <div class="field"><label>Game name *</label><input name="name" maxlength="80" required value="${esc(g ? g.name : '')}"></div>
    <div class="field"><label>Description</label><textarea name="description">${esc(g ? g.description : '')}</textarea></div>
    <div class="field"><label>Icon (PNG/JPEG/WebP, max 2 MB)</label><input type="file" name="icon" accept="image/png,image/jpeg,image/webp"></div>
    <div class="field"><label>Package name ${g ? '' : '(auto-detected; override if needed)'}</label><input name="package_name" placeholder="com.example.game" value="${esc(g ? g.package_name : '')}"></div>
    <div class="field"><label>Launch activity (optional)</label><input name="main_activity" placeholder="auto-detected" value="${esc(g ? g.main_activity : '')}"></div>
    <div class="grid" style="grid-template-columns:1fr 1fr 1fr;gap:.7rem">
      <div class="field"><label>Min RAM (MB)</label><input type="number" name="min_ram_mb" min="1024" step="256" value="${g ? g.min_ram_mb : 2048}"></div>
      <div class="field"><label>CPU cores</label><input type="number" name="cpu_cores" min="1" max="32" value="${g ? g.cpu_cores : 2}"></div>
      <div class="field"><label>Orientation</label><select name="orientation"><option value="landscape" ${g && g.orientation === 'landscape' ? 'selected' : ''}>Landscape</option><option value="portrait" ${g && g.orientation === 'portrait' ? 'selected' : ''}>Portrait</option></select></div></div>
    <label class="row"><input type="checkbox" name="enabled" ${!g || g.enabled ? 'checked' : ''}> Publish (visible to players)</label>
    <div class="progress hidden" id="pg" style="margin-top:1rem"><i></i></div><div class="err-text" id="ge"></div>
    <div class="row" style="justify-content:flex-end"><button type="button" class="btn" id="cx">Cancel</button><button class="btn primary" id="sv">${g ? 'Save' : 'Upload & publish'}</button></div></form>`);
  $('#cx', m).onclick = () => m.remove();
  $('#gf', m).onsubmit = async (e) => {
    e.preventDefault();
    const f = e.target; const fd = new FormData(f);
    fd.set('enabled', f.enabled.checked ? '1' : '0');
    if (!fd.get('icon') || !fd.get('icon').size) fd.delete('icon');
    if (g && (!fd.get('apk') || !fd.get('apk').size)) fd.delete('apk');
    $('#sv', m).disabled = true; $('#ge', m).textContent = '';
    try {
      if (g) { if (fd.get('apk')) $('#pg', m).classList.remove('hidden'); const r = await API.upload('PUT', '/admin/games/' + g.id, fd, (p) => { $('#pg i', m).style.width = Math.round(p * 100) + '%'; }); if (r && r.note) toast(r.note, 'ok'); }
      else { $('#pg', m).classList.remove('hidden'); const r = await API.upload('POST', '/admin/games', fd, (p) => { $('#pg i', m).style.width = Math.round(p * 100) + '%'; }); if (r.warning) toast(r.warning, 'err'); }
      m.remove(); toast(g ? 'Game updated' : 'Game published', 'ok'); vApks();
    } catch (err) { $('#ge', m).textContent = err.message; $('#sv', m).disabled = false; }
  };
}

function installBadge(i) {
  if (i.busy_op) return `<span class="badge warn">Working: ${esc(i.busy_op)}</span>`;
  const v = i.version_name ? ' v' + esc(i.version_name) : '';
  const map = { installed: ['ok', 'Installed' + v], installing: ['warn', 'Installing'], failed: ['bad', 'Failed'], uninstalled: ['off', 'Uninstalled'], not_installed: ['off', 'Not installed'] };
  const [c, t] = map[i.status] || ['off', i.status];
  return `<span class="badge ${c}">${t}</span>`;
}

async function installModal(g) {
  const m = modal('<div class="center"><span class="spin"></span></div>');
  let alive = true; let t = null;
  const close = () => { alive = false; clearTimeout(t); m.remove(); };
  m.addEventListener('mousedown', (e) => { if (e.target === m) close(); });
  const draw = async () => {
    if (!alive) return;
    let d; try { d = await API.get(`/admin/games/${g.id}/install`); } catch (e) { m.firstChild.innerHTML = `<div class="err-text">${esc(e.message)}</div>`; return; }
    const r = d.registry; const busy = r.busy_op || d.activeSessions.some((x) => x.op);
    m.firstChild.innerHTML = `<h2>Installation: ${esc(g.name)}</h2>
    <div class="grid" style="grid-template-columns:1fr 1fr;gap:.6rem;margin:1rem 0">
      <div><div class="muted small">Status</div>${installBadge({ ...r })}</div>
      <div><div class="muted small">Installed version</div>${esc(r.version_name || '-')} <span class="muted small">(APK: ${esc(d.game.version_name || '?')})</span></div>
      <div><div class="muted small">Package</div><span class="mono small">${esc(d.game.package_name)}</span></div>
      <div><div class="muted small">Installs performed</div>${r.install_count}</div>
      <div><div class="muted small">Installed at</div>${when(r.installed_at)}</div>
      <div><div class="muted small">Last launched</div>${when(r.last_launched_at)}</div>
      <div><div class="muted small">Last verified</div>${when(r.last_verified_at)}</div>
      <div><div class="muted small">Persistent instance</div>${d.instance.exists ? 'Present' : 'Not created yet'}<div class="mono small muted">${esc(d.instance.volume)}</div></div></div>
    <div class="card" style="background:#0b101a;margin-bottom:.8rem"><span class="small">${d.pendingReason ? `Next launch will <b>install</b> (${esc(d.pendingReason)}).` : 'Installed and up to date. Launches will <b>not</b> reinstall.'}</span>
    ${busy ? `<div class="small" style="margin-top:.4rem;color:var(--warn)"><span class="spin" style="width:14px;height:14px;border-width:2px"></span> Operation in progress${r.busy_op ? ': ' + esc(r.busy_op) : ''}. This can take a few minutes (the emulator boots first).</div>` : ''}</div>
    ${r.last_error ? `<div class="err-text">${esc(r.last_error)}</div>` : ''}
    <div class="row">${[['verify', 'Verify'], ['update', 'Update'], ['reinstall', 'Reinstall'], ['clear-data', 'Clear data'], ['uninstall', 'Uninstall']].map(([k, l]) => `<button class="btn sm ${k === 'uninstall' || k === 'clear-data' ? 'danger' : ''}" data-op="${k}" ${busy ? 'disabled' : ''}>${l}</button>`).join('')}</div>
    <div class="muted small" style="margin-top:.7rem"><b>Verify</b> checks the device. <b>Update</b> installs the stored APK over the existing one, keeping game data. <b>Reinstall</b> removes the app (keeping its data) and installs it again. <b>Clear data</b> wipes the game's saved data. <b>Uninstall</b> removes the game from its instance. All of these stop any active player of this game.</div>
    <div class="row" style="justify-content:flex-end;margin-top:1rem"><button class="btn" id="cx">Close</button></div>`;
    $('#cx', m).onclick = () => { close(); vApks(); };
    m.querySelectorAll('[data-op]').forEach((b) => { b.onclick = async () => {
      const op = b.dataset.op;
      const warn = { reinstall: 'Reinstall? Any player of this game will be disconnected.', uninstall: 'Uninstall this game from its instance? Players will be disconnected and the game reinstalls on next launch.', 'clear-data': 'Clear ALL saved game data? This cannot be undone.' }[op];
      if (warn && !confirm(warn)) return;
      b.disabled = true;
      try { const r2 = await API.post(`/admin/games/${g.id}/install/${op}`); toast(r2.message || 'Started', 'ok'); } catch (e) { toast(e.message, 'err'); }
      draw();
    }; });
    clearTimeout(t); if (busy) t = setTimeout(draw, 3000);
  };
  draw();
}

async function logsModal(g) {
  const m = modal(`<h2>Logs: ${esc(g.name)}</h2><pre class="log" id="lg" style="margin-top:1rem">Loading...</pre><div class="row" style="justify-content:flex-end;margin-top:.8rem"><button class="btn" id="cx">Close</button></div>`);
  $('#cx', m).onclick = () => m.remove();
  const rows = await API.get(`/admin/games/${g.id}/logs`).catch((e) => { $('#lg', m).textContent = e.message; return null; });
  if (rows) $('#lg', m).textContent = rows.length ? rows.map((r) => `${new Date(r.ts).toLocaleTimeString()} [${r.level}] ${r.message}`).join('\n') : 'No log entries yet.';
}

// ---------------- Admin: settings ----------------
async function vSettings() {
  const [s, ss] = await Promise.all([API.get('/admin/settings'), API.get('/admin/sessions')]);
  const num = (k, l, min) => `<div class="field"><label>${l}</label><input type="number" name="${k}" min="${min}" value="${esc(s[k])}"></div>`;
  view.innerHTML = `<div class="page-head"><h1>User Settings</h1></div><div class="grid cols2">
  <form class="card" id="sf"><h2>Access &amp; limits</h2><div style="margin-top:1rem">
    <div class="field"><label>Website name</label><input name="site_name" maxlength="40" value="${esc(s.site_name)}"></div>
    <label class="row field"><input type="checkbox" name="user_access_enabled" ${s.user_access_enabled === '1' ? 'checked' : ''}> User access enabled</label>
    ${num('max_concurrent_sessions', 'Max concurrent user logins', 1)}${num('session_timeout_min', 'Login session timeout (minutes)', 5)}${num('max_upload_mb', 'Max APK upload size (MB)', 1)}
    ${num('max_emulators', 'Max running emulators', 1)}${num('ram_per_emulator_mb', 'RAM cap per emulator (MB)', 1024)}${num('cpu_per_emulator', 'CPU cap per emulator (cores)', 1)}${num('play_duration_min', 'Max play session duration (minutes)', 5)}
    <button class="btn primary">Save settings</button></div></form>
  <div class="grid" style="align-content:start"><form class="card" id="pf"><h2>Change passwords</h2><div style="margin-top:1rem">
    <div class="field"><label>Which password</label><select name="which"><option value="user">Shared user password</option><option value="admin">Admin password</option></select></div>
    <div class="field"><label>New password (min 8 characters)</label><input type="password" name="password" autocomplete="new-password" minlength="8" required></div>
    <div class="field"><label>Your current admin password</label><input type="password" name="currentAdminPassword" autocomplete="current-password" required></div>
    <button class="btn primary">Update password</button></div></form></div></div>
  <div class="card" style="margin-top:1rem"><h2>Active sessions</h2><div class="scroll" style="margin-top:.8rem"><table class="tbl"><thead><tr><th>Type</th><th>Detail</th><th>Last active</th><th></th></tr></thead><tbody>
   ${ss.logins.map((l) => `<tr><td><span class="badge ${l.role === 'admin' ? 'warn' : 'ok'}">${l.role}</span></td><td class="small">${esc(l.ip)}<div class="muted">${esc((l.user_agent || '').slice(0, 60))}</div></td><td class="small">${when(l.last_seen)}</td><td>${l.current ? '<span class="muted small">this session</span>' : `<button class="btn sm danger" data-login="${l.id}">Terminate</button>`}</td></tr>`).join('')}
   ${ss.play.map((p) => `<tr><td><span class="badge">emulator</span></td><td class="small">${esc(p.game_name || p.game_id)}<div class="muted">${esc(p.status)} (${esc(p.role)})</div></td><td class="small">since ${when(p.started_at)}</td><td><button class="btn sm danger" data-play="${p.id}">Terminate</button></td></tr>`).join('')}
  </tbody></table></div></div>`;
  $('#sf').onsubmit = async (e) => {
    e.preventDefault(); const f = e.target; const body = {};
    for (const el of f.elements) if (el.name) body[el.name] = el.type === 'checkbox' ? el.checked : el.value;
    try { await API.put('/admin/settings', body); toast('Settings saved', 'ok'); ME.siteName = body.site_name; document.querySelectorAll('.site-name').forEach((x) => { x.textContent = body.site_name; }); } catch (err) { toast(err.message, 'err'); }
  };
  $('#pf').onsubmit = async (e) => {
    e.preventDefault(); const f = e.target;
    try { await API.put('/admin/password', { which: f.which.value, password: f.password.value, currentAdminPassword: f.currentAdminPassword.value }); toast('Password updated', 'ok'); f.reset(); } catch (err) { toast(err.message, 'err'); }
  };
  view.onclick = async (e) => {
    const l = e.target.closest('[data-login]'); const p = e.target.closest('[data-play]');
    try {
      if (l) await API.del('/admin/sessions/login/' + l.dataset.login);
      else if (p) await API.del('/admin/sessions/play/' + p.dataset.play); else return;
      toast('Session terminated', 'ok'); vSettings();
    } catch (err) { toast(err.message, 'err'); }
  };
}

// ---------------- Admin: monitoring ----------------
async function vMonitor() {
  const draw = async () => {
    const s = await API.get('/admin/system');
    view.innerHTML = `<div class="page-head"><h1>VPS Monitoring</h1><span class="muted small">Live &middot; updates every 3s</span></div><div class="grid stats">
      ${meter('CPU usage', s.cpu.percent + '%', 'Load ' + s.cpu.load.map((x) => x.toFixed(2)).join(' / '), s.cpu.percent)}
      ${meter('RAM', bytes(s.mem.usedBytes), bytes(s.mem.availableBytes) + ' available of ' + bytes(s.mem.totalBytes), pct(s.mem.usedBytes, s.mem.totalBytes))}
      ${meter('Disk', bytes(s.disk.usedBytes), bytes(s.disk.availableBytes) + ' free of ' + bytes(s.disk.totalBytes), pct(s.disk.usedBytes, s.disk.totalBytes))}
      <div class="card stat"><div class="l">Network</div><div class="v" style="font-size:1.15rem">&darr; ${bytes(s.net.rxBps)}/s<br>&uarr; ${bytes(s.net.txBps)}/s</div></div>
      <div class="card stat"><div class="l">Emulators running</div><div class="v">${s.emulators}</div></div>
      <div class="card stat"><div class="l">Active sessions</div><div class="v">${s.activeLogins}</div></div>
      <div class="card stat"><div class="l">KVM acceleration</div><div class="v">${s.kvm ? 'Yes' : 'No'}</div><div class="l">Uptime ${Math.round(s.uptimeSec / 3600)} h</div></div></div>`;
  };
  await draw(); timer = setInterval(() => draw().catch(() => {}), 3000);
}

// ---------------- Admin: audit log ----------------
async function vLogs() {
  const rows = await API.get('/admin/logs?limit=300');
  view.innerHTML = `<div class="page-head"><h1>Activity Logs</h1></div><div class="card scroll"><table class="tbl"><thead><tr><th>Time</th><th>Role</th><th>Action</th><th>Detail</th><th>IP</th></tr></thead><tbody>
  ${rows.map((r) => `<tr><td class="small">${when(r.ts)}</td><td>${esc(r.role || '-')}</td><td><span class="badge ${/fail/.test(r.action) ? 'bad' : ''}">${esc(r.action)}</span></td><td class="small">${esc(r.detail || '')}</td><td class="small mono">${esc(r.ip || '')}</td></tr>`).join('') || '<tr><td colspan="5" class="muted center">No activity yet.</td></tr>'}</tbody></table></div>`;
}

init();
