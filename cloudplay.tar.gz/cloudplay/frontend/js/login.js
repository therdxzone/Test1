'use strict';
let mode = 'user';
const $ = (id) => document.getElementById(id);

fetch('/api/auth/me', { credentials: 'same-origin' }).then((r) => r.json().then((d) => ({ ok: r.ok, d }))).then(({ ok, d }) => {
  if (d.siteName) { $('site').textContent = d.siteName; document.title = 'Sign in - ' + d.siteName; }
  if (ok) location.href = '/app.html';
}).catch(() => {});

function setMode(m) { mode = m; $('m-user').classList.toggle('on', m === 'user'); $('m-admin').classList.toggle('on', m === 'admin'); $('pw').focus(); }
$('m-user').onclick = () => setMode('user');
$('m-admin').onclick = () => setMode('admin');

$('form').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('err').textContent = ''; $('go').disabled = true; $('go').innerHTML = '<span class="spin"></span>';
  try {
    const r = await fetch('/api/auth/login', { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ mode, password: $('pw').value }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || 'Sign in failed.');
    location.href = '/app.html';
  } catch (err) {
    $('err').textContent = err.message; $('go').disabled = false; $('go').textContent = 'Sign in';
  }
});
