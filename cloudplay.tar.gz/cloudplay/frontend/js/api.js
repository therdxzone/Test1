'use strict';
const API = {
  csrf: null,
  async req(method, url, body, isForm) {
    const opts = { method, credentials: 'same-origin', headers: {} };
    if (this.csrf) opts.headers['X-CSRF-Token'] = this.csrf;
    if (body !== undefined) {
      if (isForm) opts.body = body;
      else { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body); }
    }
    const r = await fetch('/api' + url, opts);
    let data = null; try { data = await r.json(); } catch { /* empty */ }
    if (r.status === 401 && !url.startsWith('/auth/')) { location.href = '/'; throw new Error('Signed out'); }
    if (!r.ok) { const e = new Error((data && data.error) || `Request failed (${r.status})`); e.status = r.status; throw e; }
    return data;
  },
  get: (u) => API.req('GET', u),
  post: (u, b) => API.req('POST', u, b === undefined ? {} : b),
  put: (u, b) => API.req('PUT', u, b),
  del: (u) => API.req('DELETE', u),
  // multipart upload with progress (fetch cannot report upload progress)
  upload(method, url, form, onProgress) {
    return new Promise((resolve, reject) => {
      const x = new XMLHttpRequest();
      x.open(method, '/api' + url);
      x.setRequestHeader('X-CSRF-Token', this.csrf || '');
      x.upload.onprogress = (e) => { if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total); };
      x.onload = () => {
        let d = null; try { d = JSON.parse(x.responseText); } catch { /* ignore */ }
        if (x.status >= 200 && x.status < 300) resolve(d); else reject(new Error((d && d.error) || `Upload failed (${x.status})`));
      };
      x.onerror = () => reject(new Error('Network error during upload.'));
      x.send(form);
    });
  },
};

function esc(s) { return String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
function toast(msg, kind) {
  const t = document.createElement('div'); t.className = 'toast ' + (kind || ''); t.textContent = msg;
  document.getElementById('toasts').appendChild(t); setTimeout(() => t.remove(), kind === 'err' ? 6500 : 3500);
}
function bytes(n) { if (!n) return '0 B'; const u = ['B', 'KB', 'MB', 'GB', 'TB']; const i = Math.min(4, Math.floor(Math.log(n) / Math.log(1024))); return (n / 1024 ** i).toFixed(i ? 1 : 0) + ' ' + u[i]; }
function when(ts) { return ts ? new Date(ts).toLocaleString() : '-'; }
