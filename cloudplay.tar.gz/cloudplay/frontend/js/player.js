'use strict';
const $ = (id) => document.getElementById(id);
const sid = new URLSearchParams(location.search).get('s');
const vid = $('vid');
let ws = null, pc = null, dc = null, sess = null, closing = false, pingT = null;
const STEPS = { starting: ['Starting', 8], booting: ['Booting Android on the server', 30], installing: ['Installing the game', 60], launching: ['Launching the game', 85], running: ['Connecting stream', 95] };

function overlay(title, sub, pctv, fail) {
  $('ov').classList.remove('hidden');
  $('ovt').textContent = title; $('ovs').textContent = sub || '';
  if (pctv !== undefined) $('ovp').style.width = pctv + '%';
  $('ovspin').classList.toggle('hidden', !!fail); $('ovb').classList.toggle('hidden', !fail);
}
const setState = (t) => { $('state').textContent = t; };

async function boot() {
  if (!sid) return location.replace('/app.html');
  const me = await API.get('/auth/me').catch(() => null); if (!me) return;
  API.csrf = me.csrf;
  poll();
}

async function poll() {
  try {
    sess = await API.get('/play/' + sid);
    $('game').textContent = sess.game_name || 'Game'; document.title = sess.game_name || 'Playing';
    if (sess.status === 'running') return connect();
    if (sess.status === 'failed' || sess.status === 'stopped' || sess.status === 'crashed') return overlay(sess.status === 'failed' ? 'Could not start the game' : 'Session ended', sess.error || 'The session is no longer running.', 0, true);
    const [t, p] = STEPS[sess.status] || ['Working', 10];
    overlay('Starting your game', t + (sess.restarts ? ` (recovery attempt ${sess.restarts})` : '') + '...', p);
    setTimeout(poll, 1500);
  } catch (e) { overlay('Connection problem', e.message, 0, true); }
}

// ---------------- WebRTC ----------------
async function connect() {
  teardown(); closing = false;
  overlay('Connecting', 'Opening live stream...', 95);
  setState('Connecting');
  let ice = [];
  try { ice = (await API.get(`/play/${sid}/ice`)).iceServers; } catch { /* default */ }
  pc = new RTCPeerConnection({ iceServers: ice });
  pc.addTransceiver('video', { direction: 'recvonly' });
  dc = pc.createDataChannel('input', { ordered: false, maxRetransmits: 0 });
  pc.ontrack = (e) => { vid.srcObject = e.streams[0] || new MediaStream([e.track]); vid.play().catch(() => {}); };
  pc.onconnectionstatechange = () => {
    const s = pc.connectionState; setState(s === 'connected' ? 'Live' : s[0].toUpperCase() + s.slice(1));
    if (s === 'connected') $('ov').classList.add('hidden');
    if ((s === 'failed' || s === 'disconnected') && !closing) overlay('Connection lost', 'The stream was interrupted.', 0, true);
  };
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  ws = new WebSocket(`${proto}://${location.host}/ws/signal?session=${encodeURIComponent(sid)}`);
  pc.onicecandidate = (e) => { if (e.candidate && ws.readyState === 1) ws.send(JSON.stringify({ type: 'candidate', candidate: e.candidate })); };
  ws.onopen = async () => {
    const offer = await pc.createOffer(); await pc.setLocalDescription(offer);
    ws.send(JSON.stringify({ type: 'offer', sdp: pc.localDescription }));
    pingT = setInterval(() => ws.readyState === 1 && ws.send('{"type":"ping"}'), 20000);
  };
  ws.onmessage = async (ev) => {
    const m = JSON.parse(ev.data);
    if (m.type === 'answer') await pc.setRemoteDescription(m.sdp);
    else if (m.type === 'candidate') await pc.addIceCandidate(m.candidate).catch(() => {});
    else if (m.type === 'error') { toast(m.message, 'err'); }
  };
  ws.onclose = (e) => { clearInterval(pingT); if (!closing) { if (e.code === 4000) { checkEnded(); } else if (pc && pc.connectionState !== 'connected') overlay('Connection lost', 'Could not reach the stream.', 0, true); } };
  ws.onerror = () => {};
}
async function checkEnded() {
  try { const s = await API.get('/play/' + sid); if (s.status !== 'running') { if (['starting', 'booting', 'installing', 'launching'].includes(s.status)) { poll(); return; } overlay('Session ended', s.error || 'The game session has ended.', 0, true); } else connect(); }
  catch { overlay('Session ended', 'The game session has ended.', 0, true); }
}
function teardown() {
  closing = true; clearInterval(pingT);
  try { dc && dc.close(); } catch { /* */ } try { pc && pc.close(); } catch { /* */ } try { ws && ws.close(); } catch { /* */ }
  pc = dc = ws = null;
}
function send(o) {
  const s = JSON.stringify(o);
  if (dc && dc.readyState === 'open') dc.send(s);
  else if (ws && ws.readyState === 1) ws.send(JSON.stringify({ type: 'input', data: o }));
}

// ---------------- coordinate mapping (video is letterboxed with object-fit: contain) ----------------
function norm(cx, cy) {
  const r = vid.getBoundingClientRect(); const vw = vid.videoWidth || r.width, vh = vid.videoHeight || r.height;
  const s = Math.min(r.width / vw, r.height / vh); const w = vw * s, h = vh * s;
  const l = r.left + (r.width - w) / 2, t = r.top + (r.height - h) / 2;
  return { x: Math.min(1, Math.max(0, (cx - l) / w)), y: Math.min(1, Math.max(0, (cy - t) / h)) };
}
const denorm = (x, y) => {
  const r = vid.getBoundingClientRect(); const vw = vid.videoWidth || r.width, vh = vid.videoHeight || r.height;
  const s = Math.min(r.width / vw, r.height / vh); const w = vw * s, h = vh * s;
  return { x: r.left + (r.width - w) / 2 + x * w, y: r.top + (r.height - h) / 2 + y * h };
};

// ---------------- direct touch / mouse on the video ----------------
const ptr = new Map(); let nextId = 1;
const allocId = (pid) => { if (!ptr.has(pid)) ptr.set(pid, nextId++ % 90 + 1); return ptr.get(pid); };
let editing = false, setTargetMode = false;
vid.addEventListener('pointerdown', (e) => {
  if (setTargetMode && selected) { const n = norm(e.clientX, e.clientY); selected.target = { x: n.x, y: n.y }; setTargetMode = false; showCross(selected); saveCfg(); toast('Tap target set', 'ok'); return; }
  if (editing) return;
  vid.setPointerCapture(e.pointerId); const n = norm(e.clientX, e.clientY); send({ t: 'touch', a: 'down', id: allocId(e.pointerId), x: n.x, y: n.y });
});
vid.addEventListener('pointermove', (e) => { if (!ptr.has(e.pointerId) || editing) return; const n = norm(e.clientX, e.clientY); send({ t: 'touch', a: 'move', id: ptr.get(e.pointerId), x: n.x, y: n.y }); });
const upH = (e) => { if (!ptr.has(e.pointerId)) return; const n = norm(e.clientX, e.clientY); send({ t: 'touch', a: 'up', id: ptr.get(e.pointerId), x: n.x, y: n.y }); ptr.delete(e.pointerId); };
vid.addEventListener('pointerup', upH); vid.addEventListener('pointercancel', upH);
vid.addEventListener('contextmenu', (e) => e.preventDefault());
window.addEventListener('keydown', (e) => { if (['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) return; send({ t: 'key', code: e.code, down: true }); if (e.code.startsWith('Arrow') || e.code === 'Space') e.preventDefault(); });

// ---------------- virtual controls (joystick + buttons) with editable layout ----------------
const defCfg = () => ({ show: true, joy: { ui: { x: 0.12, y: 0.72 }, target: { x: 0.14, y: 0.7 }, radius: 0.12 }, buttons: [{ id: 'a', label: 'A', ui: { x: 0.88, y: 0.72 }, target: { x: 0.88, y: 0.72 } }, { id: 'b', label: 'B', ui: { x: 0.78, y: 0.84 }, target: { x: 0.78, y: 0.84 } }] });
const KEY = 'cp-controls-' + (sid || '');
let cfg = defCfg(); let gameKey = null; let selected = null; const els = [];
function loadCfg() { try { const c = JSON.parse(localStorage.getItem('cp-controls-' + gameKey) || 'null'); if (c && c.joy && Array.isArray(c.buttons)) cfg = c; } catch { /* default */ } }
function saveCfg() { try { localStorage.setItem('cp-controls-' + gameKey, JSON.stringify(cfg)); } catch { /* ignore */ } }
const isTouch = matchMedia('(pointer: coarse)').matches;

function place(el, ui) { el.style.left = ui.x * 100 + '%'; el.style.top = ui.y * 100 + '%'; el.style.transform = 'translate(-50%,-50%)'; }
function buildControls() {
  els.splice(0).forEach((x) => x.el.remove());
  if (!cfg.show) return;
  const j = document.createElement('div'); j.className = 'ctl joy'; j.innerHTML = '<i></i>'; place(j, cfg.joy.ui); $('stage').appendChild(j);
  els.push({ el: j, ref: cfg.joy, kind: 'joy' }); wireJoy(j);
  for (const b of cfg.buttons) {
    const d = document.createElement('div'); d.className = 'ctl tb'; d.textContent = b.label; place(d, b.ui); $('stage').appendChild(d);
    els.push({ el: d, ref: b, kind: 'btn' }); wireBtn(d, b);
  }
  els.forEach((x) => wireEdit(x));
}
function wireJoy(el) {
  const knob = el.firstChild; let pid = null; let tid = null;
  el.addEventListener('pointerdown', (e) => {
    if (editing) return; el.setPointerCapture(e.pointerId); pid = e.pointerId; tid = 150;
    send({ t: 'touch', a: 'down', id: tid, x: cfg.joy.target.x, y: cfg.joy.target.y }); move(e);
  });
  function move(e) {
    const r = el.getBoundingClientRect(); const cx = r.left + r.width / 2, cy = r.top + r.height / 2; const max = r.width / 2;
    let dx = e.clientX - cx, dy = e.clientY - cy; const d = Math.hypot(dx, dy); if (d > max) { dx = dx / d * max; dy = dy / d * max; }
    knob.style.transform = `translate(${dx}px,${dy}px)`;
    const R = cfg.joy.radius; const ar = vid.videoWidth / (vid.videoHeight || 1) || 16 / 9;
    send({ t: 'touch', a: 'move', id: tid, x: cfg.joy.target.x + (dx / max) * R / ar, y: cfg.joy.target.y + (dy / max) * R });
  }
  el.addEventListener('pointermove', (e) => { if (e.pointerId === pid) move(e); });
  const end = (e) => { if (e.pointerId !== pid) return; pid = null; knob.style.transform = ''; send({ t: 'touch', a: 'up', id: tid, x: cfg.joy.target.x, y: cfg.joy.target.y }); };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
}
function wireBtn(el, b) {
  let pid = null; const tid = 160 + (cfg.buttons.indexOf(b) % 20);
  el.addEventListener('pointerdown', (e) => { if (editing) return; el.setPointerCapture(e.pointerId); pid = e.pointerId; el.classList.add('down'); send({ t: 'touch', a: 'down', id: tid, x: b.target.x, y: b.target.y }); });
  const end = (e) => { if (e.pointerId !== pid) return; pid = null; el.classList.remove('down'); send({ t: 'touch', a: 'up', id: tid, x: b.target.x, y: b.target.y }); };
  el.addEventListener('pointerup', end); el.addEventListener('pointercancel', end);
}
function wireEdit(x) { // drag to reposition in edit mode, tap to select
  let drag = null;
  x.el.addEventListener('pointerdown', (e) => { if (!editing) return; e.stopPropagation(); x.el.setPointerCapture(e.pointerId); drag = e.pointerId; select(x); });
  x.el.addEventListener('pointermove', (e) => { if (!editing || drag !== e.pointerId) return; const r = $('stage').getBoundingClientRect(); x.ref.ui = { x: Math.min(.98, Math.max(.02, (e.clientX - r.left) / r.width)), y: Math.min(.98, Math.max(.02, (e.clientY - r.top) / r.height)) }; place(x.el, x.ref.ui); });
  x.el.addEventListener('pointerup', () => { if (drag !== null) { drag = null; saveCfg(); } });
}
function select(x) { els.forEach((o) => o.el.classList.remove('sel')); selected = x.ref; x.el.classList.add('sel'); showCross(x.ref); }
function showCross(ref) { const p = denorm(ref.target.x, ref.target.y); const c = $('cross'); c.style.display = 'block'; c.style.left = p.x + 'px'; c.style.top = p.y + 'px'; }
function setEditing(on) { editing = on; document.body.classList.toggle('editing', on); setTargetMode = false; if (!on) { $('cross').style.display = 'none'; selected = null; els.forEach((o) => o.el.classList.remove('sel')); } }

$('edit').onclick = () => { if (!cfg.show) { cfg.show = true; buildControls(); } setEditing(!editing); if (editing) toast('Drag controls to move. Select one, then "Set tap target" and tap where it should press in the game.'); };
$('done').onclick = () => { setEditing(false); saveCfg(); };
$('setTarget').onclick = () => { if (!selected) return toast('Select a control first', 'err'); setTargetMode = true; toast('Tap the spot on the game screen'); };
$('addBtn').onclick = () => { const label = (prompt('Button label (1-3 chars)', 'X') || '').slice(0, 3); if (!label) return; cfg.buttons.push({ id: 'b' + Date.now(), label, ui: { x: .6, y: .8 }, target: { x: .5, y: .5 } }); saveCfg(); buildControls(); };
$('delCtl').onclick = () => { const i = cfg.buttons.indexOf(selected); if (i < 0) return toast('Select a button to remove', 'err'); cfg.buttons.splice(i, 1); selected = null; saveCfg(); buildControls(); };
$('reset').onclick = () => { cfg = defCfg(); saveCfg(); buildControls(); };
$('touchToggle').onclick = () => { cfg.show = !cfg.show; saveCfg(); buildControls(); };

// ---------------- HUD ----------------
$('back').onclick = () => send({ t: 'back' });
$('fs').onclick = async () => { try { if (document.fullscreenElement) await document.exitFullscreen(); else { await document.documentElement.requestFullscreen(); if (screen.orientation && screen.orientation.lock && sess && sess.orientation) screen.orientation.lock(sess.orientation).catch(() => {}); } } catch { toast('Fullscreen is not supported here', 'err'); } };
$('reconnect').onclick = () => poll();
$('retry').onclick = () => poll();
$('ovx').onclick = () => { location.href = '/app.html'; };
$('exit').onclick = async () => { if (!confirm('Exit the game? Your session on the server will end.')) return; teardown(); try { await API.del('/play/' + sid); } catch { /* ignore */ } location.href = '/app.html'; };
window.addEventListener('beforeunload', () => { closing = true; });
window.addEventListener('resize', () => { if (editing && selected) showCross(selected); });

boot().then(() => { /* game key is the game id so layouts persist across sessions */ }).catch(() => {});
const waitKey = setInterval(() => { if (sess) { gameKey = sess.game_id; loadCfg(); buildControls(); if (!isTouch && cfg.show && !localStorage.getItem('cp-controls-' + gameKey)) { cfg.show = false; buildControls(); } clearInterval(waitKey); } }, 200);
