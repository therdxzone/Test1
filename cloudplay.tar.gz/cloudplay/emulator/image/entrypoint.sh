#!/bin/bash
set -e
RAM="${EMU_RAM_MB:-2048}"
CORES="${EMU_CORES:-2}"
adb start-server >/dev/null 2>&1 || true
exec emulator -avd cp -no-window -no-audio -no-boot-anim -no-snapshot -no-metrics \
  -gpu swiftshader_indirect -accel on -memory "$RAM" -cores "$CORES" -netfast
