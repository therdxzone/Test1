Place your built APK here as quantaforge-opencode.apk. The website download button becomes active automatically.
