plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
 namespace="ai.quantaforge.opencode"; compileSdk=35
 defaultConfig {
  applicationId="ai.quantaforge.opencode"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0"
  buildConfigField("String","API_BASE_URL","\"https://ai.example.com/\"")
 }
 buildFeatures { buildConfig=true }
}
