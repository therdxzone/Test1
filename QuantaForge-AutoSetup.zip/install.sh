#!/usr/bin/env bash
set -Eeuo pipefail
APP_DIR="/opt/quantaforge-opencode"
ETC_DIR="/etc/quantaforge-opencode"
SERVICE_USER="${SUDO_USER:-$USER}"
if [[ $EUID -ne 0 ]]; then echo "Run with: sudo bash install.sh"; exit 1; fi
if [[ ! -f "$(pwd)/server.js" || ! -d "$(pwd)/public" ]]; then
  echo "Run this script from the extracted project root (contains server.js and public/)."; exit 1
fi
echo "=== QuantaForge OpenCode Auto-Setup ==="
read -rsp "Create a private APP_TOKEN (leave blank to generate): " APP_TOKEN; echo
if [[ -z "$APP_TOKEN" ]]; then APP_TOKEN="$(openssl rand -hex 32)"; fi
if [[ ${#APP_TOKEN} -lt 32 ]]; then echo "Token must be at least 32 characters."; exit 1; fi
read -rp "Cloudflare Tunnel token (leave blank to configure later): " CF_TOKEN
read -rp "Workspace directory [/opt/quantaforge-workspace]: " WORKSPACE
WORKSPACE="${WORKSPACE:-/opt/quantaforge-workspace}"
# Install prerequisites, preserving existing Node installation.
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y ca-certificates curl openssl git
if ! command -v node >/dev/null 2>&1 || ! node -e 'process.exit(Number(process.versions.node.split(".")[0] < 20))'; then
  curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
  apt-get install -y nodejs
fi
id -u qfopencode >/dev/null 2>&1 || useradd --system --home-dir "$WORKSPACE" --create-home --shell /usr/sbin/nologin qfopencode
install -d -m 0750 -o qfopencode -g qfopencode "$WORKSPACE"
install -d -m 0750 "$APP_DIR" "$ETC_DIR"
cp -a "$(pwd)/." "$APP_DIR/"
chown -R root:root "$APP_DIR"
cd "$APP_DIR"
npm install --omit=dev
cat > "$ETC_DIR/app.env" <<EOF
APP_TOKEN=$APP_TOKEN
HOST=127.0.0.1
PORT=8787
WORKSPACE=$WORKSPACE
OPENCODE_URL=http://127.0.0.1:4096
EOF
chmod 600 "$ETC_DIR/app.env"
cat > /etc/systemd/system/quantaforge-opencode.service <<EOF
[Unit]
Description=QuantaForge OpenCode Gateway and Website
After=network-online.target
Wants=network-online.target
[Service]
Type=simple
User=qfopencode
Group=qfopencode
WorkingDirectory=$APP_DIR
EnvironmentFile=$ETC_DIR/app.env
ExecStart=/usr/bin/node $APP_DIR/server.js
Restart=on-failure
RestartSec=3
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=$WORKSPACE $APP_DIR/public/downloads
ProtectHome=true
[Install]
WantedBy=multi-user.target
EOF
install -d -o qfopencode -g qfopencode "$APP_DIR/public/downloads"
chown -R qfopencode:qfopencode "$APP_DIR/public/downloads"
systemctl daemon-reload
systemctl enable --now quantaforge-opencode
if [[ -n "$CF_TOKEN" ]]; then
  if ! command -v cloudflared >/dev/null 2>&1; then
    ARCH="$(dpkg --print-architecture)"
    case "$ARCH" in amd64) CF_ARCH=amd64;; arm64) CF_ARCH=arm64;; *) echo "Unsupported cloudflared architecture: $ARCH"; CF_ARCH="";; esac
    if [[ -n "$CF_ARCH" ]]; then
      curl -fsSL "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-${CF_ARCH}" -o /usr/local/bin/cloudflared
      chmod 755 /usr/local/bin/cloudflared
    fi
  fi
  if command -v cloudflared >/dev/null 2>&1; then
    printf 'TUNNEL_TOKEN=%s\n' "$CF_TOKEN" > "$ETC_DIR/cloudflared.env"
    chmod 600 "$ETC_DIR/cloudflared.env"
    cat > /etc/systemd/system/quantaforge-cloudflared.service <<'EOF'
[Unit]
Description=QuantaForge Cloudflare Tunnel
After=network-online.target quantaforge-opencode.service
Wants=network-online.target
[Service]
Type=simple
EnvironmentFile=/etc/quantaforge-opencode/cloudflared.env
ExecStart=/usr/local/bin/cloudflared tunnel run --no-autoupdate --token ${TUNNEL_TOKEN}
Restart=on-failure
RestartSec=5
User=root
NoNewPrivileges=true
[Install]
WantedBy=multi-user.target
EOF
    systemctl daemon-reload
    systemctl enable --now quantaforge-cloudflared
  fi
fi
echo
echo "=== Setup complete ==="
echo "Gateway: http://127.0.0.1:8787 (local only)"
echo "OpenCode expected: http://127.0.0.1:4096"
echo "Check: systemctl status quantaforge-opencode"
echo "Logs: journalctl -u quantaforge-opencode -f"
echo "APP_TOKEN saved in $ETC_DIR/app.env (root-readable only). Keep it private."
if [[ -n "$CF_TOKEN" ]]; then echo "Cloudflare service: systemctl status quantaforge-cloudflared"; echo "Ensure Cloudflare hostname route points to http://localhost:8787."; fi
echo "To uninstall, stop/disable the services and remove $APP_DIR and $ETC_DIR only after backing up."
