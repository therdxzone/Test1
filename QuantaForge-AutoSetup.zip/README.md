# QuantaForge Auto-Setup

Ubuntu/Debian one-command installer for a QuantaForge OpenCode gateway + download website, plus Android Studio source.

## What it installs
- Node.js gateway (local-only by default) and responsive download/connection website
- Detects `opencode` and checks common OpenCode server endpoints
- Cloudflare Tunnel token prompt and systemd service (optional)
- Bearer-token protected API for chat, workspace file browser/editor and terminal
- Android Studio project source (APK must be built and copied into the website's `public/downloads/` folder)

## Important limitations
1. A Cloudflare Tunnel token starts the tunnel, but the public hostname/route must already be configured in Cloudflare Zero Trust, pointing to `http://localhost:8787`. The installer cannot create DNS/Cloudflare routes from a tunnel token alone.
2. Website can serve an APK only after you build it and copy it to `public/downloads/quantaforge-opencode.apk`.
3. The APK is not prebuilt or tested in this archive. Build with Android Studio / Android SDK.
4. Terminal access is effectively remote shell access. Use a dedicated non-root Linux user and a trusted private tunnel. Do not give the shared app token to other people. For public multi-user service, implement individual accounts and isolated workspaces first.
5. OpenCode APIs vary by version. The chat adapter uses common session endpoints; verify against your installed OpenCode version.

## Install on Ubuntu/Debian
Upload/extract this project to the VPS, then:
```bash
cd QuantaForge-AutoSetup
sudo bash install.sh
```
Or run the one-command style after uploading:
```bash
sudo bash ./install.sh
```
The script asks for an application token and optional Cloudflare tunnel token. It creates `/opt/quantaforge-opencode`, installs Node.js if missing using the OS package manager, configures systemd, and starts the service.

The installer creates the service under the current invoking user where possible; avoid running OpenCode as root. Review `install.sh` before running it on a production VPS.

## Cloudflare route
In Cloudflare Zero Trust:
- Create/use a tunnel and copy its token.
- Add a public hostname such as `ai.yourdomain.com`.
- Service type HTTP, URL `http://localhost:8787`.
- If you want both website and API, they use the same hostname.
- The tunnel token is stored in `/etc/quantaforge-opencode/cloudflared.env` with root-only permissions.

## Build Android APK
1. Open `android/` in Android Studio.
2. Edit `android/app/build.gradle.kts`: set `API_BASE_URL` to your HTTPS hostname, e.g. `https://ai.yourdomain.com/`.
3. Sync Gradle and Build > Build APK(s).
4. Copy the APK to the VPS:
   `public/downloads/quantaforge-opencode.apk`
   then restart service if needed.
5. The website's Download APK button becomes available when that file exists.

## Website and API
- `GET /` landing/download page
- `GET /health` health check
- API routes under `/api` require `Authorization: Bearer <APP_TOKEN>`

## Backup / uninstall
Service data/config are under `/etc/quantaforge-opencode/`; app under `/opt/quantaforge-opencode`.
Do not expose port 8787 publicly. Bind gateway to 127.0.0.1 and use Cloudflare Tunnel or a properly configured TLS reverse proxy.
